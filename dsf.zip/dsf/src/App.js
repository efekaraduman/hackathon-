import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import './styles/minimalist.css';

// Components
import Login from './components/Login';
import DoctorPanel from './components/DoctorPanelOld';
import PatientPanel from './components/PatientPanel';
import ManagerPanel from './components/ManagerPanel';
import Layout from './components/Layout';
import NotificationSystem from './components/NotificationSystem';

// Data
import patientsData from './data/patients.json';

function App() {
  const [user, setUser] = useState(null);
  const [patients, setPatients] = useState(patientsData);
  const [complaints, setComplaints] = useState([]);

  useEffect(() => {
    // Check if user is logged in from localStorage
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    
    // Load complaints from localStorage
    const savedComplaints = localStorage.getItem('complaints');
    if (savedComplaints) {
      setComplaints(JSON.parse(savedComplaints));
    }
  }, []);

  const handleLogin = (userData) => {
    console.log('App.js - handleLogin called with:', userData);
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const handleLogout = () => {
    console.log('Çıkış yapılıyor...');
    setUser(null);
    localStorage.clear(); // Tüm localStorage'u temizle
    window.location.reload(); // Sayfayı yeniden yükle
  };

  const handleComplaintUpdate = (newComplaint) => {
    setComplaints(prev => {
      const updated = [...prev, newComplaint];
      localStorage.setItem('complaints', JSON.stringify(updated));
      return updated;
    });
  };

  return (
    <Router>
      <div className="App">
        <NotificationSystem />
        {!user ? (
          <Login onLogin={handleLogin} />
        ) : (
          <Layout user={user} onLogout={handleLogout}>
            <Routes>
              <Route 
                path="/" 
                element={
                  user.role === 'doctor' ? <Navigate to="/doctor" replace /> :
                  user.role === 'patient' ? <Navigate to="/patient" replace /> :
                  user.role === 'manager' ? <Navigate to="/manager" replace /> :
                  <Navigate to="/doctor" replace />
                } 
              />
              <Route 
                path="/doctor" 
                element={
                  user.role === 'doctor' ? 
                    <DoctorPanel patients={patients} setPatients={setPatients} onLogout={handleLogout} user={user} complaints={complaints} /> :
                    <Navigate to="/" replace />
                } 
              />
              <Route 
                path="/patient" 
                element={
                  user.role === 'patient' ?
                    <PatientPanel 
                      patients={patients} 
                      user={user} 
                      complaints={complaints}
                      onPatientsUpdate={(updatedPatient) => {
                        console.log('Patient updated in App:', updatedPatient);
                        // Burada gerçek uygulamada API'ye güncellenmiş hasta bilgisi gönderilir
                      }}
                      onComplaintUpdate={handleComplaintUpdate}
                    /> :
                    <Navigate to="/" replace />
                } 
              />
              <Route 
                path="/manager" 
                element={
                  user.role === 'manager' ?
                    <ManagerPanel patients={patients} user={user} onLogout={handleLogout} /> :
                    <Navigate to="/" replace />
                } 
              />
            </Routes>
          </Layout>
        )}
      </div>
    </Router>
  );
}

export default App;

