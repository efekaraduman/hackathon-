// Audit Log Sistemi

class AuditLogger {
  constructor() {
    this.logs = JSON.parse(localStorage.getItem('auditLogs') || '[]');
  }

  // Yeni log kaydı ekle
  addLog(action, details) {
    const logEntry = {
      id: Date.now() + Math.random(),
      timestamp: new Date().toISOString(),
      action,
      details,
      userAgent: navigator.userAgent,
      sessionId: this.getSessionId()
    };

    this.logs.unshift(logEntry);
    
    // Son 1000 kaydı tut
    if (this.logs.length > 1000) {
      this.logs = this.logs.slice(0, 1000);
    }

    this.saveToStorage();
    return logEntry;
  }

  // Hasta onay değişikliği logla
  logPatientApproval(patientId, action, confidence, feedback = '') {
    return this.addLog('PATIENT_APPROVAL', {
      patientId,
      action, // 'approve', 'reject', 'modify'
      confidence,
      feedback,
      type: 'approval_change'
    });
  }

  // Onay değişikliği logla (alias)
  logApprovalChange(patientId, action, confidence, feedback = '') {
    return this.logPatientApproval(patientId, action, confidence, feedback);
  }

  // İlaç değişikliği logla
  logMedicationChange(patientId, medicationId, oldData, newData) {
    return this.addLog('MEDICATION_CHANGE', {
      patientId,
      medicationId,
      oldData,
      newData,
      type: 'medication_update'
    });
  }

  // AI analiz logla
  logAIAnalysis(patientId, analysisType, confidence, result) {
    return this.addLog('AI_ANALYSIS', {
      patientId,
      analysisType,
      confidence,
      result,
      type: 'ai_analysis'
    });
  }

  // Veri erişimi logla
  logDataAccess(patientId, dataType, accessType) {
    return this.addLog('DATA_ACCESS', {
      patientId,
      dataType,
      accessType, // 'view', 'edit', 'export'
      type: 'data_access'
    });
  }

  // Kullanıcı girişi logla
  logUserLogin(userId, role, success) {
    return this.addLog('USER_LOGIN', {
      userId,
      role,
      success,
      type: 'authentication'
    });
  }

  // Sistem hatası logla
  logSystemError(error, context) {
    return this.addLog('SYSTEM_ERROR', {
      error: error.message || error,
      context,
      stack: error.stack,
      type: 'system_error'
    });
  }

  // Logları getir
  getLogs(filter = {}) {
    let filteredLogs = [...this.logs];

    if (filter.patientId) {
      filteredLogs = filteredLogs.filter(log => 
        log.details.patientId === filter.patientId
      );
    }

    if (filter.action) {
      filteredLogs = filteredLogs.filter(log => 
        log.action === filter.action
      );
    }

    if (filter.type) {
      filteredLogs = filteredLogs.filter(log => 
        log.details.type === filter.type
      );
    }

    if (filter.dateFrom) {
      filteredLogs = filteredLogs.filter(log => 
        new Date(log.timestamp) >= new Date(filter.dateFrom)
      );
    }

    if (filter.dateTo) {
      filteredLogs = filteredLogs.filter(log => 
        new Date(log.timestamp) <= new Date(filter.dateTo)
      );
    }

    return filteredLogs;
  }

  // İstatistikler
  getStatistics() {
    const stats = {
      totalLogs: this.logs.length,
      byAction: {},
      byType: {},
      byDay: {},
      recentActivity: this.logs.slice(0, 10)
    };

    this.logs.forEach(log => {
      // Action bazında
      stats.byAction[log.action] = (stats.byAction[log.action] || 0) + 1;
      
      // Type bazında
      const type = log.details.type || 'unknown';
      stats.byType[type] = (stats.byType[type] || 0) + 1;
      
      // Gün bazında
      const day = new Date(log.timestamp).toDateString();
      stats.byDay[day] = (stats.byDay[day] || 0) + 1;
    });

    return stats;
  }

  // Logları temizle
  clearLogs() {
    this.logs = [];
    this.saveToStorage();
  }

  // Logları dışa aktar
  exportLogs(format = 'json') {
    if (format === 'json') {
      return JSON.stringify(this.logs, null, 2);
    } else if (format === 'csv') {
      const headers = ['Timestamp', 'Action', 'Patient ID', 'Type', 'Details'];
      const csvContent = [
        headers.join(','),
        ...this.logs.map(log => [
          log.timestamp,
          log.action,
          log.details.patientId || '',
          log.details.type || '',
          JSON.stringify(log.details).replace(/,/g, ';')
        ].join(','))
      ].join('\n');
      return csvContent;
    }
  }

  // Session ID oluştur
  getSessionId() {
    let sessionId = sessionStorage.getItem('sessionId');
    if (!sessionId) {
      sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
      sessionStorage.setItem('sessionId', sessionId);
    }
    return sessionId;
  }

  // LocalStorage'a kaydet
  saveToStorage() {
    try {
      localStorage.setItem('auditLogs', JSON.stringify(this.logs));
    } catch (error) {
      console.error('Audit log kaydetme hatası:', error);
    }
  }

  // Log formatını düzenle
  formatLog(log) {
    const actionTexts = {
      'PATIENT_APPROVAL': 'Hasta Onayı',
      'MEDICATION_CHANGE': 'İlaç Değişikliği',
      'AI_ANALYSIS': 'AI Analizi',
      'DATA_ACCESS': 'Veri Erişimi',
      'USER_LOGIN': 'Kullanıcı Girişi',
      'SYSTEM_ERROR': 'Sistem Hatası'
    };

    const typeTexts = {
      'approval_change': 'Onay Değişikliği',
      'medication_update': 'İlaç Güncelleme',
      'ai_analysis': 'AI Analiz',
      'data_access': 'Veri Erişimi',
      'authentication': 'Kimlik Doğrulama',
      'system_error': 'Sistem Hatası'
    };

    return {
      ...log,
      actionText: actionTexts[log.action] || log.action,
      typeText: typeTexts[log.details.type] || log.details.type,
      formattedTime: new Date(log.timestamp).toLocaleString('tr-TR')
    };
  }
}

// Singleton instance
const auditLogger = new AuditLogger();

export default auditLogger;
