// AI Şikayet Analizi Sistemi
export const analyzeComplaint = (complaintData) => {
  const {
    complaintType,
    severity,
    duration,
    symptoms,
    description,
    emergency
  } = complaintData;

  // Acil durum kontrolü
  if (emergency || severity === 'critical') {
    return {
      priority: 'CRITICAL',
      urgency: 'IMMEDIATE',
      recommendations: [
        'Acil servise derhal başvurun',
        '112 numaralı hattı arayın',
        'Hastaneye en kısa sürede ulaşın'
      ],
      aiAnalysis: 'Kritik durum tespit edildi. Acil tıbbi müdahale gerekiyor.',
      suggestedTests: ['Acil laboratuvar', 'EKG', 'Radyoloji'],
      riskLevel: 'YÜKSEK'
    };
  }

  // Şikayet türüne göre analiz
  const analysis = getComplaintAnalysis(complaintType, severity, duration, symptoms, description);
  
  // AI önerileri
  const recommendations = generateRecommendations(complaintData, analysis);
  
  // Önerilen testler
  const suggestedTests = suggestTests(complaintType, severity, symptoms);
  
  // Risk seviyesi
  const riskLevel = calculateRiskLevel(severity, duration, complaintType);
  
  // Öncelik seviyesi
  const priority = calculatePriority(severity, riskLevel, emergency);
  
  // Aciliyet
  const urgency = calculateUrgency(priority, duration, complaintType);

  return {
    priority,
    urgency,
    recommendations,
    aiAnalysis: analysis.aiAnalysis,
    suggestedTests,
    riskLevel,
    confidence: analysis.confidence,
    relatedConditions: analysis.relatedConditions,
    warningSigns: analysis.warningSigns
  };
};

// Şikayet türüne göre detaylı analiz
const getComplaintAnalysis = (type, severity, duration, symptoms, description) => {
  const analyses = {
    'Ağrı': {
      aiAnalysis: 'Ağrı şikayeti analiz edildi. Lokalizasyon, karakter ve şiddet değerlendirildi.',
      confidence: 0.85,
      relatedConditions: ['Enflamasyon', 'Travma', 'Nörolojik durumlar'],
      warningSigns: ['Gece uyandıran ağrı', 'Ateş eşlik eden ağrı', 'Nörolojik belirtiler']
    },
    'Ateş': {
      aiAnalysis: 'Ateş şikayeti değerlendirildi. Enfeksiyon olasılığı yüksek.',
      confidence: 0.90,
      relatedConditions: ['Viral enfeksiyon', 'Bakteriyel enfeksiyon', 'Sistemik inflamasyon'],
      warningSigns: ['Yüksek ateş (>39°C)', 'Uzun süreli ateş', 'Nörolojik belirtiler']
    },
    'Nefes Darlığı': {
      aiAnalysis: 'Solunum sistemi ile ilgili şikayet tespit edildi. Kardiyopulmoner değerlendirme gerekli.',
      confidence: 0.88,
      relatedConditions: ['Astım', 'KOAH', 'Kalp yetmezliği', 'Pulmoner emboli'],
      warningSigns: ['Ani başlangıç', 'Göğüs ağrısı eşlik eden', 'Siyanoz']
    },
    'Baş Ağrısı': {
      aiAnalysis: 'Baş ağrısı şikayeti analiz edildi. Migren, gerilim tipi veya organik nedenler değerlendirildi.',
      confidence: 0.82,
      relatedConditions: ['Migren', 'Gerilim baş ağrısı', 'Sinüzit', 'Hipertansiyon'],
      warningSigns: ['Ani başlangıç', 'Görme bozukluğu', 'Nörolojik belirtiler']
    },
    'Göğüs Ağrısı': {
      aiAnalysis: 'Kardiyovasküler sistem ile ilgili şikayet. Acil değerlendirme gerekebilir.',
      confidence: 0.92,
      relatedConditions: ['Angina', 'MI', 'Perikardit', 'Pulmoner emboli'],
      warningSigns: ['Göğüste sıkışma hissi', 'Sol kola yayılan ağrı', 'Nefes darlığı']
    }
  };

  return analyses[type] || {
    aiAnalysis: 'Genel şikayet analizi yapıldı. Detaylı değerlendirme gerekli.',
    confidence: 0.75,
    relatedConditions: ['Genel değerlendirme gerekli'],
    warningSigns: ['Belirtilerin kötüleşmesi']
  };
};

// AI önerileri oluşturma
const generateRecommendations = (complaintData, analysis) => {
  const recommendations = [];
  
  // Genel öneriler
  if (complaintData.severity === 'severe' || complaintData.severity === 'critical') {
    recommendations.push('Acil tıbbi değerlendirme gerekli');
  }
  
  if (complaintData.duration === 'Son 1 saat' || complaintData.duration === 'Son 6 saat') {
    recommendations.push('Acil değerlendirme önerilir');
  }
  
  // Şikayet türüne özel öneriler
  const typeRecommendations = {
    'Ağrı': ['Ağrı kesici kullanımı', 'Dinlenme', 'Sıcak/soğuk uygulama'],
    'Ateş': ['Bol sıvı alımı', 'Ateş düşürücü', 'Dinlenme'],
    'Nefes Darlığı': ['Rahat pozisyon', 'Oksijen desteği değerlendirmesi'],
    'Baş Ağrısı': ['Karanlık ortam', 'Sessizlik', 'Baş ağrısı günlüğü'],
    'Mide Bulantısı': ['Hafif beslenme', 'Küçük porsiyonlar', 'Sıvı alımı']
  };
  
  const specificRecs = typeRecommendations[complaintData.complaintType] || [];
  recommendations.push(...specificRecs);
  
  // Genel öneriler
  recommendations.push('Doktor randevusuna kadar belirtileri takip edin');
  recommendations.push('Belirtiler kötüleşirse acil servise başvurun');
  
  return recommendations;
};

// Önerilen testler
const suggestTests = (type, severity, symptoms) => {
  const testMap = {
    'Ağrı': ['Kan tahlili', 'Görüntüleme', 'Fizik muayene'],
    'Ateş': ['Tam kan sayımı', 'CRP', 'ESR', 'İdrar tahlili'],
    'Nefes Darlığı': ['EKG', 'Akciğer grafisi', 'Arter kan gazı', 'D-dimer'],
    'Baş Ağrısı': ['Nörolojik muayene', 'Görüntüleme', 'Göz muayenesi'],
    'Göğüs Ağrısı': ['EKG', 'Troponin', 'Akciğer grafisi', 'Ekokardiografi'],
    'Mide Bulantısı': ['Karın ultrasonu', 'Kan tahlili', 'Gastroskopi']
  };
  
  let tests = testMap[type] || ['Genel laboratuvar', 'Fizik muayene'];
  
  // Şiddet seviyesine göre ek testler
  if (severity === 'severe' || severity === 'critical') {
    tests.push('Acil laboratuvar');
    tests.push('Acil görüntüleme');
  }
  
  return tests;
};

// Risk seviyesi hesaplama
const calculateRiskLevel = (severity, duration, type) => {
  let risk = 0;
  
  // Şiddet puanı
  const severityScores = { mild: 1, moderate: 2, severe: 3, critical: 4 };
  risk += severityScores[severity] || 1;
  
  // Süre puanı
  const durationScores = {
    'Son 1 saat': 4,
    'Son 6 saat': 3,
    'Son 24 saat': 2,
    '2-3 gün': 1,
    '1 hafta': 1,
    '2-4 hafta': 0,
    '1-3 ay': 0,
    '3+ ay': 0
  };
  risk += durationScores[duration] || 0;
  
  // Kritik şikayet türleri
  const criticalTypes = ['Göğüs Ağrısı', 'Nefes Darlığı', 'Bilinç Kaybı'];
  if (criticalTypes.includes(type)) {
    risk += 2;
  }
  
  if (risk >= 6) return 'YÜKSEK';
  if (risk >= 4) return 'ORTA';
  return 'DÜŞÜK';
};

// Öncelik seviyesi
const calculatePriority = (severity, riskLevel, emergency) => {
  if (emergency || severity === 'critical') return 'CRITICAL';
  if (severity === 'severe' || riskLevel === 'YÜKSEK') return 'HIGH';
  if (severity === 'moderate' || riskLevel === 'ORTA') return 'MEDIUM';
  return 'LOW';
};

// Aciliyet seviyesi
const calculateUrgency = (priority, duration, type) => {
  if (priority === 'CRITICAL') return 'IMMEDIATE';
  if (priority === 'HIGH') return 'URGENT';
  if (duration === 'Son 1 saat' || duration === 'Son 6 saat') return 'SOON';
  return 'ROUTINE';
};

// Şikayet geçmişi analizi
export const analyzeComplaintHistory = (complaints) => {
  if (!complaints || complaints.length === 0) {
    return {
      pattern: 'Yeni hasta',
      frequency: 'Bilinmiyor',
      trend: 'Stabil',
      recommendations: ['Detaylı anamnez alın']
    };
  }
  
  const recentComplaints = complaints.filter(c => 
    new Date(c.timestamp) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
  );
  
  const complaintTypes = complaints.map(c => c.complaintType);
  const mostCommon = getMostFrequent(complaintTypes);
  
  return {
    pattern: mostCommon,
    frequency: recentComplaints.length > 3 ? 'Sık' : 'Nadir',
    trend: analyzeTrend(complaints),
    recommendations: generateHistoryRecommendations(complaints)
  };
};

const getMostFrequent = (arr) => {
  const frequency = {};
  arr.forEach(item => {
    frequency[item] = (frequency[item] || 0) + 1;
  });
  
  return Object.keys(frequency).reduce((a, b) => 
    frequency[a] > frequency[b] ? a : b
  );
};

const analyzeTrend = (complaints) => {
  if (complaints.length < 2) return 'Stabil';
  
  const recent = complaints.slice(-3);
  const older = complaints.slice(-6, -3);
  
  const recentSeverity = recent.reduce((sum, c) => {
    const scores = { mild: 1, moderate: 2, severe: 3, critical: 4 };
    return sum + (scores[c.severity] || 1);
  }, 0);
  
  const olderSeverity = older.reduce((sum, c) => {
    const scores = { mild: 1, moderate: 2, severe: 3, critical: 4 };
    return sum + (scores[c.severity] || 1);
  }, 0);
  
  if (recentSeverity > olderSeverity) return 'Kötüleşiyor';
  if (recentSeverity < olderSeverity) return 'İyileşiyor';
  return 'Stabil';
};

const generateHistoryRecommendations = (complaints) => {
  const recommendations = [];
  
  if (complaints.length > 5) {
    recommendations.push('Kronik durum değerlendirmesi gerekli');
  }
  
  const severeCount = complaints.filter(c => c.severity === 'severe' || c.severity === 'critical').length;
  if (severeCount > 2) {
    recommendations.push('Acil müdahale protokolü uygulanmalı');
  }
  
  return recommendations;
};
