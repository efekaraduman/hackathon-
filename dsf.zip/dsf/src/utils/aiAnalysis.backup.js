// AI Analiz Fonksiyonları

// Hasta için AI özeti oluştur
export const generateAISummary = (patient) => {
  if (!patient) return null;

  // Risk seviyesi hesaplama
  let riskScore = 0;
  let mainProblems = [];
  let recommendations = '';

  // Yaş riski
  if (patient.age > 65) riskScore += 2;
  else if (patient.age > 50) riskScore += 1;

  // Kronik hastalık riski
  riskScore += patient.chronicDiseases.length;
  patient.chronicDiseases.forEach(disease => {
    if (disease.includes('Diyabet') || disease.includes('Hipertansiyon')) {
      mainProblems.push(disease);
    }
  });

  // İlaç sayısı riski
  if (patient.medications.length > 5) riskScore += 2;
  else if (patient.medications.length > 3) riskScore += 1;

  // Alerji riski
  if (patient.allergies.length > 0) {
    riskScore += 1;
    mainProblems.push(`${patient.allergies.length} alerji mevcut`);
  }

  // Laboratuvar değerleri kontrolü
  patient.labResults.forEach(result => {
    if (result.status !== 'Normal') {
      riskScore += 1;
      mainProblems.push(`${result.testName} değeri anormal`);
    }
  });

  // Risk seviyesi belirleme
  let riskLevel = 'Düşük';
  if (riskScore >= 6) riskLevel = 'Yüksek';
  else if (riskScore >= 3) riskLevel = 'Orta';

  // Öneriler oluşturma
  if (riskLevel === 'Yüksek') {
    recommendations = 'Hasta yakın takip altında tutulmalı, düzenli kontroller yapılmalı ve ilaç etkileşimleri sürekli değerlendirilmelidir.';
  } else if (riskLevel === 'Orta') {
    recommendations = 'Hasta düzenli aralıklarla kontrol edilmeli ve ilaç uyumu takip edilmelidir.';
  } else {
    recommendations = 'Hasta rutin takip programında tutulabilir.';
  }

  return {
    riskLevel,
    mainProblems: mainProblems.length > 0 ? mainProblems : ['Özel problem tespit edilmedi'],
    recommendations,
    riskScore
  };
};

// İlaç etkileşimlerini analiz et
export const analyzeDrugInteractions = (medications) => {
  if (!medications || medications.length < 2) return [];

  const interactions = [];
  const drugNames = medications.map(med => med.name.toLowerCase());
  const activeSubstances = medications.map(med => med.activeSubstance.toLowerCase());

  // Bilinen etkileşimler (demo için)
  const knownInteractions = [
    {
      drugs: ['metformin', 'insulin'],
      interaction: 'Metformin ve insulin birlikte kullanıldığında hipoglisemi riski artabilir.'
    },
    {
      drugs: ['lisinopril', 'amlodipin'],
      interaction: 'ACE inhibitörleri ve kalsiyum kanal blokerleri birlikte kullanıldığında hipotansiyon riski artabilir.'
    },
    {
      drugs: ['atorvastatin', 'ramipril'],
      interaction: 'Statin ve ACE inhibitörü birlikte kullanıldığında kas ağrıları görülebilir.'
    },
    {
      drugs: ['enalapril', 'tamsulosin'],
      interaction: 'ACE inhibitörü ve alfa bloker birlikte kullanıldığında baş dönmesi riski artabilir.'
    }
  ];

  // Etkileşim kontrolü
  knownInteractions.forEach(interaction => {
    const hasInteraction = interaction.drugs.every(drug => 
      drugNames.some(name => name.includes(drug)) || 
      activeSubstances.some(substance => substance.includes(drug))
    );
    
    if (hasInteraction) {
      interactions.push(interaction.interaction);
    }
  });

  // Aynı etken madde kontrolü
  const substanceCounts = {};
  activeSubstances.forEach(substance => {
    substanceCounts[substance] = (substanceCounts[substance] || 0) + 1;
  });

  Object.entries(substanceCounts).forEach(([substance, count]) => {
    if (count > 1) {
      interactions.push(`${substance} etken maddesi ${count} farklı ilaçta bulunmaktadır. Doz aşımı riski olabilir.`);
    }
  });

  return interactions;
};

// Hasta verilerini normalize et
export const normalizePatientData = (patient) => {
  if (!patient) return null;

  return {
    ...patient,
    medications: patient.medications.map(med => ({
      ...med,
      normalizedName: med.name.toLowerCase().trim(),
      normalizedSubstance: med.activeSubstance.toLowerCase().trim()
    }))
  };
};

// Hasta karşılaştırması yap
export const comparePatients = (patient1, patient2) => {
  if (!patient1 || !patient2) return null;

  const similarities = [];
  const differences = [];

  // Yaş karşılaştırması
  if (Math.abs(patient1.age - patient2.age) <= 5) {
    similarities.push('Benzer yaş grubu');
  } else {
    differences.push('Farklı yaş grupları');
  }

  // Kronik hastalık karşılaştırması
  const commonDiseases = patient1.chronicDiseases.filter(disease => 
    patient2.chronicDiseases.includes(disease)
  );
  
  if (commonDiseases.length > 0) {
    similarities.push(`Ortak hastalıklar: ${commonDiseases.join(', ')}`);
  }

  // İlaç karşılaştırması
  const commonMedications = patient1.medications.filter(med1 =>
    patient2.medications.some(med2 => 
      med1.activeSubstance.toLowerCase() === med2.activeSubstance.toLowerCase()
    )
  );

  if (commonMedications.length > 0) {
    similarities.push(`${commonMedications.length} ortak ilaç`);
  }

  return {
    similarities,
    differences,
    commonDiseases,
    commonMedications
  };
};

// Hasta risk skorlaması (gelişmiş versiyon)
export const calculateRiskScore = (patient) => {
  if (!patient) return { score: 0, level: 'Düşük', factors: [] };

  let riskScore = 0;
  let riskFactors = [];

  // Yaş faktörü
  if (patient.age >= 75) {
    riskScore += 30;
    riskFactors.push('İleri yaş (75+)');
  } else if (patient.age >= 65) {
    riskScore += 20;
    riskFactors.push('Yaşlı hasta (65+)');
  } else if (patient.age <= 5) {
    riskScore += 25;
    riskFactors.push('Çocuk hasta (5 yaş altı)');
  }

  // Kronik hastalık faktörü
  if (patient.chronicDiseases && patient.chronicDiseases.length > 0) {
    const chronicDiseases = patient.chronicDiseases.join(' ').toLowerCase();
    
    if (chronicDiseases.includes('kalp') || chronicDiseases.includes('kardiyak')) {
      riskScore += 25;
      riskFactors.push('Kardiyovasküler hastalık');
    }
    if (chronicDiseases.includes('diyabet') || chronicDiseases.includes('diabetes')) {
      riskScore += 20;
      riskFactors.push('Diyabet');
    }
    if (chronicDiseases.includes('hipertansiyon') || chronicDiseases.includes('tansiyon')) {
      riskScore += 15;
      riskFactors.push('Hipertansiyon');
    }
    if (chronicDiseases.includes('kanser') || chronicDiseases.includes('onkolojik')) {
      riskScore += 30;
      riskFactors.push('Onkolojik hastalık');
    }
    if (chronicDiseases.includes('koah') || chronicDiseases.includes('astım')) {
      riskScore += 18;
      riskFactors.push('Solunum hastalığı');
    }
    if (chronicDiseases.includes('böbrek') || chronicDiseases.includes('renal')) {
      riskScore += 22;
      riskFactors.push('Böbrek hastalığı');
    }

    // Genel kronik hastalık sayısı
    if (patient.chronicDiseases.length >= 3) {
      riskScore += 15;
      riskFactors.push('Çoklu komorbidite');
    }
  }

  // İlaç sayısı faktörü
  if (patient.medications && patient.medications.length >= 8) {
    riskScore += 20;
    riskFactors.push('Çoklu ilaç kullanımı (8+)');
  } else if (patient.medications && patient.medications.length >= 5) {
    riskScore += 10;
    riskFactors.push('Çoklu ilaç kullanımı (5+)');
  }

  // Alerji faktörü
  if (patient.allergies && patient.allergies.length > 0) {
    riskScore += 5;
    riskFactors.push(`${patient.allergies.length} alerji`);
  }

  // Risk seviyesi belirleme
  let riskLevel = 'Düşük';
  if (riskScore >= 70) riskLevel = 'Kritik';
  else if (riskScore >= 50) riskLevel = 'Yüksek';
  else if (riskScore >= 30) riskLevel = 'Orta';

  return {
    score: Math.min(riskScore, 100),
    level: riskLevel,
    factors: riskFactors
  };
};

// Hasta kategorilendirme
export const categorizePatient = (patient) => {
  const riskData = calculateRiskScore(patient);
  
  if (riskData.level === 'Kritik' || riskData.level === 'Yüksek') return 'Yüksek Risk';
  if (riskData.level === 'Orta') return 'Orta Risk';
  return 'Düşük Risk';
};

// Gelişmiş AI analiz sistemi
export const determineComplaintPriority = (complaintData, patient) => {
  if (!complaintData || !patient) return 'normal';

  let priorityScore = 0;
  const { title, description, symptoms, duration, previousTreatment } = complaintData;
  
  // Tüm metni birleştir ve analiz et
  const fullText = `${title} ${description} ${symptoms || ''}`.toLowerCase();
  
  // 1. SEMANTIK ANALİZ - Anlam bazlı değerlendirme
  priorityScore += analyzeSemanticContent(fullText);
  
  // 2. SÜRE ANALİZİ - Zaman faktörü
  priorityScore += analyzeDuration(duration);
  
  // 3. HASTA PROFİLİ ANALİZİ - Kişisel risk faktörleri
  priorityScore += analyzePatientProfile(patient);
  
  // 4. SEMPTOM ŞİDDETİ ANALİZİ - Ağrı ve semptom şiddeti
  priorityScore += analyzeSymptomSeverity(fullText);
  
  // 5. FONKSİYONEL ETKİ ANALİZİ - Günlük yaşam etkisi
  priorityScore += analyzeFunctionalImpact(fullText);
  
  // 6. ÖNCEKİ TEDAVİ ANALİZİ - Geçmiş tedavi deneyimi
  priorityScore += analyzePreviousTreatment(previousTreatment);
  
  // 7. DUYGUSAL TON ANALİZİ - Aciliyet ifadeleri
  priorityScore += analyzeEmotionalTone(fullText);
  
  // 8. TIBBİ URGENCY ANALİZİ - Tıbbi aciliyet göstergeleri
  priorityScore += analyzeMedicalUrgency(fullText);
  
  // Öncelik belirleme (daha hassas eşikler)
  if (priorityScore >= 12) return 'urgent';
  if (priorityScore >= 8) return 'high';
  if (priorityScore >= 4) return 'normal';
  return 'low';
};

// Semantik içerik analizi
const analyzeSemanticContent = (text) => {
  let score = 0;
  
  // Acil durum göstergeleri (çok geniş kapsamlı)
  const urgentPatterns = [
    /\b(acil|kritik|hayati|ölüm|ölümcül|tehlikeli)\b/,
    /\b(kalp\s*krizi|miyokard|enfarktüs|stroke|felç)\b/,
    /\b(nefes\s*alamıyorum|solunum\s*sıkıntısı|boğuluyorum)\b/,
    /\b(bilinç\s*kaybı|bayılma|koma|şok)\b/,
    /\b(kanama|hemoraji|kan\s*kaybı)\b/,
    /\b(travma|yaralanma|kazan|düşme)\b/,
    /\b(zehirlenme|intoksikasyon|overdose)\b/,
    /\b(yüksek\s*ateş|hipertermi|fever)\b/,
    /\b(şiddetli\s*ağrı|dayanılmaz|çok\s*şiddetli)\b/,
    /\b(durdurulamayan|kontrol\s*edilemeyen|geçmiyor)\b/
  ];
  
  urgentPatterns.forEach(pattern => {
    if (pattern.test(text)) score += 3;
  });
  
  // Yüksek öncelik göstergeleri
  const highPatterns = [
    /\b(şiddetli|kronik|sürekli|geçmiyor|artıyor|kötüleşiyor)\b/,
    /\b(uyuyamıyorum|yemek\s*yiyemiyorum|çalışamıyorum)\b/,
    /\b(günlük\s*hayatı\s*etkiliyor|normal\s*hayata\s*devam\s*edemiyorum)\b/,
    /\b(ilaç\s*işe\s*yaramıyor|tedavi\s*başarısız)\b/,
    /\b(doktor\s*değiştirdim|hastaneye\s*gittim|ambulans\s*çağırdım)\b/,
    /\b(yayılıyor|ilerliyor|kötüleşiyor)\b/
  ];
  
  highPatterns.forEach(pattern => {
    if (pattern.test(text)) score += 2;
  });
  
  // Düşük öncelik göstergeleri
  const lowPatterns = [
    /\b(hafif|ara\s*sıra|bazen|geçici|küçük)\b/,
    /\b(kendiliğinden\s*geçiyor|sadece|merak\s*ediyorum)\b/,
    /\b(kontrol|rutin|normal\s*mi|endişe)\b/,
    /\b(rahatsız\s*ediyor|biraz|az\s*miktarda)\b/
  ];
  
  lowPatterns.forEach(pattern => {
    if (pattern.test(text)) score -= 1;
  });
  
  return score;
};

// Süre analizi
const analyzeDuration = (duration) => {
  if (!duration) return 0;
  
  let score = 0;
  const durationText = duration.toLowerCase();
  
  // Sayısal değerleri çıkar
  const numbers = durationText.match(/\d+/g);
  if (numbers) {
    const num = parseInt(numbers[0]);
    
    // Dakika/saat = acil
    if (durationText.includes('dakika') || durationText.includes('minute')) {
      score += 4;
    } else if (durationText.includes('saat') || durationText.includes('hour')) {
      if (num <= 2) score += 4;
      else if (num <= 6) score += 3;
      else score += 2;
    }
    // Gün = normal-yüksek
    else if (durationText.includes('gün') || durationText.includes('day')) {
      if (num <= 1) score += 3;
      else if (num <= 3) score += 2;
      else if (num <= 7) score += 1;
      else score -= 1;
    }
    // Hafta = düşük
    else if (durationText.includes('hafta') || durationText.includes('week')) {
      score -= 1;
    }
    // Ay = çok düşük
    else if (durationText.includes('ay') || durationText.includes('month')) {
      score -= 2;
    }
  }
  
  return score;
};

// Hasta profili analizi
const analyzePatientProfile = (patient) => {
  let score = 0;

  // Yaş faktörü
  if (patient.age >= 75) score += 3;
  else if (patient.age >= 65) score += 2;
  else if (patient.age <= 5) score += 3;
  else if (patient.age <= 18) score += 1;

  // Kronik hastalık faktörü
  if (patient.chronicDiseases && patient.chronicDiseases.length > 0) {
    const chronicDiseases = patient.chronicDiseases.join(' ').toLowerCase();
    
    // Yüksek risk hastalıklar
    if (chronicDiseases.includes('kalp') || chronicDiseases.includes('kardiyak')) score += 3;
    if (chronicDiseases.includes('diyabet') || chronicDiseases.includes('diabetes')) score += 2;
    if (chronicDiseases.includes('hipertansiyon') || chronicDiseases.includes('tansiyon')) score += 2;
    if (chronicDiseases.includes('koah') || chronicDiseases.includes('astım')) score += 2;
    if (chronicDiseases.includes('kanser') || chronicDiseases.includes('onkolojik')) score += 3;
    if (chronicDiseases.includes('böbrek') || chronicDiseases.includes('renal')) score += 2;
    
    // Genel kronik hastalık sayısı
    score += Math.min(patient.chronicDiseases.length, 3);
  }

  // İlaç sayısı faktörü
  if (patient.medications && patient.medications.length >= 8) score += 3;
  else if (patient.medications && patient.medications.length >= 5) score += 2;
  else if (patient.medications && patient.medications.length >= 3) score += 1;

  // Alerji faktörü
  if (patient.allergies && patient.allergies.length > 0) {
    score += Math.min(patient.allergies.length, 2);
  }
  
  return score;
};

// Semptom şiddeti analizi
const analyzeSymptomSeverity = (text) => {
  let score = 0;
  
  // Ağrı şiddeti göstergeleri
  const painSeverityPatterns = [
    /\b(dayanılmaz|çok\s*şiddetli|korkunç|berbat)\b/,
    /\b(şiddetli|çok\s*ağrı|çok\s*kötü)\b/,
    /\b(orta|hafif\s*şiddetli)\b/,
    /\b(hafif|az|biraz)\b/
  ];
  
  const painScores = [4, 2, 0, -1];
  painSeverityPatterns.forEach((pattern, index) => {
    if (pattern.test(text)) score += painScores[index];
  });
  
  // Semptom çeşitliliği
  const symptomCount = (text.match(/\b(ağrı|bulantı|kusma|baş\s*dönmesi|halsizlik|ateş|titreme|terleme|çarpıntı|nefes\s*darlığı)\b/g) || []).length;
  score += Math.min(symptomCount, 3);
  
  return score;
};

// Fonksiyonel etki analizi
const analyzeFunctionalImpact = (text) => {
  let score = 0;
  
  const functionalImpactPatterns = [
    /\b(çalışamıyorum|işe\s*gidemiyorum|okula\s*gidemiyorum)\b/,
    /\b(uyuyamıyorum|yemek\s*yiyemiyorum|su\s*içemiyorum)\b/,
    /\b(yataktan\s*kalkamıyorum|yürüyemiyorum|oturup\s*kalkamıyorum)\b/,
    /\b(günlük\s*işlerimi\s*yapamıyorum|ev\s*işlerini\s*yapamıyorum)\b/,
    /\b(sosyal\s*hayattan\s*çekildim|insanlarla\s*görüşemiyorum)\b/
  ];
  
  functionalImpactPatterns.forEach(pattern => {
    if (pattern.test(text)) score += 2;
  });
  
  return score;
};

// Önceki tedavi analizi
const analyzePreviousTreatment = (previousTreatment) => {
  if (!previousTreatment) return 0;
  
  let score = 0;
  const treatmentText = previousTreatment.toLowerCase();
  
  if (treatmentText.includes('hastane') || treatmentText.includes('acil')) score += 3;
  if (treatmentText.includes('doktor') || treatmentText.includes('hekim')) score += 1;
  if (treatmentText.includes('ilaç') || treatmentText.includes('tedavi')) score += 1;
  if (treatmentText.includes('başarısız') || treatmentText.includes('işe\s*yaramadı')) score += 2;
  
  return score;
};

// Duygusal ton analizi
const analyzeEmotionalTone = (text) => {
  let score = 0;
  
  const urgentEmotionalPatterns = [
    /\b(panik|korku|endişe|stres|kaygı)\b/,
    /\b(çok\s*kötü|berbat|korkunç|dayanamıyorum)\b/,
    /\b(acil|hemen|şimdi|derhal)\b/,
    /\b(ölüyorum|öleceğim|hayatım\s*tehlikede)\b/
  ];
  
  urgentEmotionalPatterns.forEach(pattern => {
    if (pattern.test(text)) score += 2;
  });
  
  return score;
};

// Tıbbi aciliyet analizi
const analyzeMedicalUrgency = (text) => {
  let score = 0;
  
  const medicalUrgencyPatterns = [
    /\b(ateş|fever|hipertermi)\b/,
    /\b(çarpıntı|aritmi|kalp\s*ritmi)\b/,
    /\b(nefes\s*darlığı|dispne|solunum)\b/,
    /\b(baş\s*dönmesi|vertigo|dengesizlik)\b/,
    /\b(bulantı|kusma|nausea)\b/,
    /\b(ishal|diyare|kabızlık)\b/,
    /\b(idrar|mesane|böbrek)\b/,
    /\b(görme|göz|işitme|kulak)\b/
  ];
  
  medicalUrgencyPatterns.forEach(pattern => {
    if (pattern.test(text)) score += 1;
  });
  
  return score;
};

// Gelişmiş şikayet analizi ve öneriler
export const analyzeComplaint = (complaintData, patient) => {
  const priority = determineComplaintPriority(complaintData, patient);
  
  const analysis = {
    priority,
    urgencyLevel: {
      urgent: 'Acil - Hemen müdahale gerekli',
      high: 'Yüksek - 24 saat içinde değerlendirilmeli',
      normal: 'Normal - 1-3 gün içinde değerlendirilmeli',
      low: 'Düşük - Rutin kontrol sırasında değerlendirilebilir'
    }[priority],
    recommendations: [],
    riskFactors: [],
    confidence: calculateConfidence(complaintData, patient, priority),
    aiInsights: generateAIInsights(complaintData, patient, priority)
  };
  
  // Öneriler oluştur
  if (priority === 'urgent') {
    analysis.recommendations.push('🚨 Hasta acil servise yönlendirilmeli');
    analysis.recommendations.push('📊 Vital bulgular kontrol edilmeli');
    analysis.recommendations.push('👨‍⚕️ Doktor hemen bilgilendirilmeli');
    analysis.recommendations.push('⏰ Müdahale süresi: 0-30 dakika');
  } else if (priority === 'high') {
    analysis.recommendations.push('⚡ Hasta öncelikli randevuya alınmalı');
    analysis.recommendations.push('📋 Detaylı anamnez alınmalı');
    analysis.recommendations.push('🔬 Gerekli tetkikler planlanmalı');
    analysis.recommendations.push('⏰ Müdahale süresi: 24 saat içinde');
  } else if (priority === 'normal') {
    analysis.recommendations.push('📅 Rutin randevu planlanabilir');
    analysis.recommendations.push('👀 Semptom takibi yapılmalı');
    analysis.recommendations.push('⏰ Müdahale süresi: 1-3 gün içinde');
  } else {
    analysis.recommendations.push('🔄 Rutin kontrol sırasında değerlendirilebilir');
    analysis.recommendations.push('⏰ Müdahale süresi: 1 hafta içinde');
  }
  
  // Risk faktörleri
  if (patient.age >= 75) {
    analysis.riskFactors.push('👴 İleri yaş (75+)');
  } else if (patient.age >= 65) {
    analysis.riskFactors.push('👴 Yaşlı hasta (65+)');
  }
  
  if (patient.age <= 5) {
    analysis.riskFactors.push('👶 Çocuk hasta (5 yaş altı)');
  }
  
  if (patient.chronicDiseases && patient.chronicDiseases.length > 0) {
    analysis.riskFactors.push(`🏥 ${patient.chronicDiseases.length} kronik hastalık`);
  }
  
  if (patient.medications && patient.medications.length >= 5) {
    analysis.riskFactors.push(`💊 Çoklu ilaç kullanımı (${patient.medications.length} ilaç)`);
  }
  
  if (patient.allergies && patient.allergies.length > 0) {
    analysis.riskFactors.push(`⚠️ ${patient.allergies.length} alerji`);
  }
  
  return analysis;
};

// AI güven skoru hesaplama
const calculateConfidence = (complaintData, patient, priority) => {
  let confidence = 0;
  const { title, description, symptoms } = complaintData;
  
  // Metin uzunluğu faktörü
  const textLength = (title + description + (symptoms || '')).length;
  if (textLength > 100) confidence += 20;
  else if (textLength > 50) confidence += 10;
  
  // Semptom detayı faktörü
  if (symptoms && symptoms.length > 20) confidence += 15;
  
  // Hasta profili bilgisi
  if (patient.chronicDiseases && patient.chronicDiseases.length > 0) confidence += 10;
  if (patient.medications && patient.medications.length > 0) confidence += 10;
  
  // Öncelik seviyesi faktörü
  if (priority === 'urgent') confidence += 25;
  else if (priority === 'high') confidence += 20;
  else if (priority === 'normal') confidence += 15;
  else confidence += 10;
  
  return Math.min(confidence, 100);
};

// Aile geçmişi risk analizi
const analyzeFamilyHistory = (patient) => {
  if (!patient.familyHistory) {
    return {
      riskScore: 0,
      riskLevel: 'Bilinmiyor',
      analysis: 'Aile geçmişi bilgisi mevcut değil.',
      geneticRisks: [],
      recommendations: []
    };
  }

  const familyHistory = patient.familyHistory;
  let riskScore = 0;
  const geneticRisks = [];
  const recommendations = [];
  const analysis = [];

  // Anne-baba analizi
  if (familyHistory.father) {
    const father = familyHistory.father;
    if (!father.alive && father.causeOfDeath) {
      riskScore += 15;
      analysis.push(`Baba: ${father.causeOfDeath} nedeniyle kaybedilmiş (${father.age} yaşında)`);
      
      // Kalp hastalıkları analizi
      if (father.causeOfDeath.includes('Miyokard') || father.causeOfDeath.includes('Kalp')) {
        geneticRisks.push({
          disease: 'Kardiyovasküler Hastalık',
          risk: 'Yüksek',
          source: 'Baba - ' + father.causeOfDeath,
          preventiveActions: ['Düzenli kardiyoloji kontrolü', 'Kolesterol takibi', 'Egzersiz programı']
        });
        riskScore += 20;
      }
      
      // KOAH/Akciğer hastalıkları
      if (father.causeOfDeath.includes('KOAH') || father.causeOfDeath.includes('Akciğer')) {
        geneticRisks.push({
          disease: 'Solunum Sistemi Hastalıkları',
          risk: 'Yüksek',
          source: 'Baba - ' + father.causeOfDeath,
          preventiveActions: ['Sigara bırakma', 'Düzenli akciğer fonksiyon testleri', 'Solunum egzersizleri']
        });
        riskScore += 18;
      }

      // Diyabet komplikasyonları
      if (father.causeOfDeath.includes('Diyabet')) {
        geneticRisks.push({
          disease: 'Diyabet Tip 2',
          risk: 'Çok Yüksek',
          source: 'Baba - ' + father.causeOfDeath,
          preventiveActions: ['HbA1c düzenli takibi', 'Diyabet diyeti', 'Kilo kontrolü', 'İnsülin tedavi uyumu']
        });
        riskScore += 25;
      }
    }
    
    if (father.conditions && father.conditions.length > 0) {
      riskScore += father.conditions.length * 5;
      analysis.push(`Baba kronik hastalıkları: ${father.conditions.join(', ')}`);
    }
  }

  if (familyHistory.mother) {
    const mother = familyHistory.mother;
    if (!mother.alive && mother.causeOfDeath) {
      riskScore += 15;
      analysis.push(`Anne: ${mother.causeOfDeath} nedeniyle kaybedilmiş (${mother.age} yaşında)`);
      
      // Kanser analizi
      if (mother.causeOfDeath.includes('Kanser') || mother.causeOfDeath.includes('Cancer')) {
        const cancerType = mother.causeOfDeath.includes('Meme') ? 'Meme Kanseri' : 
                          mother.causeOfDeath.includes('Ovarian') ? 'Over Kanseri' :
                          mother.causeOfDeath.includes('Tiroid') ? 'Tiroid Kanseri' : 'Kanser';
        
        geneticRisks.push({
          disease: cancerType,
          risk: cancerType.includes('Meme') || cancerType.includes('Over') ? 'Çok Yüksek' : 'Yüksek',
          source: 'Anne - ' + mother.causeOfDeath,
          preventiveActions: [
            'Düzenli tarama testleri',
            'Genetik danışmanlık',
            'Erken tanı programları',
            'Risk azaltıcı yaşam tarzı değişiklikleri'
          ]
        });
        riskScore += cancerType.includes('Meme') || cancerType.includes('Over') ? 30 : 25;
      }

      // Alzheimer analizi
      if (mother.causeOfDeath.includes('Alzheimer')) {
        geneticRisks.push({
          disease: 'Alzheimer Hastalığı',
          risk: 'Orta',
          source: 'Anne - ' + mother.causeOfDeath,
          preventiveActions: ['Zihinsel aktiviteler', 'Düzenli egzersiz', 'Beslenme düzeni', 'Sosyal etkileşim']
        });
        riskScore += 15;
      }
    }
    
    if (mother.conditions && mother.conditions.length > 0) {
      riskScore += mother.conditions.length * 5;
      analysis.push(`Anne kronik hastalıkları: ${mother.conditions.join(', ')}`);
    }
  }

  // Kardeş analizi
  if (familyHistory.siblings && familyHistory.siblings.length > 0) {
    familyHistory.siblings.forEach(sibling => {
      if (sibling.conditions && sibling.conditions.length > 0) {
        riskScore += sibling.conditions.length * 3;
        analysis.push(`${sibling.gender} kardeş: ${sibling.conditions.join(', ')}`);
      }
    });
  }

  // Büyükanne-büyükbaba analizi
  if (familyHistory.grandparents && familyHistory.grandparents.length > 0) {
    familyHistory.grandparents.forEach(grandparent => {
      if (!grandparent.alive && grandparent.causeOfDeath) {
        riskScore += 8;
        analysis.push(`${grandparent.relation} (${grandparent.side}): ${grandparent.causeOfDeath}`);
        
        // Kanser geçmişi
        if (grandparent.causeOfDeath.includes('Kanser')) {
          const existing = geneticRisks.find(r => r.disease.includes('Kanser'));
          if (!existing) {
            geneticRisks.push({
              disease: 'Kanser (Aile Geçmişi)',
              risk: 'Orta',
              source: `${grandparent.relation} - ${grandparent.causeOfDeath}`,
              preventiveActions: ['Düzenli tarama testleri', 'Sağlıklı yaşam tarzı']
            });
          }
          riskScore += 10;
        }
      }
    });
  }

  // Genetik risk faktörleri
  if (familyHistory.geneticRiskFactors && familyHistory.geneticRiskFactors.length > 0) {
    familyHistory.geneticRiskFactors.forEach(risk => {
      if (risk.includes('Çok Yüksek')) riskScore += 15;
      else if (risk.includes('Yüksek')) riskScore += 10;
      else if (risk.includes('Orta')) riskScore += 5;
    });
    analysis.push(`Genetik risk faktörleri: ${familyHistory.geneticRiskFactors.join(', ')}`);
  }

  // Risk seviyesi belirleme
  let riskLevel;
  if (riskScore >= 80) riskLevel = 'Çok Yüksek';
  else if (riskScore >= 60) riskLevel = 'Yüksek';
  else if (riskScore >= 40) riskLevel = 'Orta';
  else if (riskScore >= 20) riskLevel = 'Düşük';
  else riskLevel = 'Minimal';

  // Genel öneriler
  if (geneticRisks.length > 0) {
    recommendations.push('Genetik danışmanlık alınması önerilir');
    recommendations.push('Düzenli sağlık taramaları yapılmalı');
    recommendations.push('Risk faktörlerini azaltıcı yaşam tarzı benimsenmelidir');
  }

  if (riskScore > 50) {
    recommendations.push('Aile hekimi ile aile geçmişi detaylı değerlendirilmelidir');
    recommendations.push('Erken tanı programlarına katılım sağlanmalıdır');
  }

  return {
    riskScore: Math.min(riskScore, 100),
    riskLevel,
    analysis: analysis.join('\n'),
    geneticRisks,
    recommendations,
    familyDiseasePattern: analyzeFamilyDiseasePattern(familyHistory)
  };
};

// Aile hastalık paterni analizi
const analyzeFamilyDiseasePattern = (familyHistory) => {
  const patterns = [];
  const diseases = {};

  // Tüm aile üyelerindeki hastalıkları topla
  const collectDiseases = (member, relation) => {
    if (member && member.conditions) {
      member.conditions.forEach(condition => {
        if (!diseases[condition]) diseases[condition] = [];
        diseases[condition].push(relation);
      });
    }
    if (member && member.causeOfDeath) {
      const cause = member.causeOfDeath;
      if (!diseases[cause]) diseases[cause] = [];
      diseases[cause].push(relation + ' (ölüm nedeni)');
    }
  };

  if (familyHistory.father) collectDiseases(familyHistory.father, 'Baba');
  if (familyHistory.mother) collectDiseases(familyHistory.mother, 'Anne');
  
  if (familyHistory.siblings) {
    familyHistory.siblings.forEach((sibling, index) => {
      collectDiseases(sibling, `${sibling.gender} Kardeş`);
    });
  }

  if (familyHistory.grandparents) {
    familyHistory.grandparents.forEach(gp => {
      collectDiseases(gp, `${gp.relation} (${gp.side})`);
    });
  }

  // Tekrarlanan hastalıkları tespit et
  Object.keys(diseases).forEach(disease => {
    if (diseases[disease].length >= 2) {
      patterns.push({
        disease,
        frequency: diseases[disease].length,
        affectedMembers: diseases[disease],
        risk: diseases[disease].length >= 3 ? 'Çok Yüksek' : 'Yüksek'
      });
    }
  });

  return patterns;
};

// AI içgörüleri oluşturma
const generateAIInsights = (complaintData, patient, priority) => {
  const insights = [];
  const { title, description, symptoms, duration } = complaintData;
  const fullText = `${title} ${description} ${symptoms || ''}`.toLowerCase();
  
  // Semptom analizi
  if (fullText.includes('ağrı')) {
    insights.push('🔍 Ağrı şikayeti tespit edildi - Lokalizasyon ve şiddet değerlendirilmeli');
  }
  
  if (fullText.includes('ateş') || fullText.includes('fever')) {
    insights.push('🌡️ Ateş şikayeti - Vücut sıcaklığı ölçülmeli');
  }
  
  if (fullText.includes('nefes') || fullText.includes('solunum')) {
    insights.push('🫁 Solunum şikayeti - Oksijen saturasyonu kontrol edilmeli');
  }
  
  if (fullText.includes('kalp') || fullText.includes('çarpıntı')) {
    insights.push('❤️ Kardiyak şikayet - EKG ve vital bulgular değerlendirilmeli');
  }
  
  // Süre analizi
  if (duration) {
    if (duration.includes('saat') || duration.includes('dakika')) {
      insights.push('⏰ Akut başlangıç - Acil değerlendirme gerekli');
    } else if (duration.includes('gün')) {
      insights.push('📅 Subakut başlangıç - Detaylı anamnez alınmalı');
    } else if (duration.includes('hafta') || duration.includes('ay')) {
      insights.push('📆 Kronik seyir - Uzun süreli takip planlanmalı');
    }
  }
  
  // Hasta profili içgörüleri
  if (patient.age >= 65) {
    insights.push('👴 Yaşlı hasta - Komorbiditeler ve ilaç etkileşimleri dikkate alınmalı');
  }
  
  if (patient.chronicDiseases && patient.chronicDiseases.some(d => d.includes('diyabet'))) {
    insights.push('🍯 Diyabet öyküsü - Kan şekeri kontrolü yapılmalı');
  }
  
  if (patient.chronicDiseases && patient.chronicDiseases.some(d => d.includes('kalp'))) {
    insights.push('❤️ Kardiyak öykü - Kardiyovasküler değerlendirme gerekli');
  }
  
  // Öncelik bazlı içgörüler
  if (priority === 'urgent') {
    insights.push('🚨 Acil durum - Hasta stabilizasyonu öncelikli');
  } else if (priority === 'high') {
    insights.push('⚡ Yüksek öncelik - Hızlı değerlendirme ve müdahale');
  }
  
  return insights;
};

// Doktor için hasta veri analizi
export const analyzePatientData = (patient) => {
  if (!patient) return null;

  const analysis = {
    riskScore: calculateRiskScore(patient),
    familyHistory: analyzeFamilyHistory(patient),
    healthTrends: analyzeHealthTrends(patient),
    medicationAnalysis: analyzeMedicationPatterns(patient),
    diseaseProgression: analyzeDiseaseProgression(patient),
    recommendations: generateDoctorRecommendations(patient),
    alerts: generateHealthAlerts(patient),
    priorityLevel: determinePatientPriority(patient),
    aiInsights: generateDoctorInsights(patient)
  };

  return analysis;
};


// Sağlık trendleri analizi
const analyzeHealthTrends = (patient) => {
  const trends = {
    overall: 'Stabil',
    medications: 'Stabil',
    diseases: 'Stabil',
    recommendations: []
  };

  // İlaç trend analizi
  if (patient.medications && patient.medications.length > 0) {
    const medicationCount = patient.medications.length;
    if (medicationCount >= 8) {
      trends.medications = 'Artış';
      trends.recommendations.push('İlaç sayısında artış tespit edildi - polifarmasi riski');
    } else if (medicationCount >= 5) {
      trends.medications = 'Hafif Artış';
      trends.recommendations.push('İlaç sayısı yüksek - etkileşim kontrolü gerekli');
    }
  }

  // Hastalık trend analizi
  if (patient.chronicDiseases && patient.chronicDiseases.length >= 3) {
    trends.diseases = 'Artış';
    trends.recommendations.push('Çoklu komorbidite - kapsamlı değerlendirme gerekli');
  }

  // Genel trend belirleme
  if (trends.medications === 'Artış' || trends.diseases === 'Artış') {
    trends.overall = 'Kötüleşme';
  } else if (trends.medications === 'Hafif Artış') {
    trends.overall = 'Hafif Kötüleşme';
  }

  return trends;
};

// İlaç analizi
const analyzeMedicationPatterns = (patient) => {
  if (!patient.medications || patient.medications.length === 0) {
    return {
      totalMedications: 0,
      riskLevel: 'Düşük',
      interactions: [],
      recommendations: ['İlaç kullanımı yok']
    };
  }

  const medications = patient.medications;
  const interactions = analyzeDrugInteractions(medications);
  
  let riskLevel = 'Düşük';
  const recommendations = [];

  // İlaç sayısı analizi
  if (medications.length >= 8) {
    riskLevel = 'Yüksek';
    recommendations.push('Polifarmasi riski - ilaç sayısı azaltılmalı');
  } else if (medications.length >= 5) {
    riskLevel = 'Orta';
    recommendations.push('Çoklu ilaç kullanımı - düzenli takip gerekli');
  }

  // Etkileşim analizi
  if (interactions.length > 0) {
    riskLevel = riskLevel === 'Düşük' ? 'Orta' : riskLevel;
    recommendations.push(`${interactions.length} ilaç etkileşimi tespit edildi`);
  }

  // Yaş ve ilaç analizi
  if (patient.age >= 65 && medications.length >= 5) {
    recommendations.push('Yaşlı hasta - ilaç dozları gözden geçirilmeli');
  }

  return {
    totalMedications: medications.length,
    riskLevel,
    interactions,
    recommendations
  };
};

// Hastalık ilerlemesi analizi
const analyzeDiseaseProgression = (patient) => {
  if (!patient.chronicDiseases || patient.chronicDiseases.length === 0) {
    return {
      progression: 'Stabil',
      riskFactors: [],
      recommendations: ['Kronik hastalık yok']
    };
  }

  const diseases = patient.chronicDiseases;
  const riskFactors = [];
  const recommendations = [];

  // Diyabet analizi
  if (diseases.some(d => d.toLowerCase().includes('diyabet'))) {
    riskFactors.push('Diyabet komplikasyon riski');
    recommendations.push('HbA1c ve kan şekeri takibi gerekli');
  }

  // Kalp hastalığı analizi
  if (diseases.some(d => d.toLowerCase().includes('kalp'))) {
    riskFactors.push('Kardiyovasküler risk');
    recommendations.push('EKG ve kardiyak değerlendirme önerilir');
  }

  // Hipertansiyon analizi
  if (diseases.some(d => d.toLowerCase().includes('hipertansiyon'))) {
    riskFactors.push('Hipertansif kriz riski');
    recommendations.push('Kan basıncı takibi ve ilaç uyumu kontrolü');
  }

  // KOAH/Astım analizi
  if (diseases.some(d => d.toLowerCase().includes('koah') || d.toLowerCase().includes('astım'))) {
    riskFactors.push('Solunum yetmezliği riski');
    recommendations.push('Spirometri ve oksijen saturasyonu takibi');
  }

  let progression = 'Stabil';
  if (riskFactors.length >= 3) {
    progression = 'Kötüleşme';
  } else if (riskFactors.length >= 2) {
    progression = 'Hafif Kötüleşme';
  }

  return {
    progression,
    riskFactors,
    recommendations
  };
};

// Doktor önerileri
const generateDoctorRecommendations = (patient) => {
  const recommendations = [];

  // Genel öneriler
  if (patient.age >= 65) {
    recommendations.push({
      type: 'Yaş',
      priority: 'Yüksek',
      message: 'Yaşlı hasta - komprehensif geriatrik değerlendirme önerilir',
      action: 'Geriatrik konsültasyon planla'
    });
  }

  if (patient.chronicDiseases && patient.chronicDiseases.length >= 3) {
    recommendations.push({
      type: 'Komorbidite',
      priority: 'Yüksek',
      message: 'Çoklu komorbidite - multidisipliner yaklaşım gerekli',
      action: 'İlgili branş konsültasyonları planla'
    });
  }

  if (patient.medications && patient.medications.length >= 5) {
    recommendations.push({
      type: 'İlaç',
      priority: 'Orta',
      message: 'Çoklu ilaç kullanımı - etkileşim kontrolü gerekli',
      action: 'İlaç etkileşim analizi yap'
    });
  }

  // Spesifik hastalık önerileri
  if (patient.chronicDiseases) {
    const diseases = patient.chronicDiseases.join(' ').toLowerCase();
    
    if (diseases.includes('diyabet')) {
      recommendations.push({
        type: 'Diyabet',
        priority: 'Yüksek',
        message: 'Diyabet takibi - HbA1c, mikroalbüminüri kontrolü',
        action: 'Endokrinoloji konsültasyonu'
      });
    }

    if (diseases.includes('kalp')) {
      recommendations.push({
        type: 'Kardiyoloji',
        priority: 'Yüksek',
        message: 'Kardiyovasküler değerlendirme gerekli',
        action: 'EKG, ekokardiyografi, stres testi'
      });
    }

    if (diseases.includes('hipertansiyon')) {
      recommendations.push({
        type: 'Hipertansiyon',
        priority: 'Orta',
        message: 'Kan basıncı takibi ve ilaç uyumu',
        action: '24 saatlik tansiyon holter'
      });
    }
  }

  return recommendations;
};

// Sağlık uyarıları
const generateHealthAlerts = (patient) => {
  const alerts = [];

  // Kritik uyarılar
  if (patient.age >= 75 && patient.chronicDiseases && patient.chronicDiseases.length >= 3) {
    alerts.push({
      type: 'Kritik',
      message: 'Yüksek riskli hasta - yakın takip gerekli',
      icon: '⚠️'
    });
  }

  if (patient.medications && patient.medications.length >= 8) {
    alerts.push({
      type: 'Uyarı',
      message: 'Polifarmasi riski - ilaç gözden geçirilmeli',
      icon: '💊'
    });
  }

  // İlaç etkileşim uyarıları
  if (patient.medications && patient.medications.length >= 3) {
    const interactions = analyzeDrugInteractions(patient.medications);
    if (interactions.length > 0) {
      alerts.push({
        type: 'Uyarı',
        message: `${interactions.length} ilaç etkileşimi tespit edildi`,
        icon: '⚡'
      });
    }
  }

  // Alerji uyarıları
  if (patient.allergies && patient.allergies.length > 0) {
    alerts.push({
      type: 'Bilgi',
      message: `${patient.allergies.length} alerji kayıtlı`,
      icon: '🔍'
    });
  }

  return alerts;
};

// Hasta öncelik seviyesi
const determinePatientPriority = (patient) => {
  let priority = 'Normal';
  let score = 0;

  // Yaş faktörü
  if (patient.age >= 75) score += 3;
  else if (patient.age >= 65) score += 2;
  else if (patient.age <= 5) score += 3;

  // Kronik hastalık faktörü
  if (patient.chronicDiseases && patient.chronicDiseases.length >= 3) score += 3;
  else if (patient.chronicDiseases && patient.chronicDiseases.length >= 1) score += 1;

  // İlaç faktörü
  if (patient.medications && patient.medications.length >= 8) score += 3;
  else if (patient.medications && patient.medications.length >= 5) score += 2;

  // Alerji faktörü
  if (patient.allergies && patient.allergies.length > 0) score += 1;

  if (score >= 7) priority = 'Kritik';
  else if (score >= 5) priority = 'Yüksek';
  else if (score >= 3) priority = 'Orta';

  return priority;
};

// Doktor için AI içgörüleri
const generateDoctorInsights = (patient) => {
  const insights = [];

  // Genel hasta profili
  if (patient.age >= 65) {
    insights.push('👴 Yaşlı hasta - komorbiditeler ve ilaç etkileşimleri dikkate alınmalı');
  }

  if (patient.chronicDiseases && patient.chronicDiseases.length > 0) {
    insights.push(`🏥 ${patient.chronicDiseases.length} kronik hastalık - multidisipliner yaklaşım önerilir`);
  }

  if (patient.medications && patient.medications.length > 0) {
    insights.push(`💊 ${patient.medications.length} ilaç kullanımı - etkileşim kontrolü gerekli`);
  }

  // Spesifik hastalık içgörüleri
  if (patient.chronicDiseases) {
    const diseases = patient.chronicDiseases.join(' ').toLowerCase();
    
    if (diseases.includes('diyabet')) {
      insights.push('🍯 Diyabet hastası - kan şekeri takibi ve komplikasyon kontrolü');
    }
    
    if (diseases.includes('kalp')) {
      insights.push('❤️ Kardiyak hasta - EKG ve vital bulgular dikkatle değerlendirilmeli');
    }
    
    if (diseases.includes('hipertansiyon')) {
      insights.push('🩸 Hipertansif hasta - kan basıncı takibi ve hedef değerler');
    }
  }

  // İlaç içgörüleri
  if (patient.medications && patient.medications.length >= 5) {
    insights.push('⚠️ Çoklu ilaç kullanımı - polifarmasi riski ve ilaç uyumu kontrolü');
  }

  return insights;
};