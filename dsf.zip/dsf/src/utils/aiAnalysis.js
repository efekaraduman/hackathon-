// AI Analiz Fonksiyonları

// Hasta için AI özeti oluştur
export const generateAISummary = (patient) => {
  if (!patient) return null;

  // Risk seviyesi hesaplama
  let riskScore = 0;
  let mainProblems = [];
  let recommendations = '';

  // Yaş riski
  if (patient.age > 65) riskScore += 2;
  else if (patient.age > 50) riskScore += 1;

  // Kronik hastalık riski
  riskScore += patient.chronicDiseases.length;
  patient.chronicDiseases.forEach(disease => {
    if (disease.includes('Diyabet') || disease.includes('Hipertansiyon')) {
      mainProblems.push(disease);
    }
  });

  // İlaç sayısı riski
  if (patient.medications.length > 5) riskScore += 2;
  else if (patient.medications.length > 3) riskScore += 1;

  // Alerji riski
  if (patient.allergies.length > 0) {
    riskScore += 1;
    mainProblems.push(`${patient.allergies.length} alerji mevcut`);
  }

  // Laboratuvar değerleri kontrolü
  patient.labResults.forEach(result => {
    if (result.status !== 'Normal') {
      riskScore += 1;
      mainProblems.push(`${result.testName} değeri anormal`);
    }
  });

  // Risk seviyesi belirleme
  let riskLevel = 'Düşük';
  if (riskScore >= 6) riskLevel = 'Yüksek';
  else if (riskScore >= 3) riskLevel = 'Orta';

  // Öneriler oluşturma
  if (riskLevel === 'Yüksek') {
    recommendations = 'Hasta yakın takip altında tutulmalı, düzenli kontroller yapılmalı ve ilaç etkileşimleri sürekli değerlendirilmelidir.';
  } else if (riskLevel === 'Orta') {
    recommendations = 'Hasta düzenli aralıklarla kontrol edilmeli ve ilaç uyumu takip edilmelidir.';
  } else {
    recommendations = 'Hasta rutin takip programında tutulabilir.';
  }

  return {
    riskLevel,
    mainProblems: mainProblems.length > 0 ? mainProblems : ['Özel problem tespit edilmedi'],
    recommendations,
    riskScore
  };
};

// İlaç etkileşimlerini analiz et
export const analyzeDrugInteractions = (medications) => {
  if (!medications || medications.length < 2) return [];

  const interactions = [];
  const drugNames = medications.map(med => med.name.toLowerCase());
  const activeSubstances = medications.map(med => med.activeSubstance.toLowerCase());

  // Bilinen etkileşimler (demo için)
  const knownInteractions = [
    {
      drugs: ['metformin', 'insulin'],
      interaction: 'Metformin ve insulin birlikte kullanıldığında hipoglisemi riski artabilir.'
    },
    {
      drugs: ['lisinopril', 'amlodipin'],
      interaction: 'ACE inhibitörleri ve kalsiyum kanal blokerleri birlikte kullanıldığında hipotansiyon riski artabilir.'
    },
    {
      drugs: ['atorvastatin', 'ramipril'],
      interaction: 'Statin ve ACE inhibitörü birlikte kullanıldığında kas ağrıları görülebilir.'
    },
    {
      drugs: ['enalapril', 'tamsulosin'],
      interaction: 'ACE inhibitörü ve alfa bloker birlikte kullanıldığında baş dönmesi riski artabilir.'
    }
  ];

  // Etkileşim kontrolü
  knownInteractions.forEach(interaction => {
    const hasInteraction = interaction.drugs.every(drug => 
      drugNames.some(name => name.includes(drug)) || 
      activeSubstances.some(substance => substance.includes(drug))
    );
    
    if (hasInteraction) {
      interactions.push(interaction.interaction);
    }
  });

  // Aynı etken madde kontrolü
  const substanceCounts = {};
  activeSubstances.forEach(substance => {
    substanceCounts[substance] = (substanceCounts[substance] || 0) + 1;
  });

  Object.entries(substanceCounts).forEach(([substance, count]) => {
    if (count > 1) {
      interactions.push(`${substance} etken maddesi ${count} farklı ilaçta bulunmaktadır. Doz aşımı riski olabilir.`);
    }
  });

  return interactions;
};

// Hasta verilerini normalize et
export const normalizePatientData = (patient) => {
  if (!patient) return null;

  return {
    ...patient,
    medications: patient.medications.map(med => ({
      ...med,
      normalizedName: med.name.toLowerCase().trim(),
      normalizedSubstance: med.activeSubstance.toLowerCase().trim()
    }))
  };
};

// Hasta karşılaştırması yap
export const comparePatients = (patient1, patient2) => {
  if (!patient1 || !patient2) return null;

  const similarities = [];
  const differences = [];

  // Yaş karşılaştırması
  if (Math.abs(patient1.age - patient2.age) <= 5) {
    similarities.push('Benzer yaş grubu');
  } else {
    differences.push('Farklı yaş grupları');
  }

  // Kronik hastalık karşılaştırması
  const commonDiseases = patient1.chronicDiseases.filter(disease => 
    patient2.chronicDiseases.includes(disease)
  );
  
  if (commonDiseases.length > 0) {
    similarities.push(`Ortak hastalıklar: ${commonDiseases.join(', ')}`);
  }

  // İlaç karşılaştırması
  const commonMedications = patient1.medications.filter(med1 =>
    patient2.medications.some(med2 => 
      med1.activeSubstance.toLowerCase() === med2.activeSubstance.toLowerCase()
    )
  );

  if (commonMedications.length > 0) {
    similarities.push(`${commonMedications.length} ortak ilaç`);
  }

  return {
    similarities,
    differences,
    commonDiseases,
    commonMedications
  };
};

// Hasta risk skorlaması
export const calculateRiskScore = (patient) => {
  if (!patient) return 0;

  let score = 0;

  // Yaş faktörü
  if (patient.age >= 75) score += 3;
  else if (patient.age >= 65) score += 2;
  else if (patient.age >= 50) score += 1;

  // Kronik hastalık faktörü
  patient.chronicDiseases.forEach(disease => {
    if (disease.includes('Diyabet')) score += 2;
    else if (disease.includes('Hipertansiyon')) score += 1;
    else if (disease.includes('Kalp')) score += 2;
    else if (disease.includes('KOAH')) score += 2;
    else score += 1;
  });

  // İlaç sayısı faktörü
  if (patient.medications.length >= 8) score += 3;
  else if (patient.medications.length >= 5) score += 2;
  else if (patient.medications.length >= 3) score += 1;

  // Alerji faktörü
  score += patient.allergies.length;

  // Laboratuvar değerleri
  patient.labResults.forEach(result => {
    if (result.status === 'Yüksek' || result.status === 'Düşük') {
      score += 1;
    }
  });

  return Math.min(score, 10); // Maksimum 10 puan
};

// Hasta kategorilendirme
export const categorizePatient = (patient) => {
  const riskScore = calculateRiskScore(patient);
  
  if (riskScore >= 7) return 'Yüksek Risk';
  if (riskScore >= 4) return 'Orta Risk';
  return 'Düşük Risk';
};
