import React, { useState, useEffect } from 'react';
import { Card, Form, Button, Alert, Modal, Row, Col, Badge } from 'react-bootstrap';
import { 
  Shield, 
  CheckCircle, 
  XCircle, 
  FileText, 
  Eye, 
  Lock,
  AlertTriangle,
  Info
} from 'lucide-react';

const ConsentPanel = ({ patient, onConsentChange }) => {
  const [consentData, setConsentData] = useState({
    dataExtraction: false,
    aiAnalysis: false,
    dataSharing: false,
    auditLogging: true, // Varsayılan olarak true
    anonymization: true // Varsayılan olarak true
  });
  const [showConsentModal, setShowConsentModal] = useState(false);
  const [consentHistory, setConsentHistory] = useState([]);

  useEffect(() => {
    if (patient) {
      loadConsentData();
    }
  }, [patient]);

  const loadConsentData = () => {
    // LocalStorage'dan hasta rızası verilerini yükle
    const savedConsent = localStorage.getItem(`consent_${patient.id}`);
    if (savedConsent) {
      const parsed = JSON.parse(savedConsent);
      setConsentData(parsed.consent);
      setConsentHistory(parsed.history || []);
    }
  };

  const saveConsentData = (newConsent) => {
    const consentRecord = {
      timestamp: new Date().toISOString(),
      consent: newConsent,
      patientId: patient.id,
      changes: Object.keys(newConsent).filter(key => 
        consentData[key] !== newConsent[key]
      )
    };

    const updatedHistory = [consentRecord, ...consentHistory];
    
    localStorage.setItem(`consent_${patient.id}`, JSON.stringify({
      consent: newConsent,
      history: updatedHistory
    }));

    setConsentData(newConsent);
    setConsentHistory(updatedHistory);

    if (onConsentChange) {
      onConsentChange(consentRecord);
    }
  };

  const handleConsentChange = (field, value) => {
    const newConsent = { ...consentData, [field]: value };
    setConsentData(newConsent);
    saveConsentData(newConsent);
  };

  const handleShowConsentModal = () => {
    setShowConsentModal(true);
  };

  const getConsentStatus = () => {
    const total = Object.keys(consentData).length;
    const approved = Object.values(consentData).filter(Boolean).length;
    
    if (approved === total) return { status: 'full', color: 'success', text: 'Tam Rıza' };
    if (approved > total / 2) return { status: 'partial', color: 'warning', text: 'Kısmi Rıza' };
    return { status: 'none', color: 'danger', text: 'Rıza Yok' };
  };

  const handleSaveConsent = () => {
    saveConsentData(consentData);
    alert('Rızalar başarıyla kaydedildi!');
  };

  const handleResetConsent = () => {
    const resetConsent = {
      dataExtraction: false,
      aiAnalysis: false,
      dataSharing: false,
      auditLogging: true,
      anonymization: true
    };
    setConsentData(resetConsent);
    saveConsentData(resetConsent);
    alert('Rızalar sıfırlandı!');
  };

  const getLastUpdate = () => {
    if (consentHistory.length > 0) {
      return new Date(consentHistory[0].timestamp).toLocaleString('tr-TR');
    }
    return 'Henüz güncelleme yok';
  };

  const consentStatus = getConsentStatus();

  if (!patient) return null;

  return (
    <div className="modern-consent-panel">
      {/* Modern Header */}
      <div className="consent-header-modern">
        <div className="consent-header-content">
          <div className="consent-title-section">
            <div className="consent-icon-wrapper">
              <Shield size={28} />
            </div>
            <div className="consent-title-text">
              <h1 className="consent-title-main">Hasta Rızası ve Veri Koruma</h1>
              <p className="consent-title-sub">KVKK ve GDPR uyumlu veri işleme onayları</p>
            </div>
          </div>
          <div className="consent-header-actions">
            <Button 
              variant="outline-primary" 
              size="lg"
              onClick={() => setShowConsentModal(true)}
              className="consent-history-btn"
            >
              <FileText size={20} />
              Rıza Geçmişi
            </Button>
          </div>
        </div>
      </div>

      {/* Modern Content */}
      <div className="consent-content-modern">
        {/* Info Banner */}
        <div className="consent-info-modern">
          <div className="consent-info-icon">
            <Info size={24} />
          </div>
          <div className="consent-info-content">
            <h4>Önemli Bilgilendirme</h4>
            <p>
              Hasta rızası KVKK ve GDPR uyumluluğu için gereklidir. 
              Rıza verilmeyen veriler işlenmeyecektir. Tüm veri işleme 
              faaliyetleri şeffaf ve güvenli bir şekilde gerçekleştirilir.
            </p>
          </div>
        </div>

        {/* Consent Categories */}
        <div className="consent-categories-modern">
          {/* Data Processing Category */}
          <div className="consent-category-modern">
            <div className="consent-category-header-modern">
              <div className="consent-category-title">
                <h3>Veri İşleme Kategorileri</h3>
                <p>Hasta verilerinin işlenmesi için gerekli onaylar</p>
              </div>
              <div className="consent-category-badge">
                <Badge variant="primary" className="consent-badge-modern">KVKK Uyumlu</Badge>
              </div>
            </div>
            
            <div className="consent-options-modern">
              <div className="consent-option-modern">
                <div className="consent-checkbox-modern">
                  <Form.Check
                    type="checkbox"
                    id="dataExtraction"
                    checked={consentData.dataExtraction}
                    onChange={(e) => handleConsentChange('dataExtraction', e.target.checked)}
                    className="consent-checkbox-input"
                  />
                  <div className="consent-checkbox-custom"></div>
                </div>
                <div className="consent-option-content">
                  <h4 className="consent-option-title">Veri Çıkarımı ve İşleme</h4>
                  <p className="consent-option-desc">
                    Hasta verilerinin sistem tarafından güvenli bir şekilde işlenmesi ve analiz edilmesi
                  </p>
                  <div className="consent-option-tags">
                    <span className="consent-tag">Veri İşleme</span>
                    <span className="consent-tag">Analiz</span>
                  </div>
                </div>
              </div>

              <div className="consent-option-modern">
                <div className="consent-checkbox-modern">
                  <Form.Check
                    type="checkbox"
                    id="aiAnalysis"
                    checked={consentData.aiAnalysis}
                    onChange={(e) => handleConsentChange('aiAnalysis', e.target.checked)}
                    className="consent-checkbox-input"
                  />
                  <div className="consent-checkbox-custom"></div>
                </div>
                <div className="consent-option-content">
                  <h4 className="consent-option-title">AI Analiz ve Özetleme</h4>
                  <p className="consent-option-desc">
                    Yapay zeka teknolojileri ile hasta verilerinin gelişmiş analizi ve özetlenmesi
                  </p>
                  <div className="consent-option-tags">
                    <span className="consent-tag">Yapay Zeka</span>
                    <span className="consent-tag">Özetleme</span>
                  </div>
                </div>
              </div>

              <div className="consent-option-modern">
                <div className="consent-checkbox-modern">
                  <Form.Check
                    type="checkbox"
                    id="dataSharing"
                    checked={consentData.dataSharing}
                    onChange={(e) => handleConsentChange('dataSharing', e.target.checked)}
                    className="consent-checkbox-input"
                  />
                  <div className="consent-checkbox-custom"></div>
                </div>
                <div className="consent-option-content">
                  <h4 className="consent-option-title">Veri Paylaşımı</h4>
                  <p className="consent-option-desc">
                    Diğer sağlık kuruluşları ile güvenli veri paylaşımı ve işbirliği
                  </p>
                  <div className="consent-option-tags">
                    <span className="consent-tag">Paylaşım</span>
                    <span className="consent-tag">İşbirliği</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Security Category */}
          <div className="consent-category-modern">
            <div className="consent-category-header-modern">
              <div className="consent-category-title">
                <h3>Güvenlik ve Koruma</h3>
                <p>Sistem güvenliği için zorunlu koruma önlemleri</p>
              </div>
              <div className="consent-category-badge">
                <Badge variant="success" className="consent-badge-modern">Zorunlu</Badge>
              </div>
            </div>
            
            <div className="consent-options-modern">
              <div className="consent-option-modern consent-option-disabled">
                <div className="consent-checkbox-modern">
                  <Form.Check
                    type="checkbox"
                    id="auditLogging"
                    checked={consentData.auditLogging}
                    onChange={(e) => handleConsentChange('auditLogging', e.target.checked)}
                    disabled
                    className="consent-checkbox-input"
                  />
                  <div className="consent-checkbox-custom"></div>
                </div>
                <div className="consent-option-content">
                  <h4 className="consent-option-title">Audit Logging</h4>
                  <p className="consent-option-desc">
                    Sistem güvenliği için zorunlu log kayıtları ve aktivite takibi
                  </p>
                  <div className="consent-option-tags">
                    <span className="consent-tag">Güvenlik</span>
                    <span className="consent-tag">Log Kayıt</span>
                  </div>
                </div>
              </div>

              <div className="consent-option-modern consent-option-disabled">
                <div className="consent-checkbox-modern">
                  <Form.Check
                    type="checkbox"
                    id="anonymization"
                    checked={consentData.anonymization}
                    onChange={(e) => handleConsentChange('anonymization', e.target.checked)}
                    disabled
                    className="consent-checkbox-input"
                  />
                  <div className="consent-checkbox-custom"></div>
                </div>
                <div className="consent-option-content">
                  <h4 className="consent-option-title">Veri Anonimleştirme</h4>
                  <p className="consent-option-desc">
                    Kişisel verilerin korunması için otomatik anonimleştirme işlemleri
                  </p>
                  <div className="consent-option-tags">
                    <span className="consent-tag">Anonimleştirme</span>
                    <span className="consent-tag">Gizlilik</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="consent-actions-modern">
          <Button 
            variant="primary" 
            size="lg"
            onClick={handleSaveConsent}
            className="consent-save-btn-modern"
          >
            <CheckCircle size={20} />
            Rızaları Kaydet
          </Button>
          
          <Button 
            variant="outline-secondary" 
            size="lg"
            onClick={handleResetConsent}
            className="consent-reset-btn-modern"
          >
            <XCircle size={20} />
            Sıfırla
          </Button>
        </div>

        {/* Status Section */}
        <div className="consent-status-modern">
          <div className="consent-status-card">
            <div className="consent-status-item">
              <h5>Son Güncelleme</h5>
              <p>{getLastUpdate()}</p>
            </div>
            <div className="consent-status-item">
              <h5>Durum</h5>
              <Badge variant={getConsentStatus().variant} className="consent-status-badge">
                {getConsentStatus().text}
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Rıza Geçmişi Modal */}
      <Modal show={showConsentModal} onHide={() => setShowConsentModal(false)} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>
            <FileText size={20} style={{ marginRight: '8px' }} />
            Hasta Rızası Geçmişi - {patient.name} {patient.surname}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {consentHistory.length === 0 ? (
            <div className="text-center text-muted py-4">
              <FileText size={48} className="mb-3" />
              <p>Rıza geçmişi bulunamadı</p>
            </div>
          ) : (
            <div className="consent-history">
              {consentHistory.map((record, index) => (
                <Card key={index} className="mb-3">
                  <Card.Body>
                    <Row>
                      <Col md={8}>
                        <h6>Rıza Güncellemesi</h6>
                        <p className="mb-2">
                          <strong>Tarih:</strong> {new Date(record.timestamp).toLocaleString('tr-TR')}
                        </p>
                        {record.changes.length > 0 && (
                          <div>
                            <strong>Değişiklikler:</strong>
                            <ul className="mb-0">
                              {record.changes.map(change => (
                                <li key={change}>
                                  {change === 'dataExtraction' && 'Veri Çıkarımı'}
                                  {change === 'aiAnalysis' && 'AI Analizi'}
                                  {change === 'dataSharing' && 'Veri Paylaşımı'}
                                  {change === 'auditLogging' && 'Audit Logging'}
                                  {change === 'anonymization' && 'Anonimleştirme'}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </Col>
                      <Col md={4}>
                        <div className="consent-status">
                          <h6>Mevcut Durum</h6>
                          {Object.entries(record.consent).map(([key, value]) => (
                            <div key={key} className="d-flex align-items-center mb-1">
                              {value ? (
                                <CheckCircle size={16} className="text-success me-2" />
                              ) : (
                                <XCircle size={16} className="text-danger me-2" />
                              )}
                              <small>
                                {key === 'dataExtraction' && 'Veri Çıkarımı'}
                                {key === 'aiAnalysis' && 'AI Analizi'}
                                {key === 'dataSharing' && 'Veri Paylaşımı'}
                                {key === 'auditLogging' && 'Audit Logging'}
                                {key === 'anonymization' && 'Anonimleştirme'}
                              </small>
                            </div>
                          ))}
                        </div>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
              ))}
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowConsentModal(false)}>
            Kapat
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default ConsentPanel;
