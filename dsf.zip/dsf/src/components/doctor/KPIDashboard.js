import React, { useState, useEffect } from 'react';
import { Card, Row, Col, ProgressBar, Badge, Button, Table, Alert } from 'react-bootstrap';
import { 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  Target,
  Activity,
  Users,
  FileText,
  Brain
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import auditLogger from '../../utils/auditLog';

const KPIDashboard = ({ patients, show, onHide }) => {
  const [kpiData, setKpiData] = useState(null);
  const [timeRange, setTimeRange] = useState('7d'); // 7d, 30d, 90d

  useEffect(() => {
    if (show) {
      calculateKPIs();
    }
  }, [show, patients, timeRange]);

  const calculateKPIs = () => {
    const logs = auditLogger.getLogs();
    const now = new Date();
    const timeFilter = getTimeFilter();
    
    // Zaman filtresi uygula
    const filteredLogs = logs.filter(log => 
      new Date(log.timestamp) >= timeFilter
    );

    // Temel KPI'lar
    const totalPatients = patients.length;
    const totalApprovals = filteredLogs.filter(log => log.action === 'PATIENT_APPROVAL').length;
    const totalMedicationChanges = filteredLogs.filter(log => log.action === 'MEDICATION_CHANGE').length;
    const totalAIAnalyses = filteredLogs.filter(log => log.action === 'AI_ANALYSIS').length;

    // Onay süreleri (simüle edilmiş)
    const approvalTimes = generateApprovalTimes(totalApprovals);
    const avgApprovalTime = approvalTimes.reduce((a, b) => a + b, 0) / approvalTimes.length || 0;

    // Doğruluk oranları (simüle edilmiş)
    const reconciliationAccuracy = calculateReconciliationAccuracy(patients);
    const falsePositiveRate = calculateFalsePositiveRate(filteredLogs);

    // Hasta risk dağılımı
    const riskDistribution = calculateRiskDistribution(patients);

    // Günlük aktivite
    const dailyActivity = calculateDailyActivity(filteredLogs);

    // Doktor performansı
    const doctorPerformance = calculateDoctorPerformance(patients);

    setKpiData({
      totalPatients,
      totalApprovals,
      totalMedicationChanges,
      totalAIAnalyses,
      avgApprovalTime,
      reconciliationAccuracy,
      falsePositiveRate,
      riskDistribution,
      dailyActivity,
      doctorPerformance,
      approvalTimes
    });
  };

  const getTimeFilter = () => {
    const now = new Date();
    switch (timeRange) {
      case '7d': return new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      case '30d': return new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      case '90d': return new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
      default: return new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    }
  };

  const generateApprovalTimes = (count) => {
    // Simüle edilmiş onay süreleri (saniye)
    return Array.from({ length: count }, () => Math.random() * 120 + 10);
  };

  const calculateReconciliationAccuracy = (patients) => {
    // Simüle edilmiş doğruluk oranı
    return 85 + Math.random() * 10; // 85-95% arası
  };

  const calculateFalsePositiveRate = (logs) => {
    // Simüle edilmiş false positive oranı
    return Math.random() * 5; // 0-5% arası
  };

  const calculateRiskDistribution = (patients) => {
    const distribution = { high: 0, medium: 0, low: 0 };
    
    patients.forEach(patient => {
      const riskScore = calculateRiskScore(patient);
      if (riskScore >= 7) distribution.high++;
      else if (riskScore >= 4) distribution.medium++;
      else distribution.low++;
    });

    return distribution;
  };

  const calculateRiskScore = (patient) => {
    let score = 0;
    if (patient.age > 65) score += 2;
    score += patient.chronicDiseases.length;
    if (patient.medications.length > 5) score += 2;
    score += patient.allergies.length;
    return Math.min(score, 10);
  };

  const calculateDailyActivity = (logs) => {
    const activity = {};
    logs.forEach(log => {
      const date = new Date(log.timestamp).toDateString();
      activity[date] = (activity[date] || 0) + 1;
    });

    return Object.entries(activity).map(([date, count]) => ({
      date: new Date(date).toLocaleDateString('tr-TR'),
      count
    })).slice(-7); // Son 7 gün
  };

  const calculateDoctorPerformance = (patients) => {
    const performance = {};
    
    patients.forEach(patient => {
      patient.medications.forEach(med => {
        const doctor = med.prescribingDoctor;
        if (!performance[doctor]) {
          performance[doctor] = { patients: 0, medications: 0, cities: new Set() };
        }
        performance[doctor].patients++;
        performance[doctor].medications++;
        performance[doctor].cities.add(med.city);
      });
    });

    return Object.entries(performance).map(([doctor, data]) => ({
      doctor,
      patients: data.patients,
      medications: data.medications,
      cities: data.cities.size
    }));
  };

  const getKPIStatus = (value, target, higherIsBetter = true) => {
    const percentage = (value / target) * 100;
    if (higherIsBetter) {
      if (percentage >= 100) return { color: 'success', text: 'Hedef Aşıldı' };
      if (percentage >= 80) return { color: 'warning', text: 'Hedefe Yakın' };
      return { color: 'danger', text: 'Hedefin Altında' };
    } else {
      if (percentage <= 100) return { color: 'success', text: 'Hedef Aşıldı' };
      if (percentage <= 120) return { color: 'warning', text: 'Hedefe Yakın' };
      return { color: 'danger', text: 'Hedefin Üstünde' };
    }
  };

  if (!show || !kpiData) return null;

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  return (
    <div className="kpi-dashboard">
      {/* Header */}
      <Card className="mb-4">
        <Card.Header className="bg-primary text-white">
          <Row className="align-items-center">
            <Col>
              <h5 className="mb-0">
                <Target size={20} style={{ marginRight: '8px' }} />
                KPI Dashboard
              </h5>
            </Col>
            <Col xs="auto">
              <div className="btn-group" role="group">
                <Button
                  variant={timeRange === '7d' ? 'light' : 'outline-light'}
                  size="sm"
                  onClick={() => setTimeRange('7d')}
                >
                  7 Gün
                </Button>
                <Button
                  variant={timeRange === '30d' ? 'light' : 'outline-light'}
                  size="sm"
                  onClick={() => setTimeRange('30d')}
                >
                  30 Gün
                </Button>
                <Button
                  variant={timeRange === '90d' ? 'light' : 'outline-light'}
                  size="sm"
                  onClick={() => setTimeRange('90d')}
                >
                  90 Gün
                </Button>
              </div>
            </Col>
          </Row>
        </Card.Header>
      </Card>

      {/* Ana KPI'lar */}
      <Row className="mb-4">
        <Col md={3}>
          <Card className="text-center">
            <Card.Body>
              <div className="d-flex align-items-center justify-content-center mb-2">
                <CheckCircle size={24} className="text-success me-2" />
                <h4 className="mb-0">{kpiData.reconciliationAccuracy.toFixed(1)}%</h4>
              </div>
              <h6 className="text-muted">Reconciliation Doğruluğu</h6>
              <Badge bg={getKPIStatus(kpiData.reconciliationAccuracy, 85).color}>
                {getKPIStatus(kpiData.reconciliationAccuracy, 85).text}
              </Badge>
              <div className="mt-2">
                <small className="text-muted">Hedef: ≥85%</small>
              </div>
            </Card.Body>
          </Card>
        </Col>
        <Col md={3}>
          <Card className="text-center">
            <Card.Body>
              <div className="d-flex align-items-center justify-content-center mb-2">
                <Clock size={24} className="text-primary me-2" />
                <h4 className="mb-0">{kpiData.avgApprovalTime.toFixed(0)}s</h4>
              </div>
              <h6 className="text-muted">Ortalama Onay Süresi</h6>
              <Badge bg={getKPIStatus(kpiData.avgApprovalTime, 60, false).color}>
                {getKPIStatus(kpiData.avgApprovalTime, 60, false).text}
              </Badge>
              <div className="mt-2">
                <small className="text-muted">Hedef: ≤60s</small>
              </div>
            </Card.Body>
          </Card>
        </Col>
        <Col md={3}>
          <Card className="text-center">
            <Card.Body>
              <div className="d-flex align-items-center justify-content-center mb-2">
                <AlertTriangle size={24} className="text-warning me-2" />
                <h4 className="mb-0">{kpiData.falsePositiveRate.toFixed(1)}%</h4>
              </div>
              <h6 className="text-muted">False Positive Oranı</h6>
              <Badge bg={getKPIStatus(kpiData.falsePositiveRate, 5, false).color}>
                {getKPIStatus(kpiData.falsePositiveRate, 5, false).text}
              </Badge>
              <div className="mt-2">
                <small className="text-muted">Hedef: ≤5%</small>
              </div>
            </Card.Body>
          </Card>
        </Col>
        <Col md={3}>
          <Card className="text-center">
            <Card.Body>
              <div className="d-flex align-items-center justify-content-center mb-2">
                <Users size={24} className="text-info me-2" />
                <h4 className="mb-0">{kpiData.totalPatients}</h4>
              </div>
              <h6 className="text-muted">Toplam Hasta</h6>
              <div className="mt-2">
                <small className="text-muted">Aktif hasta sayısı</small>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* Grafikler */}
      <Row className="mb-4">
        <Col md={6}>
          <Card>
            <Card.Header>
              <h6 className="mb-0">Hasta Risk Dağılımı</h6>
            </Card.Header>
            <Card.Body>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={[
                      { name: 'Yüksek Risk', value: kpiData.riskDistribution.high, color: '#dc3545' },
                      { name: 'Orta Risk', value: kpiData.riskDistribution.medium, color: '#ffc107' },
                      { name: 'Düşük Risk', value: kpiData.riskDistribution.low, color: '#28a745' }
                    ]}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {[
                      { name: 'Yüksek Risk', value: kpiData.riskDistribution.high, color: '#dc3545' },
                      { name: 'Orta Risk', value: kpiData.riskDistribution.medium, color: '#ffc107' },
                      { name: 'Düşük Risk', value: kpiData.riskDistribution.low, color: '#28a745' }
                    ].map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </Card.Body>
          </Card>
        </Col>
        <Col md={6}>
          <Card>
            <Card.Header>
              <h6 className="mb-0">Günlük Aktivite</h6>
            </Card.Header>
            <Card.Body>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={kpiData.dailyActivity}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* Doktor Performansı */}
      <Card className="mb-4">
        <Card.Header>
          <h6 className="mb-0">Doktor Performansı</h6>
        </Card.Header>
        <Card.Body>
          <div className="table-responsive">
            <Table striped hover>
              <thead>
                <tr>
                  <th>Doktor</th>
                  <th>Hasta Sayısı</th>
                  <th>İlaç Sayısı</th>
                  <th>Şehir Sayısı</th>
                  <th>Performans</th>
                </tr>
              </thead>
              <tbody>
                {kpiData.doctorPerformance.map((perf, index) => (
                  <tr key={index}>
                    <td>{perf.doctor}</td>
                    <td>{perf.patients}</td>
                    <td>{perf.medications}</td>
                    <td>{perf.cities}</td>
                    <td>
                      <ProgressBar 
                        now={(perf.patients / Math.max(...kpiData.doctorPerformance.map(p => p.patients))) * 100}
                        variant="success"
                        style={{ width: '100px' }}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </Card.Body>
      </Card>

      {/* Özet */}
      <Alert variant="info">
        <Activity size={16} style={{ marginRight: '8px' }} />
        <strong>KPI Özeti:</strong> Sistem performansı genel olarak hedeflere uygun seviyededir. 
        Reconciliation doğruluğu %{kpiData.reconciliationAccuracy.toFixed(1)}, 
        ortalama onay süresi {kpiData.avgApprovalTime.toFixed(0)} saniye, 
        false positive oranı %{kpiData.falsePositiveRate.toFixed(1)} olarak ölçülmüştür.
      </Alert>
    </div>
  );
};

export default KPIDashboard;
