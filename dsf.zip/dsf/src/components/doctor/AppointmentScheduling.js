import React, { useState, useEffect } from 'react';
import { Calendar, Clock, User, MapPin, Phone, Plus, Edit, Trash2, CheckCircle, XCircle } from 'lucide-react';

const AppointmentScheduling = ({ patient, onAppointmentUpdate }) => {
  const [appointments, setAppointments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingAppointment, setEditingAppointment] = useState(null);
  const [formData, setFormData] = useState({
    date: '',
    time: '',
    type: 'consultation',
    doctor: '',
    notes: '',
    status: 'scheduled'
  });

  // Örnek randevu verileri
  useEffect(() => {
    const sampleAppointments = [
      {
        id: 1,
        date: '2024-01-15',
        time: '10:00',
        type: 'consultation',
        doctor: 'Dr. Ahmet Yılmaz',
        notes: 'Kontrol muayenesi',
        status: 'completed',
        patientId: patient?.id
      },
      {
        id: 2,
        date: '2024-01-20',
        time: '14:30',
        type: 'follow-up',
        doctor: 'Dr. Mehmet Kaya',
        notes: 'Takip randevusu',
        status: 'scheduled',
        patientId: patient?.id
      },
      {
        id: 3,
        date: '2024-01-25',
        time: '09:15',
        type: 'emergency',
        doctor: 'Dr. Ayşe Demir',
        notes: 'Acil durum',
        status: 'cancelled',
        patientId: patient?.id
      }
    ];
    setAppointments(sampleAppointments);
  }, [patient]);

  const appointmentTypes = [
    { value: 'consultation', label: 'Konsültasyon', color: 'primary' },
    { value: 'follow-up', label: 'Takip', color: 'success' },
    { value: 'emergency', label: 'Acil', color: 'danger' },
    { value: 'surgery', label: 'Ameliyat', color: 'warning' },
    { value: 'checkup', label: 'Kontrol', color: 'info' }
  ];

  const statusOptions = [
    { value: 'scheduled', label: 'Planlandı', color: 'primary' },
    { value: 'completed', label: 'Tamamlandı', color: 'success' },
    { value: 'cancelled', label: 'İptal', color: 'danger' },
    { value: 'rescheduled', label: 'Ertelendi', color: 'warning' }
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (editingAppointment) {
      // Güncelleme
      const updatedAppointments = appointments.map(apt => 
        apt.id === editingAppointment.id 
          ? { ...apt, ...formData }
          : apt
      );
      setAppointments(updatedAppointments);
    } else {
      // Yeni ekleme
      const newAppointment = {
        id: Date.now(),
        ...formData,
        patientId: patient?.id
      };
      setAppointments([...appointments, newAppointment]);
    }

    setShowModal(false);
    setEditingAppointment(null);
    setFormData({
      date: '',
      time: '',
      type: 'consultation',
      doctor: '',
      notes: '',
      status: 'scheduled'
    });
  };

  const handleEdit = (appointment) => {
    setEditingAppointment(appointment);
    setFormData(appointment);
    setShowModal(true);
  };

  const handleDelete = (appointmentId) => {
    if (window.confirm('Bu randevuyu silmek istediğinizden emin misiniz?')) {
      setAppointments(appointments.filter(apt => apt.id !== appointmentId));
    }
  };

  const getStatusColor = (status) => {
    const statusMap = {
      scheduled: 'gov-badge-primary',
      completed: 'gov-badge-success',
      cancelled: 'gov-badge-danger',
      rescheduled: 'gov-badge-warning'
    };
    return statusMap[status] || 'gov-badge-secondary';
  };

  const getTypeColor = (type) => {
    const typeMap = {
      consultation: 'gov-badge-primary',
      'follow-up': 'gov-badge-success',
      emergency: 'gov-badge-danger',
      surgery: 'gov-badge-warning',
      checkup: 'gov-badge-info'
    };
    return typeMap[type] || 'gov-badge-secondary';
  };

  const getTypeLabel = (type) => {
    const typeObj = appointmentTypes.find(t => t.value === type);
    return typeObj ? typeObj.label : type;
  };

  const getStatusLabel = (status) => {
    const statusObj = statusOptions.find(s => s.value === status);
    return statusObj ? statusObj.label : status;
  };

  const upcomingAppointments = appointments.filter(apt => 
    apt.status === 'scheduled' && new Date(apt.date) >= new Date()
  );

  const completedAppointments = appointments.filter(apt => 
    apt.status === 'completed'
  );

  return (
    <div className="gov-card">
      <div className="gov-card-header">
        <div className="d-flex align-items-center justify-content-between">
          <h6 className="mb-0">
            <Calendar size={16} style={{ marginRight: '5px' }} />
            Randevu Yönetimi
          </h6>
          <button
            className="gov-btn gov-btn-sm gov-btn-primary"
            onClick={() => setShowModal(true)}
          >
            <Plus size={14} />
            Yeni Randevu
          </button>
        </div>
      </div>
      <div className="gov-card-body">
        {/* İstatistikler */}
        <div className="gov-stats mb-4">
          <div className="gov-stat">
            <div className="gov-stat-value">{appointments.length}</div>
            <div className="gov-stat-label">Toplam Randevu</div>
          </div>
          <div className="gov-stat">
            <div className="gov-stat-value">{upcomingAppointments.length}</div>
            <div className="gov-stat-label">Yaklaşan</div>
          </div>
          <div className="gov-stat">
            <div className="gov-stat-value">{completedAppointments.length}</div>
            <div className="gov-stat-label">Tamamlanan</div>
          </div>
          <div className="gov-stat">
            <div className="gov-stat-value">
              {appointments.filter(apt => apt.status === 'cancelled').length}
            </div>
            <div className="gov-stat-label">İptal</div>
          </div>
        </div>

        {/* Randevu Listesi */}
        <div className="table-responsive">
          <table className="gov-table">
            <thead>
              <tr>
                <th>Tarih</th>
                <th>Saat</th>
                <th>Tip</th>
                <th>Doktor</th>
                <th>Durum</th>
                <th>Notlar</th>
                <th>İşlemler</th>
              </tr>
            </thead>
            <tbody>
              {appointments.map(appointment => (
                <tr key={appointment.id}>
                  <td>
                    {new Date(appointment.date).toLocaleDateString('tr-TR')}
                  </td>
                  <td>
                    <Clock size={14} style={{ marginRight: '5px' }} />
                    {appointment.time}
                  </td>
                  <td>
                    <span className={`gov-badge ${getTypeColor(appointment.type)}`}>
                      {getTypeLabel(appointment.type)}
                    </span>
                  </td>
                  <td>
                    <User size={14} style={{ marginRight: '5px' }} />
                    {appointment.doctor}
                  </td>
                  <td>
                    <span className={`gov-badge ${getStatusColor(appointment.status)}`}>
                      {getStatusLabel(appointment.status)}
                    </span>
                  </td>
                  <td>{appointment.notes}</td>
                  <td>
                    <div className="d-flex gap-1">
                      <button
                        className="gov-btn gov-btn-sm gov-btn-outline-primary"
                        onClick={() => handleEdit(appointment)}
                        title="Düzenle"
                      >
                        <Edit size={12} />
                      </button>
                      <button
                        className="gov-btn gov-btn-sm gov-btn-outline-danger"
                        onClick={() => handleDelete(appointment.id)}
                        title="Sil"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {appointments.length === 0 && (
          <div className="text-center py-4">
            <Calendar size={48} className="mb-3 text-muted" />
            <p className="text-muted">Henüz randevu bulunmuyor</p>
            <button
              className="gov-btn gov-btn-primary"
              onClick={() => setShowModal(true)}
            >
              <Plus size={16} />
              İlk Randevuyu Ekle
            </button>
          </div>
        )}
      </div>

      {/* Randevu Ekleme/Düzenleme Modal */}
      {showModal && (
        <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  {editingAppointment ? 'Randevu Düzenle' : 'Yeni Randevu'}
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => {
                    setShowModal(false);
                    setEditingAppointment(null);
                    setFormData({
                      date: '',
                      time: '',
                      type: 'consultation',
                      doctor: '',
                      notes: '',
                      status: 'scheduled'
                    });
                  }}
                ></button>
              </div>
              <form onSubmit={handleSubmit}>
                <div className="modal-body">
                  <div className="row">
                    <div className="col-md-6">
                      <div className="gov-form-group">
                        <label className="gov-label">Tarih</label>
                        <input
                          type="date"
                          className="gov-input"
                          value={formData.date}
                          onChange={(e) => setFormData({...formData, date: e.target.value})}
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="gov-form-group">
                        <label className="gov-label">Saat</label>
                        <input
                          type="time"
                          className="gov-input"
                          value={formData.time}
                          onChange={(e) => setFormData({...formData, time: e.target.value})}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="row">
                    <div className="col-md-6">
                      <div className="gov-form-group">
                        <label className="gov-label">Randevu Tipi</label>
                        <select
                          className="gov-select"
                          value={formData.type}
                          onChange={(e) => setFormData({...formData, type: e.target.value})}
                        >
                          {appointmentTypes.map(type => (
                            <option key={type.value} value={type.value}>
                              {type.label}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="gov-form-group">
                        <label className="gov-label">Durum</label>
                        <select
                          className="gov-select"
                          value={formData.status}
                          onChange={(e) => setFormData({...formData, status: e.target.value})}
                        >
                          {statusOptions.map(status => (
                            <option key={status.value} value={status.value}>
                              {status.label}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>

                  <div className="gov-form-group">
                    <label className="gov-label">Doktor</label>
                    <input
                      type="text"
                      className="gov-input"
                      value={formData.doctor}
                      onChange={(e) => setFormData({...formData, doctor: e.target.value})}
                      placeholder="Doktor adı"
                      required
                    />
                  </div>

                  <div className="gov-form-group">
                    <label className="gov-label">Notlar</label>
                    <textarea
                      className="gov-input"
                      rows="3"
                      value={formData.notes}
                      onChange={(e) => setFormData({...formData, notes: e.target.value})}
                      placeholder="Randevu notları..."
                    />
                  </div>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="gov-btn gov-btn-secondary"
                    onClick={() => {
                      setShowModal(false);
                      setEditingAppointment(null);
                    }}
                  >
                    İptal
                  </button>
                  <button type="submit" className="gov-btn gov-btn-primary">
                    {editingAppointment ? 'Güncelle' : 'Kaydet'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AppointmentScheduling;
