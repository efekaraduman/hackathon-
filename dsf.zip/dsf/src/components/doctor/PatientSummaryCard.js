import React from 'react';
import { Card, Row, Col, Badge, Alert } from 'react-bootstrap';
import { 
  User, 
  AlertTriangle, 
  Heart, 
  Activity, 
  Clock,
  Shield,
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { calculateRiskScore, categorizePatient } from '../../utils/aiAnalysis';

const PatientSummaryCard = ({ patient, aiSummary }) => {
  if (!patient) return null;

  const riskScore = calculateRiskScore(patient);
  const riskCategory = categorizePatient(patient);
  const criticalAlerts = [];
  const warnings = [];

  // Kritik uyarıları tespit et
  patient.labResults.forEach(result => {
    if (result.status === 'Yüksek' && (result.testName.includes('HbA1c') || result.testName.includes('Kreatinin'))) {
      criticalAlerts.push(`${result.testName}: ${result.value} ${result.unit} (${result.status})`);
    }
  });

  // İlaç uyarıları
  if (patient.medications.length > 6) {
    warnings.push(`${patient.medications.length} aktif ilaç - etkileşim riski`);
  }

  // Alerji uyarıları
  if (patient.allergies.length > 0) {
    warnings.push(`${patient.allergies.length} alerji mevcut`);
  }

  // Yaş uyarıları
  if (patient.age > 70) {
    warnings.push('İleri yaş - yakın takip gerekli');
  }

  const getRiskColor = (category) => {
    switch (category) {
      case 'Yüksek Risk': return 'danger';
      case 'Orta Risk': return 'warning';
      default: return 'success';
    }
  };

  const getRiskIcon = (category) => {
    switch (category) {
      case 'Yüksek Risk': return AlertTriangle;
      case 'Orta Risk': return AlertCircle;
      default: return Shield;
    }
  };

  const RiskIcon = getRiskIcon(riskCategory);

  return (
    <Card className="mb-4 patient-summary-card glass-card hover-lift">
      <Card.Header className={`bg-${getRiskColor(riskCategory)} text-white`}>
        <Row className="align-items-center">
          <Col>
            <h5 className="mb-0">
              <User size={20} style={{ marginRight: '8px' }} />
              {patient.name} {patient.surname} - Hasta Özeti
            </h5>
          </Col>
          <Col xs="auto">
            <Badge bg="light" text="dark" className="fs-6">
              <RiskIcon size={16} style={{ marginRight: '4px' }} />
              {riskCategory} ({riskScore}/10)
            </Badge>
          </Col>
        </Row>
      </Card.Header>
      
      <Card.Body>
        <Row>
          {/* Temel Bilgiler */}
          <Col md={3}>
            <div className="summary-section">
              <h6 className="text-muted mb-2">Temel Bilgiler</h6>
              <div className="d-flex align-items-center mb-1">
                <Clock size={14} className="me-2" />
                <span><strong>Yaş:</strong> {patient.age}</span>
              </div>
              <div className="d-flex align-items-center mb-1">
                <User size={14} className="me-2" />
                <span><strong>Cinsiyet:</strong> {patient.gender}</span>
              </div>
              <div className="d-flex align-items-center">
                <Activity size={14} className="me-2" />
                <span><strong>TC:</strong> {patient.tcNo}</span>
              </div>
            </div>
          </Col>

          {/* Kronik Hastalıklar */}
          <Col md={3}>
            <div className="summary-section">
              <h6 className="text-muted mb-2">Kronik Hastalıklar</h6>
              <div className="disease-badges">
                {patient.chronicDiseases.map(disease => (
                  <Badge 
                    key={disease} 
                    bg={disease.includes('Diyabet') || disease.includes('Hipertansiyon') ? 'danger' : 'secondary'}
                    className="me-1 mb-1"
                  >
                    {disease}
                  </Badge>
                ))}
              </div>
            </div>
          </Col>

          {/* Alerjiler */}
          <Col md={3}>
            <div className="summary-section">
              <h6 className="text-muted mb-2">Alerjiler</h6>
              {patient.allergies.length === 0 ? (
                <Badge bg="success">Alerji yok</Badge>
              ) : (
                <div className="allergy-badges">
                  {patient.allergies.map(allergy => (
                    <Badge key={allergy} bg="danger" className="me-1 mb-1">
                      {allergy}
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          </Col>

          {/* İstatistikler */}
          <Col md={3}>
            <div className="summary-section">
              <h6 className="text-muted mb-2">İstatistikler</h6>
              <div className="d-flex align-items-center mb-1">
                <TrendingUp size={14} className="me-2" />
                <span><strong>İlaç:</strong> {patient.medications.length}</span>
              </div>
              <div className="d-flex align-items-center mb-1">
                <Heart size={14} className="me-2" />
                <span><strong>Operasyon:</strong> {patient.surgeries.length}</span>
              </div>
              <div className="d-flex align-items-center">
                <Activity size={14} className="me-2" />
                <span><strong>Randevu:</strong> {patient.appointments.length}</span>
              </div>
            </div>
          </Col>
        </Row>

        {/* Kritik Uyarılar */}
        {criticalAlerts.length > 0 && (
          <Alert variant="danger" className="mt-3">
            <AlertTriangle size={16} style={{ marginRight: '8px' }} />
            <strong>Kritik Uyarılar:</strong>
            <ul className="mb-0 mt-2">
              {criticalAlerts.map((alert, index) => (
                <li key={index}>{alert}</li>
              ))}
            </ul>
          </Alert>
        )}

        {/* Genel Uyarılar */}
        {warnings.length > 0 && (
          <Alert variant="warning" className="mt-2">
            <AlertCircle size={16} style={{ marginRight: '8px' }} />
            <strong>Dikkat Edilmesi Gerekenler:</strong>
            <ul className="mb-0 mt-2">
              {warnings.map((warning, index) => (
                <li key={index}>{warning}</li>
              ))}
            </ul>
          </Alert>
        )}

        {/* AI Özet */}
        {aiSummary && (
          <Alert variant="info" className="mt-2">
            <Shield size={16} style={{ marginRight: '8px' }} />
            <strong>AI Analiz:</strong> {aiSummary.recommendations}
          </Alert>
        )}
      </Card.Body>
    </Card>
  );
};

export default PatientSummaryCard;
