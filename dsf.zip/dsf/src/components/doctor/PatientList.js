import React, { useState, useMemo } from 'react';
import { Users, Search, Eye } from 'lucide-react';

const PatientList = ({ patients, selectedPatient, onPatientSelect }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDisease, setSelectedDisease] = useState('all');

  // Hastalık listesini oluştur
  const diseases = useMemo(() => {
    const diseaseSet = new Set();
    patients.forEach(patient => {
      if (patient.chronicDiseases) {
        patient.chronicDiseases.forEach(disease => diseaseSet.add(disease));
      }
    });
    return Array.from(diseaseSet);
  }, [patients]);

  // Filtrelenmiş hasta listesi
  const filteredPatients = useMemo(() => {
    return patients.filter(patient => {
      // Güvenli arama - undefined kontrolü
      const name = patient.name || '';
      const surname = patient.surname || '';
      const tc = patient.tc || '';
      
      const matchesSearch = name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           surname.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           tc.includes(searchTerm);
      
      const matchesDisease = selectedDisease === 'all' || 
                            (patient.chronicDiseases && patient.chronicDiseases.includes(selectedDisease));
      
      return matchesSearch && matchesDisease;
    });
  }, [patients, searchTerm, selectedDisease]);

  return (
    <div className="minimal-card">
      <div className="minimal-card-header">
        <div className="d-flex justify-content-between align-items-center">
          <h5 className="minimal-card-title">
            <Users size={20} />
            Hasta Listesi
          </h5>
          <span className="minimal-badge minimal-badge-primary">
            {filteredPatients.length} Hasta
          </span>
        </div>
      </div>
      
      <div className="minimal-card-body">
        {/* Arama ve Filtreler */}
        <div className="minimal-search">
          <Search size={20} className="minimal-search-icon" />
          <input
            type="text"
            className="minimal-search-input"
            placeholder="Hasta ara..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="minimal-filters">
          <button
            className={`minimal-filter-tag ${selectedDisease === 'all' ? 'active' : ''}`}
            onClick={() => setSelectedDisease('all')}
          >
            Tümü
          </button>
          {diseases.map((disease) => (
            <button
              key={disease}
              className={`minimal-filter-tag ${selectedDisease === disease ? 'active' : ''}`}
              onClick={() => setSelectedDisease(disease)}
            >
              {disease}
            </button>
          ))}
        </div>

        {/* Hasta Kartları */}
        <div className="row">
          {filteredPatients.map((patient) => (
            <div key={patient.id} className="col-md-6 col-lg-4 mb-3">
              <div 
                className={`minimal-patient-card ${selectedPatient?.id === patient.id ? 'selected' : ''}`}
                onClick={() => onPatientSelect(patient)}
                style={selectedPatient?.id === patient.id ? { borderColor: 'var(--primary)', backgroundColor: 'var(--gray-50)' } : {}}
              >
                <div className="minimal-patient-name">
                  {patient.name} {patient.surname}
                </div>
                <div className="minimal-patient-info">
                  <div>Yaş: {patient.age}</div>
                  <div>TC: {patient.tc}</div>
                  <div>Telefon: {patient.phone}</div>
                </div>
                <div className="minimal-patient-diseases">
                  {patient.chronicDiseases && patient.chronicDiseases.map((disease, index) => (
                    <span key={index} className="minimal-badge minimal-badge-warning">
                      {disease}
                    </span>
                  ))}
                </div>
                <button 
                  className="minimal-btn minimal-btn-sm minimal-btn-secondary mt-2"
                  onClick={(e) => {
                    e.stopPropagation();
                    onPatientSelect(patient);
                  }}
                >
                  <Eye size={16} />
                  Detayları Görüntüle
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredPatients.length === 0 && (
          <div className="text-center py-5">
            <Users size={48} style={{ color: 'var(--gray-400)', marginBottom: '16px' }} />
            <p style={{ color: 'var(--gray-500)', margin: 0 }}>
              {searchTerm || selectedDisease !== 'all' 
                ? 'Arama kriterlerinize uygun hasta bulunamadı.' 
                : 'Henüz hasta kaydı bulunmuyor.'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PatientList;