import React from 'react';
import { Card } from 'react-bootstrap';
import { Calendar, Pill, AlertTriangle, Activity, MapPin } from 'lucide-react';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';

const Timeline = ({ patient }) => {
  if (!patient) return null;

  // Tüm olayları birleştir ve tarihe göre sırala
  const allEvents = [
    ...patient.medications.map(med => ({
      ...med,
      type: 'medication',
      date: med.startDate,
      title: med.name,
      description: `${med.dosage} - ${med.prescribingDoctor}`,
      location: `${med.hospital}, ${med.city}`,
      icon: Pill
    })),
    ...patient.appointments.map(app => ({
      ...app,
      type: 'appointment',
      date: app.date,
      title: `${app.department} - ${app.doctor}`,
      description: app.notes,
      location: app.hospital,
      icon: Calendar
    })),
    ...patient.surgeries.map(surgery => ({
      ...surgery,
      type: 'surgery',
      date: surgery.date,
      title: surgery.name,
      description: surgery.notes,
      location: `${surgery.hospital} - ${surgery.doctor}`,
      icon: Activity
    }))
  ].sort((a, b) => new Date(b.date) - new Date(a.date));

  const getEventColor = (type) => {
    switch (type) {
      case 'medication': return '#28a745';
      case 'appointment': return '#ffc107';
      case 'surgery': return '#6f42c1';
      default: return '#007bff';
    }
  };

  const getEventIcon = (type) => {
    switch (type) {
      case 'medication': return Pill;
      case 'appointment': return Calendar;
      case 'surgery': return Activity;
      default: return Activity;
    }
  };

  return (
    <Card>
      <Card.Header className="bg-primary text-white">
        <h6 className="mb-0">
          <Calendar size={16} style={{ marginRight: '5px' }} />
          Hasta Timeline
        </h6>
      </Card.Header>
      <Card.Body>
        {allEvents.length === 0 ? (
          <div className="text-center text-muted py-4">
            <Calendar size={48} className="mb-3" />
            <p>Timeline verisi bulunamadı</p>
          </div>
        ) : (
          <div className="timeline">
            {allEvents.map((event, index) => {
              const IconComponent = getEventIcon(event.type);
              const eventColor = getEventColor(event.type);
              
              return (
                <div key={`${event.type}-${event.id}`} className="timeline-item">
                  <div className="d-flex align-items-start">
                    <div 
                      className="timeline-icon me-3"
                      style={{ 
                        backgroundColor: eventColor,
                        color: 'white',
                        borderRadius: '50%',
                        width: '40px',
                        height: '40px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexShrink: 0
                      }}
                    >
                      <IconComponent size={20} />
                    </div>
                    
                    <div className="flex-grow-1">
                      <div className="d-flex justify-content-between align-items-start mb-1">
                        <h6 className="mb-1" style={{ color: eventColor }}>
                          {event.title}
                        </h6>
                        <small className="text-muted">
                          {format(new Date(event.date), 'dd MMM yyyy', { locale: tr })}
                        </small>
                      </div>
                      
                      <p className="mb-1 text-muted">{event.description}</p>
                      
                      <div className="d-flex align-items-center text-muted">
                        <MapPin size={14} style={{ marginRight: '4px' }} />
                        <small>{event.location}</small>
                      </div>
                      
                      {event.type === 'medication' && (
                        <div className="mt-2">
                          <small className="badge bg-light text-dark">
                            Etken Madde: {event.activeSubstance}
                          </small>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {index < allEvents.length - 1 && (
                    <div 
                      className="timeline-line"
                      style={{
                        position: 'absolute',
                        left: '19px',
                        top: '40px',
                        bottom: '-20px',
                        width: '2px',
                        backgroundColor: '#dee2e6'
                      }}
                    />
                  )}
                </div>
              );
            })}
          </div>
        )}
      </Card.Body>
    </Card>
  );
};

export default Timeline;
