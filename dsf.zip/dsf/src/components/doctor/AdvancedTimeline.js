import React, { useState } from 'react';
import { Card, Row, Col, Badge, Button, Modal, Alert } from 'react-bootstrap';
import { 
  Calendar, 
  Pill, 
  AlertTriangle, 
  Activity, 
  MapPin, 
  TrendingUp,
  TrendingDown,
  Minus,
  Eye,
  FileText,
  Heart
} from 'lucide-react';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';

const AdvancedTimeline = ({ patient }) => {
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [showEventModal, setShowEventModal] = useState(false);
  const [filterType, setFilterType] = useState('all');

  if (!patient) return null;

  // Tüm olayları birleştir ve tarihe göre sırala
  const allEvents = [
    // İlaçlar
    ...patient.medications.map(med => ({
      ...med,
      type: 'medication',
      date: med.startDate,
      title: med.name,
      description: `${med.dosage} - ${med.prescribingDoctor}`,
      location: `${med.hospital}, ${med.city}`,
      icon: Pill,
      category: 'medication',
      priority: 'medium',
      tags: ['ilaç', 'reçete'],
      details: {
        activeSubstance: med.activeSubstance,
        dosage: med.dosage,
        prescribingDoctor: med.prescribingDoctor,
        hospital: med.hospital,
        city: med.city
      }
    })),
    
    // Randevular
    ...patient.appointments.map(app => ({
      ...app,
      type: 'appointment',
      date: app.date,
      title: `${app.department} - ${app.doctor}`,
      description: app.notes,
      location: app.hospital,
      icon: Calendar,
      category: 'appointment',
      priority: 'high',
      tags: ['randevu', 'kontrol'],
      details: {
        department: app.department,
        doctor: app.doctor,
        hospital: app.hospital,
        notes: app.notes
      }
    })),
    
    // Operasyonlar
    ...patient.surgeries.map(surgery => ({
      ...surgery,
      type: 'surgery',
      date: surgery.date,
      title: surgery.name,
      description: surgery.notes,
      location: `${surgery.hospital} - ${surgery.doctor}`,
      icon: Activity,
      category: 'surgery',
      priority: 'high',
      tags: ['operasyon', 'cerrahi'],
      details: {
        name: surgery.name,
        hospital: surgery.hospital,
        doctor: surgery.doctor,
        notes: surgery.notes
      }
    })),
    
    // Laboratuvar sonuçları (anormal olanlar)
    ...patient.labResults
      .filter(result => result.status !== 'Normal')
      .map(result => ({
        ...result,
        type: 'lab_result',
        date: result.date,
        title: `${result.testName} - ${result.status}`,
        description: `Değer: ${result.value} ${result.unit} (Normal: ${result.normalRange})`,
        location: 'Laboratuvar',
        icon: TrendingUp,
        category: 'lab',
        priority: result.status === 'Yüksek' ? 'high' : 'medium',
        tags: ['laboratuvar', result.status.toLowerCase()],
        details: {
          testName: result.testName,
          value: result.value,
          unit: result.unit,
          normalRange: result.normalRange,
          status: result.status
        }
      }))
  ].sort((a, b) => new Date(b.date) - new Date(a.date));

  // Filtrelenmiş olaylar
  const filteredEvents = filterType === 'all' 
    ? allEvents 
    : allEvents.filter(event => event.category === filterType);

  const getEventColor = (type, priority) => {
    if (priority === 'high') {
      switch (type) {
        case 'medication': return '#dc3545';
        case 'appointment': return '#fd7e14';
        case 'surgery': return '#6f42c1';
        case 'lab_result': return '#e83e8c';
        default: return '#007bff';
      }
    } else if (priority === 'medium') {
      switch (type) {
        case 'medication': return '#28a745';
        case 'appointment': return '#ffc107';
        case 'surgery': return '#6f42c1';
        case 'lab_result': return '#fd7e14';
        default: return '#007bff';
      }
    } else {
      return '#6c757d';
    }
  };

  const getEventIcon = (type) => {
    switch (type) {
      case 'medication': return Pill;
      case 'appointment': return Calendar;
      case 'surgery': return Activity;
      case 'lab_result': return TrendingUp;
      default: return Activity;
    }
  };

  const getPriorityIcon = (priority) => {
    switch (priority) {
      case 'high': return TrendingUp;
      case 'medium': return Minus;
      case 'low': return TrendingDown;
      default: return Minus;
    }
  };

  const handleEventClick = (event) => {
    setSelectedEvent(event);
    setShowEventModal(true);
  };

  const getCategoryStats = () => {
    const stats = {
      medication: 0,
      appointment: 0,
      surgery: 0,
      lab: 0
    };

    allEvents.forEach(event => {
      stats[event.category] = (stats[event.category] || 0) + 1;
    });

    return stats;
  };

  const categoryStats = getCategoryStats();

  return (
    <>
      <div className="modern-patient-detail-panel">
        <div className="modern-timeline-filters">
          <button
            className={`modern-timeline-filter-btn ${filterType === 'all' ? 'active' : ''}`}
            onClick={() => setFilterType('all')}
          >
            <Calendar size={16} />
            Tümü
            <span className="modern-timeline-filter-count">{allEvents.length}</span>
          </button>
          <button
            className={`modern-timeline-filter-btn ${filterType === 'medication' ? 'active' : ''}`}
            onClick={() => setFilterType('medication')}
          >
            <Pill size={16} />
            İlaç
            <span className="modern-timeline-filter-count">{categoryStats.medication}</span>
          </button>
          <button
            className={`modern-timeline-filter-btn ${filterType === 'appointment' ? 'active' : ''}`}
            onClick={() => setFilterType('appointment')}
          >
            <Calendar size={16} />
            Randevu
            <span className="modern-timeline-filter-count">{categoryStats.appointment}</span>
          </button>
          <button
            className={`modern-timeline-filter-btn ${filterType === 'surgery' ? 'active' : ''}`}
            onClick={() => setFilterType('surgery')}
          >
            <Activity size={16} />
            Operasyon
            <span className="modern-timeline-filter-count">{categoryStats.surgery}</span>
          </button>
          <button
            className={`modern-timeline-filter-btn ${filterType === 'lab' ? 'active' : ''}`}
            onClick={() => setFilterType('lab')}
          >
            <TrendingUp size={16} />
            Lab
            <span className="modern-timeline-filter-count">{categoryStats.lab}</span>
          </button>
        </div>
        <div className="gov-card-body">
          {filteredEvents.length === 0 ? (
            <div className="text-center text-muted py-4">
              <Calendar size={48} className="mb-3" />
              <p>Timeline verisi bulunamadı</p>
            </div>
          ) : (
            <div className="gov-timeline">
              {filteredEvents.map((event, index) => {
                const IconComponent = getEventIcon(event.type);
                const PriorityIcon = getPriorityIcon(event.priority);
                const eventColor = getEventColor(event.type, event.priority);
                
                return (
                  <div key={`${event.type}-${event.id}`} className="gov-timeline-item">
                    <div className="d-flex align-items-start">
                      <div 
                        className="timeline-icon-advanced me-3"
                        style={{ 
                          backgroundColor: eventColor,
                          color: 'white',
                          borderRadius: '50%',
                          width: '50px',
                          height: '50px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0,
                          cursor: 'pointer'
                        }}
                        onClick={() => handleEventClick(event)}
                      >
                        <IconComponent size={24} />
                      </div>
                      
                      <div className="flex-grow-1">
                        <div className="gov-timeline-date">
                          {format(new Date(event.date), 'dd MMM yyyy', { locale: tr })}
                        </div>
                        <div className="gov-timeline-title">
                          {event.title}
                        </div>
                        <div className="gov-timeline-description">
                          {event.description}
                        </div>
                        <div className="d-flex align-items-center gap-2 mt-2">
                          <span className={`gov-badge ${event.priority === 'high' ? 'gov-badge-danger' : 
                                        event.priority === 'medium' ? 'gov-badge-warning' : 'gov-badge-secondary'}`}>
                            <PriorityIcon size={12} className="me-1" />
                            {event.priority === 'high' ? 'Yüksek' : 
                             event.priority === 'medium' ? 'Orta' : 'Düşük'} Öncelik
                          </span>
                        </div>
                        <button
                          className="gov-btn gov-btn-sm gov-btn-outline-primary"
                          onClick={() => handleEventClick(event)}
                        >
                          <Eye size={14} />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Event Detay Modal */}
      <Modal show={showEventModal} onHide={() => setShowEventModal(false)} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>
            {selectedEvent && (
              <>
                {React.createElement(getEventIcon(selectedEvent.type), { size: 20, style: { marginRight: '8px' } })}
                {selectedEvent.title}
              </>
            )}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedEvent && (
            <div>
              <Row>
                <Col md={6}>
                  <h6 className="text-muted">Temel Bilgiler</h6>
                  <div className="mb-3">
                    <strong>Tarih:</strong> {format(new Date(selectedEvent.date), 'dd MMMM yyyy', { locale: tr })}
                  </div>
                  <div className="mb-3">
                    <strong>Öncelik:</strong> 
                    <Badge bg={selectedEvent.priority === 'high' ? 'danger' : 
                              selectedEvent.priority === 'medium' ? 'warning' : 'secondary'} 
                           className="ms-2">
                      {selectedEvent.priority === 'high' ? 'Yüksek' : 
                       selectedEvent.priority === 'medium' ? 'Orta' : 'Düşük'}
                    </Badge>
                  </div>
                  <div className="mb-3">
                    <strong>Konum:</strong> {selectedEvent.location}
                  </div>
                  <div className="mb-3">
                    <strong>Açıklama:</strong> {selectedEvent.description}
                  </div>
                </Col>
                <Col md={6}>
                  <h6 className="text-muted">Detaylar</h6>
                  {Object.entries(selectedEvent.details).map(([key, value]) => (
                    <div key={key} className="mb-2">
                      <strong>{key}:</strong> {value}
                    </div>
                  ))}
                </Col>
              </Row>
              
              <div className="mt-3">
                <h6 className="text-muted">Etiketler</h6>
                <div>
                  {selectedEvent.tags.map(tag => (
                    <Badge key={tag} bg="primary" className="me-1">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowEventModal(false)}>
            Kapat
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default AdvancedTimeline;
