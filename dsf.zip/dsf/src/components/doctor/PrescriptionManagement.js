import React, { useState, useEffect } from 'react';
import { Pill, Plus, Edit, Trash2, FileText, Printer, Download, AlertTriangle, CheckCircle } from 'lucide-react';

const PrescriptionManagement = ({ patient, onPrescriptionUpdate }) => {
  const [prescriptions, setPrescriptions] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingPrescription, setEditingPrescription] = useState(null);
  const [formData, setFormData] = useState({
    date: '',
    doctor: '',
    medications: [],
    notes: '',
    status: 'active'
  });

  // Örnek reçete verileri
  useEffect(() => {
    const samplePrescriptions = [
      {
        id: 1,
        date: '2024-01-10',
        doctor: 'Dr. Ahmet Yılmaz',
        medications: [
          { name: 'Paracetamol', dosage: '500mg', frequency: '3x1', duration: '7 gün' },
          { name: 'Ibuprofen', dosage: '400mg', frequency: '2x1', duration: '5 gün' }
        ],
        notes: 'Ateş ve ağrı için',
        status: 'active',
        patientId: patient?.id
      },
      {
        id: 2,
        date: '2024-01-05',
        doctor: 'Dr. Mehmet Kaya',
        medications: [
          { name: 'Amoxicillin', dosage: '875mg', frequency: '2x1', duration: '10 gün' }
        ],
        notes: 'Enfeksiyon tedavisi',
        status: 'completed',
        patientId: patient?.id
      }
    ];
    setPrescriptions(samplePrescriptions);
  }, [patient]);

  const statusOptions = [
    { value: 'active', label: 'Aktif', color: 'success' },
    { value: 'completed', label: 'Tamamlandı', color: 'primary' },
    { value: 'cancelled', label: 'İptal', color: 'danger' },
    { value: 'expired', label: 'Süresi Doldu', color: 'warning' }
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (editingPrescription) {
      // Güncelleme
      const updatedPrescriptions = prescriptions.map(pres => 
        pres.id === editingPrescription.id 
          ? { ...pres, ...formData }
          : pres
      );
      setPrescriptions(updatedPrescriptions);
    } else {
      // Yeni ekleme
      const newPrescription = {
        id: Date.now(),
        ...formData,
        patientId: patient?.id
      };
      setPrescriptions([...prescriptions, newPrescription]);
    }

    setShowModal(false);
    setEditingPrescription(null);
    setFormData({
      date: '',
      doctor: '',
      medications: [],
      notes: '',
      status: 'active'
    });
  };

  const handleEdit = (prescription) => {
    setEditingPrescription(prescription);
    setFormData(prescription);
    setShowModal(true);
  };

  const handleDelete = (prescriptionId) => {
    if (window.confirm('Bu reçeteyi silmek istediğinizden emin misiniz?')) {
      setPrescriptions(prescriptions.filter(pres => pres.id !== prescriptionId));
    }
  };

  const addMedication = () => {
    setFormData({
      ...formData,
      medications: [...formData.medications, { name: '', dosage: '', frequency: '', duration: '' }]
    });
  };

  const updateMedication = (index, field, value) => {
    const updatedMedications = [...formData.medications];
    updatedMedications[index][field] = value;
    setFormData({ ...formData, medications: updatedMedications });
  };

  const removeMedication = (index) => {
    const updatedMedications = formData.medications.filter((_, i) => i !== index);
    setFormData({ ...formData, medications: updatedMedications });
  };

  const getStatusColor = (status) => {
    const statusMap = {
      active: 'gov-badge-success',
      completed: 'gov-badge-primary',
      cancelled: 'gov-badge-danger',
      expired: 'gov-badge-warning'
    };
    return statusMap[status] || 'gov-badge-secondary';
  };

  const getStatusLabel = (status) => {
    const statusObj = statusOptions.find(s => s.value === status);
    return statusObj ? statusObj.label : status;
  };

  const activePrescriptions = prescriptions.filter(pres => pres.status === 'active');
  const totalMedications = prescriptions.reduce((total, pres) => total + pres.medications.length, 0);

  return (
    <div className="gov-card">
      <div className="gov-card-header">
        <div className="d-flex align-items-center justify-content-between">
          <h6 className="mb-0">
            <Pill size={16} style={{ marginRight: '5px' }} />
            Reçete Yönetimi
          </h6>
          <button
            className="gov-btn gov-btn-sm gov-btn-primary"
            onClick={() => setShowModal(true)}
          >
            <Plus size={14} />
            Yeni Reçete
          </button>
        </div>
      </div>
      <div className="gov-card-body">
        {/* İstatistikler */}
        <div className="gov-stats mb-4">
          <div className="gov-stat">
            <div className="gov-stat-value">{prescriptions.length}</div>
            <div className="gov-stat-label">Toplam Reçete</div>
          </div>
          <div className="gov-stat">
            <div className="gov-stat-value">{activePrescriptions.length}</div>
            <div className="gov-stat-label">Aktif Reçete</div>
          </div>
          <div className="gov-stat">
            <div className="gov-stat-value">{totalMedications}</div>
            <div className="gov-stat-label">Toplam İlaç</div>
          </div>
          <div className="gov-stat">
            <div className="gov-stat-value">
              {prescriptions.filter(pres => pres.status === 'expired').length}
            </div>
            <div className="gov-stat-label">Süresi Dolan</div>
          </div>
        </div>

        {/* Reçete Listesi */}
        <div className="table-responsive">
          <table className="gov-table">
            <thead>
              <tr>
                <th>Tarih</th>
                <th>Doktor</th>
                <th>İlaçlar</th>
                <th>Durum</th>
                <th>Notlar</th>
                <th>İşlemler</th>
              </tr>
            </thead>
            <tbody>
              {prescriptions.map(prescription => (
                <tr key={prescription.id}>
                  <td>
                    {new Date(prescription.date).toLocaleDateString('tr-TR')}
                  </td>
                  <td>{prescription.doctor}</td>
                  <td>
                    <div className="d-flex flex-wrap gap-1">
                      {prescription.medications.map((med, index) => (
                        <span key={index} className="gov-badge gov-badge-primary">
                          {med.name}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td>
                    <span className={`gov-badge ${getStatusColor(prescription.status)}`}>
                      {getStatusLabel(prescription.status)}
                    </span>
                  </td>
                  <td>{prescription.notes}</td>
                  <td>
                    <div className="d-flex gap-1">
                      <button
                        className="gov-btn gov-btn-sm gov-btn-outline-primary"
                        onClick={() => handleEdit(prescription)}
                        title="Düzenle"
                      >
                        <Edit size={12} />
                      </button>
                      <button
                        className="gov-btn gov-btn-sm gov-btn-outline-success"
                        title="Yazdır"
                      >
                        <Printer size={12} />
                      </button>
                      <button
                        className="gov-btn gov-btn-sm gov-btn-outline-danger"
                        onClick={() => handleDelete(prescription.id)}
                        title="Sil"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {prescriptions.length === 0 && (
          <div className="text-center py-4">
            <Pill size={48} className="mb-3 text-muted" />
            <p className="text-muted">Henüz reçete bulunmuyor</p>
            <button
              className="gov-btn gov-btn-primary"
              onClick={() => setShowModal(true)}
            >
              <Plus size={16} />
              İlk Reçeteyi Ekle
            </button>
          </div>
        )}
      </div>

      {/* Reçete Ekleme/Düzenleme Modal */}
      {showModal && (
        <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  {editingPrescription ? 'Reçete Düzenle' : 'Yeni Reçete'}
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => {
                    setShowModal(false);
                    setEditingPrescription(null);
                    setFormData({
                      date: '',
                      doctor: '',
                      medications: [],
                      notes: '',
                      status: 'active'
                    });
                  }}
                ></button>
              </div>
              <form onSubmit={handleSubmit}>
                <div className="modal-body">
                  <div className="row">
                    <div className="col-md-6">
                      <div className="gov-form-group">
                        <label className="gov-label">Tarih</label>
                        <input
                          type="date"
                          className="gov-input"
                          value={formData.date}
                          onChange={(e) => setFormData({...formData, date: e.target.value})}
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="gov-form-group">
                        <label className="gov-label">Durum</label>
                        <select
                          className="gov-select"
                          value={formData.status}
                          onChange={(e) => setFormData({...formData, status: e.target.value})}
                        >
                          {statusOptions.map(status => (
                            <option key={status.value} value={status.value}>
                              {status.label}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>

                  <div className="gov-form-group">
                    <label className="gov-label">Doktor</label>
                    <input
                      type="text"
                      className="gov-input"
                      value={formData.doctor}
                      onChange={(e) => setFormData({...formData, doctor: e.target.value})}
                      placeholder="Doktor adı"
                      required
                    />
                  </div>

                  {/* İlaç Listesi */}
                  <div className="gov-form-group">
                    <div className="d-flex align-items-center justify-content-between mb-2">
                      <label className="gov-label">İlaçlar</label>
                      <button
                        type="button"
                        className="gov-btn gov-btn-sm gov-btn-outline-primary"
                        onClick={addMedication}
                      >
                        <Plus size={14} />
                        İlaç Ekle
                      </button>
                    </div>
                    
                    {formData.medications.map((medication, index) => (
                      <div key={index} className="border rounded p-3 mb-2">
                        <div className="row">
                          <div className="col-md-6">
                            <input
                              type="text"
                              className="gov-input mb-2"
                              placeholder="İlaç adı"
                              value={medication.name}
                              onChange={(e) => updateMedication(index, 'name', e.target.value)}
                              required
                            />
                          </div>
                          <div className="col-md-6">
                            <input
                              type="text"
                              className="gov-input mb-2"
                              placeholder="Dozaj (örn: 500mg)"
                              value={medication.dosage}
                              onChange={(e) => updateMedication(index, 'dosage', e.target.value)}
                              required
                            />
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-md-6">
                            <input
                              type="text"
                              className="gov-input mb-2"
                              placeholder="Sıklık (örn: 3x1)"
                              value={medication.frequency}
                              onChange={(e) => updateMedication(index, 'frequency', e.target.value)}
                              required
                            />
                          </div>
                          <div className="col-md-6">
                            <div className="d-flex">
                              <input
                                type="text"
                                className="gov-input mb-2"
                                placeholder="Süre (örn: 7 gün)"
                                value={medication.duration}
                                onChange={(e) => updateMedication(index, 'duration', e.target.value)}
                                required
                              />
                              <button
                                type="button"
                                className="gov-btn gov-btn-sm gov-btn-outline-danger ms-2"
                                onClick={() => removeMedication(index)}
                                title="İlaç Sil"
                              >
                                <Trash2 size={12} />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="gov-form-group">
                    <label className="gov-label">Notlar</label>
                    <textarea
                      className="gov-input"
                      rows="3"
                      value={formData.notes}
                      onChange={(e) => setFormData({...formData, notes: e.target.value})}
                      placeholder="Reçete notları..."
                    />
                  </div>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="gov-btn gov-btn-secondary"
                    onClick={() => {
                      setShowModal(false);
                      setEditingPrescription(null);
                    }}
                  >
                    İptal
                  </button>
                  <button type="submit" className="gov-btn gov-btn-primary">
                    {editingPrescription ? 'Güncelle' : 'Kaydet'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PrescriptionManagement;
