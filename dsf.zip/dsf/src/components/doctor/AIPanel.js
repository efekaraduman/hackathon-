import React from 'react';
import { Card, Button, Badge } from 'react-bootstrap';
import { 
  Brain, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  TrendingUp,
  Activity
} from 'lucide-react';

const AIPanel = ({ patient, aiSummary, drugInteractions }) => {
  if (!patient) {
    return (
      <div className="ai-panel">
        <div className="text-center text-muted py-5">
          <Brain size={64} className="mb-3" />
          <h5>AI Analiz Paneli</h5>
          <p>Hasta seçildiğinde AI analizi burada görünecek</p>
        </div>
      </div>
    );
  }

  return (
    <div className="ai-panel">
      <div className="d-flex align-items-center mb-4">
        <Brain size={24} style={{ marginRight: '8px' }} />
        <h5 className="mb-0">AI Analiz Paneli</h5>
      </div>

      {/* AI Özet */}
      {aiSummary && (
        <div className="ai-summary mb-4">
          <h6 className="mb-3">
            <CheckCircle size={18} style={{ marginRight: '5px' }} />
            Hasta Özeti
          </h6>
          <p className="mb-2"><strong>Risk Seviyesi:</strong> {aiSummary.riskLevel}</p>
          <p className="mb-2"><strong>Ana Problemler:</strong></p>
          <ul className="mb-3">
            {aiSummary.mainProblems.map((problem, index) => (
              <li key={index}>{problem}</li>
            ))}
          </ul>
          <p className="mb-0"><strong>Öneriler:</strong> {aiSummary.recommendations}</p>
        </div>
      )}

      {/* İlaç Etkileşim Analizi */}
      {drugInteractions.length > 0 && (
        <Card className="mb-4">
          <Card.Header className="bg-warning text-dark">
            <h6 className="mb-0">
              <AlertTriangle size={16} style={{ marginRight: '5px' }} />
              İlaç Etkileşim Analizi
            </h6>
          </Card.Header>
          <Card.Body>
            {drugInteractions.map((interaction, index) => (
              <div key={index} className="drug-interaction-warning mb-2">
                <small>{interaction}</small>
              </div>
            ))}
          </Card.Body>
        </Card>
      )}

      {/* Hasta İstatistikleri */}
      <Card className="mb-4">
        <Card.Header className="bg-info text-white">
          <h6 className="mb-0">
            <TrendingUp size={16} style={{ marginRight: '5px' }} />
            Hasta İstatistikleri
          </h6>
        </Card.Header>
        <Card.Body>
          <div className="d-flex justify-content-between mb-2">
            <span>Aktif İlaç Sayısı:</span>
            <Badge bg="primary">{patient.medications.length}</Badge>
          </div>
          <div className="d-flex justify-content-between mb-2">
            <span>Kronik Hastalık:</span>
            <Badge bg="secondary">{patient.chronicDiseases.length}</Badge>
          </div>
          <div className="d-flex justify-content-between mb-2">
            <span>Alerji Sayısı:</span>
            <Badge bg="danger">{patient.allergies.length}</Badge>
          </div>
          <div className="d-flex justify-content-between mb-2">
            <span>Operasyon Sayısı:</span>
            <Badge bg="warning">{patient.surgeries.length}</Badge>
          </div>
        </Card.Body>
      </Card>

      {/* Tedavi Timeline Özeti */}
      <Card className="mb-4">
        <Card.Header className="bg-success text-white">
          <h6 className="mb-0">
            <Clock size={16} style={{ marginRight: '5px' }} />
            Tedavi Timeline
          </h6>
        </Card.Header>
        <Card.Body>
          <div className="timeline-summary">
            {patient.medications.slice(0, 3).map(medication => (
              <div key={medication.id} className="mb-2">
                <small className="text-muted">
                  {new Date(medication.startDate).toLocaleDateString('tr-TR')}
                </small>
                <div className="fw-bold">{medication.name}</div>
                <small className="text-muted">{medication.prescribingDoctor}</small>
              </div>
            ))}
            {patient.medications.length > 3 && (
              <small className="text-muted">+{patient.medications.length - 3} daha fazla ilaç</small>
            )}
          </div>
        </Card.Body>
      </Card>

      {/* AI Önerileri */}
      <Card className="mb-4">
        <Card.Header className="bg-primary text-white">
          <h6 className="mb-0">
            <Activity size={16} style={{ marginRight: '5px' }} />
            AI Önerileri
          </h6>
        </Card.Header>
        <Card.Body>
          <div className="ai-recommendations">
            <div className="mb-2">
              <Badge bg="success" className="me-2">✓</Badge>
              <small>Düzenli ilaç takibi yapılmalı</small>
            </div>
            <div className="mb-2">
              <Badge bg="warning" className="me-2">⚠</Badge>
              <small>Laboratuvar değerleri yakından izlenmeli</small>
            </div>
            <div className="mb-2">
              <Badge bg="info" className="me-2">ℹ</Badge>
              <small>Hasta eğitimi verilmeli</small>
            </div>
          </div>
        </Card.Body>
      </Card>

      {/* Aksiyon Butonları */}
      <div className="d-grid gap-2">
        <Button variant="success" size="sm">
          <CheckCircle size={16} style={{ marginRight: '5px' }} />
          Onayla
        </Button>
        <Button variant="warning" size="sm">
          <AlertTriangle size={16} style={{ marginRight: '5px' }} />
          Düzenle
        </Button>
        <Button variant="info" size="sm">
          <Activity size={16} style={{ marginRight: '5px' }} />
          Rapor Oluştur
        </Button>
      </div>
    </div>
  );
};

export default AIPanel;
