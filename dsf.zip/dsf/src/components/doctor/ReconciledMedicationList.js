import React, { useState } from 'react';
import { Card, Table, Button, Modal, Badge, Form, Row, Col, Alert } from 'react-bootstrap';
import { 
  Eye, 
  Edit, 
  Check, 
  X, 
  AlertTriangle, 
  MapPin,
  Calendar,
  User,
  Pill
} from 'lucide-react';

const ReconciledMedicationList = ({ patient, onMedicationUpdate }) => {
  const [showSourceModal, setShowSourceModal] = useState(false);
  const [selectedMedication, setSelectedMedication] = useState(null);
  const [editingMedication, setEditingMedication] = useState(null);
  const [editForm, setEditForm] = useState({});

  if (!patient) return null;

  const handleShowSource = (medication) => {
    setSelectedMedication(medication);
    setShowSourceModal(true);
  };

  const handleEdit = (medication) => {
    setEditingMedication(medication);
    setEditForm({
      dosage: medication.dosage,
      notes: medication.notes || '',
      status: medication.status || 'active'
    });
  };

  const handleSaveEdit = () => {
    if (editingMedication && onMedicationUpdate) {
      onMedicationUpdate(editingMedication.id, editForm);
    }
    setEditingMedication(null);
    setEditForm({});
  };

  const handleCancelEdit = () => {
    setEditingMedication(null);
    setEditForm({});
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'success';
      case 'discontinued': return 'secondary';
      case 'modified': return 'warning';
      default: return 'primary';
    }
  };

  const getInteractionLevel = (medication) => {
    // Basit etkileşim seviyesi hesaplama
    const highRiskSubstances = ['metformin', 'insulin', 'warfarin', 'digoxin'];
    const substance = medication.activeSubstance.toLowerCase();
    
    if (highRiskSubstances.some(risk => substance.includes(risk))) {
      return { level: 'high', color: 'danger', text: 'Yüksek Risk' };
    } else if (medication.dosage.includes('2x') || medication.dosage.includes('3x')) {
      return { level: 'medium', color: 'warning', text: 'Orta Risk' };
    } else {
      return { level: 'low', color: 'success', text: 'Düşük Risk' };
    }
  };

  return (
    <>
      <div className="modern-patient-detail-panel">
        {/* İlaç Özet Kartları */}
        <div className="modern-medication-summary">
          <div className="modern-summary-card">
            <div className="modern-summary-value">{patient.medications.length}</div>
            <div className="modern-summary-label">Toplam İlaç</div>
          </div>
          <div className="modern-summary-card">
            <div className="modern-summary-value">
              {patient.medications.filter(med => getInteractionLevel(med).level === 'high').length}
            </div>
            <div className="modern-summary-label">Yüksek Risk</div>
          </div>
          <div className="modern-summary-card">
            <div className="modern-summary-value">
              {new Set(patient.medications.map(med => med.city)).size}
            </div>
            <div className="modern-summary-label">Farklı Şehir</div>
          </div>
          <div className="modern-summary-card">
            <div className="modern-summary-value">
              {new Set(patient.medications.map(med => med.prescribingDoctor)).size}
            </div>
            <div className="modern-summary-label">Farklı Doktor</div>
          </div>
        </div>

        {/* İlaç Detayları */}
        {patient.medications.map(medication => {
          const interaction = getInteractionLevel(medication);
          const isEditing = editingMedication?.id === medication.id;
          
          return (
            <div key={medication.id} className="modern-medication-details">
              <div className="modern-medication-header">
                <div>
                  <h3 className="modern-medication-name">{medication.name}</h3>
                  <p className="modern-medication-dosage">{medication.dosage}</p>
                </div>
                <div className="modern-medication-actions">
                  <div 
                    className="modern-action-icon modern-action-icon-view"
                    onClick={() => handleShowSource(medication)}
                    title="Kaynak Görüntüle"
                  >
                    <Eye size={18} />
                  </div>
                  <div 
                    className="modern-action-icon modern-action-icon-edit"
                    onClick={() => handleEdit(medication)}
                    title="Düzenle"
                  >
                    <Edit size={18} />
                  </div>
                </div>
              </div>
              
              <div className="modern-medication-tags">
                <span className={`modern-medication-tag modern-medication-tag-info`}>
                  Gerektiğinde
                </span>
                <span className={`modern-medication-tag modern-medication-tag-success`}>
                  Aktif
                </span>
                <span className={`modern-medication-tag modern-medication-tag-${interaction.color}`}>
                  {interaction.text}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Kaynak Modal */}
      <Modal show={showSourceModal} onHide={() => setShowSourceModal(false)} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>
            <Pill size={20} style={{ marginRight: '8px' }} />
            İlaç Kaynak Bilgileri
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedMedication && (
            <div>
              <Row className="mb-3">
                <Col md={6}>
                  <strong>İlaç Adı:</strong>
                  <p>{selectedMedication.name}</p>
                </Col>
                <Col md={6}>
                  <strong>Etken Madde:</strong>
                  <p>{selectedMedication.activeSubstance}</p>
                </Col>
              </Row>
              <Row className="mb-3">
                <Col md={6}>
                  <strong>Dozaj:</strong>
                  <p>{selectedMedication.dosage}</p>
                </Col>
                <Col md={6}>
                  <strong>Reçete Eden Doktor:</strong>
                  <p>{selectedMedication.prescribingDoctor}</p>
                </Col>
              </Row>
              <Row className="mb-3">
                <Col md={6}>
                  <strong>Hastane:</strong>
                  <p>{selectedMedication.hospital}</p>
                </Col>
                <Col md={6}>
                  <strong>Şehir:</strong>
                  <p>{selectedMedication.city}</p>
                </Col>
              </Row>
              <Row className="mb-3">
                <Col md={6}>
                  <strong>Başlangıç Tarihi:</strong>
                  <p>{new Date(selectedMedication.startDate).toLocaleDateString('tr-TR')}</p>
                </Col>
                <Col md={6}>
                  <strong>Durum:</strong>
                  <Badge bg={getStatusColor(selectedMedication.status || 'active')}>
                    {selectedMedication.status === 'discontinued' ? 'Durduruldu' : 
                     selectedMedication.status === 'modified' ? 'Değiştirildi' : 'Aktif'}
                  </Badge>
                </Col>
              </Row>
              {selectedMedication.notes && (
                <Row>
                  <Col>
                    <strong>Notlar:</strong>
                    <p>{selectedMedication.notes}</p>
                  </Col>
                </Row>
              )}
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowSourceModal(false)}>
            Kapat
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Düzenleme Modal */}
      <Modal show={editingMedication !== null} onHide={handleCancelEdit} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>
            <Edit size={20} style={{ marginRight: '8px' }} />
            İlaç Düzenle
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {editingMedication && (
            <Form>
              <Row className="mb-3">
                <Col md={6}>
                  <Form.Label>Dozaj</Form.Label>
                  <Form.Control
                    type="text"
                    value={editForm.dosage}
                    onChange={(e) => setEditForm({...editForm, dosage: e.target.value})}
                    placeholder="Örn: 1x1, 2x1"
                  />
                </Col>
                <Col md={6}>
                  <Form.Label>Durum</Form.Label>
                  <Form.Select
                    value={editForm.status}
                    onChange={(e) => setEditForm({...editForm, status: e.target.value})}
                  >
                    <option value="active">Aktif</option>
                    <option value="discontinued">Durduruldu</option>
                    <option value="modified">Değiştirildi</option>
                  </Form.Select>
                </Col>
              </Row>
              <Row>
                <Col>
                  <Form.Label>Notlar</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    value={editForm.notes}
                    onChange={(e) => setEditForm({...editForm, notes: e.target.value})}
                    placeholder="İlaç hakkında notlar..."
                  />
                </Col>
              </Row>
            </Form>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCancelEdit}>
            İptal
          </Button>
          <Button variant="primary" onClick={handleSaveEdit}>
            Kaydet
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default ReconciledMedicationList;