import React from 'react';
import { Card } from 'react-bootstrap';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, PieChart as PieChartIcon } from 'lucide-react';

const MedicationChart = ({ patient }) => {
  if (!patient) return null;

  // Şehirlere göre ilaç dağılımı
  const cityData = patient.medications.reduce((acc, med) => {
    const city = med.city;
    acc[city] = (acc[city] || 0) + 1;
    return acc;
  }, {});

  const cityChartData = Object.entries(cityData).map(([city, count]) => ({
    city,
    count
  }));

  // Etken madde dağılımı
  const substanceData = patient.medications.reduce((acc, med) => {
    const substance = med.activeSubstance;
    acc[substance] = (acc[substance] || 0) + 1;
    return acc;
  }, {});

  const substanceChartData = Object.entries(substanceData).map(([substance, count]) => ({
    substance,
    count
  }));

  // Renk paleti
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

  return (
    <Card className="mb-4">
      <Card.Header className="bg-info text-white">
        <h6 className="mb-0">
          <TrendingUp size={16} style={{ marginRight: '5px' }} />
          İlaç Analiz Grafikleri
        </h6>
      </Card.Header>
      <Card.Body>
        <div className="row">
          {/* Şehirlere Göre İlaç Dağılımı */}
          <div className="col-md-6">
            <h6 className="text-center mb-3">Şehirlere Göre İlaç Dağılımı</h6>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={cityChartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="city" 
                  angle={-45}
                  textAnchor="end"
                  height={60}
                  fontSize={12}
                />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Etken Madde Dağılımı */}
          <div className="col-md-6">
            <h6 className="text-center mb-3">Etken Madde Dağılımı</h6>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={substanceChartData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ substance, percent }) => `${substance} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="count"
                >
                  {substanceChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* İstatistikler */}
        <div className="row mt-4">
          <div className="col-md-3">
            <div className="text-center">
              <h4 className="text-primary">{patient.medications.length}</h4>
              <small className="text-muted">Toplam İlaç</small>
            </div>
          </div>
          <div className="col-md-3">
            <div className="text-center">
              <h4 className="text-success">{Object.keys(cityData).length}</h4>
              <small className="text-muted">Farklı Şehir</small>
            </div>
          </div>
          <div className="col-md-3">
            <div className="text-center">
              <h4 className="text-warning">{Object.keys(substanceData).length}</h4>
              <small className="text-muted">Farklı Etken Madde</small>
            </div>
          </div>
          <div className="col-md-3">
            <div className="text-center">
              <h4 className="text-info">
                {patient.medications.filter(med => !med.endDate).length}
              </h4>
              <small className="text-muted">Aktif İlaç</small>
            </div>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
};

export default MedicationChart;
