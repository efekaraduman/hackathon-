import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Badge, Alert, Button, Modal, Accordion } from 'react-bootstrap';
import { 
  MessageSquare, 
  AlertTriangle, 
  Clock, 
  User, 
  Activity,
  Brain,
  TestTube,
  TrendingUp,
  Eye,
  CheckCircle
} from 'lucide-react';
import { analyzeComplaint, analyzeComplaintHistory } from '../../utils/complaintAnalysis';

const ComplaintPanel = ({ patient, complaints = [] }) => {
  const [selectedComplaint, setSelectedComplaint] = useState(null);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState(null);

  useEffect(() => {
    if (selectedComplaint) {
      const analysis = analyzeComplaint(selectedComplaint);
      setAiAnalysis(analysis);
    }
  }, [selectedComplaint]);

  const getSeverityColor = (severity) => {
    const colors = {
      mild: 'success',
      moderate: 'warning', 
      severe: 'danger',
      critical: 'dark'
    };
    return colors[severity] || 'secondary';
  };

  const getPriorityColor = (priority) => {
    const colors = {
      CRITICAL: 'danger',
      HIGH: 'warning',
      MEDIUM: 'info',
      LOW: 'success'
    };
    return colors[priority] || 'secondary';
  };

  const getUrgencyIcon = (urgency) => {
    const icons = {
      IMMEDIATE: <AlertTriangle size={16} className="text-danger" />,
      URGENT: <Clock size={16} className="text-warning" />,
      SOON: <Clock size={16} className="text-info" />,
      ROUTINE: <CheckCircle size={16} className="text-success" />
    };
    return icons[urgency] || <Clock size={16} />;
  };

  const formatDate = (timestamp) => {
    return new Date(timestamp).toLocaleString('tr-TR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const historyAnalysis = analyzeComplaintHistory(complaints);

  if (!complaints || complaints.length === 0) {
    return (
      <Card className="minimal-card">
        <Card.Header className="d-flex align-items-center">
          <MessageSquare size={20} style={{ marginRight: '8px' }} />
          <strong>Hasta Şikayetleri</strong>
        </Card.Header>
        <Card.Body className="text-center py-4">
          <MessageSquare size={48} className="text-muted mb-3" />
          <p className="text-muted mb-0">Bu hasta için henüz şikayet bildirimi yok.</p>
        </Card.Body>
      </Card>
    );
  }

  return (
    <Card className="minimal-card">
      <Card.Header className="d-flex align-items-center justify-content-between">
        <div className="d-flex align-items-center">
          <MessageSquare size={20} style={{ marginRight: '8px' }} />
          <strong>Hasta Şikayetleri</strong>
          <Badge bg="primary" className="ms-2">{complaints.length}</Badge>
        </div>
        <Button 
          variant="outline-primary" 
          size="sm"
          onClick={() => setShowAnalysis(true)}
        >
          <Brain size={16} style={{ marginRight: '4px' }} />
          AI Analizi
        </Button>
      </Card.Header>
      
      <Card.Body>
        {/* Şikayet Geçmişi Analizi */}
        <Alert variant="info" className="mb-3">
          <div className="d-flex justify-content-between align-items-center">
            <div>
              <strong>Şikayet Geçmişi:</strong> {historyAnalysis.frequency} • 
              <strong> Trend:</strong> {historyAnalysis.trend} • 
              <strong> En Sık:</strong> {historyAnalysis.pattern}
            </div>
          </div>
        </Alert>

        {/* Şikayet Listesi */}
        <div className="complaint-list">
          {complaints.map((complaint, index) => (
            <Card 
              key={complaint.id} 
              className={`mb-3 ${selectedComplaint?.id === complaint.id ? 'border-primary' : ''}`}
              style={{ cursor: 'pointer' }}
              onClick={() => setSelectedComplaint(complaint)}
            >
              <Card.Body>
                <Row className="align-items-center">
                  <Col md={8}>
                    <div className="d-flex align-items-center mb-2">
                      <h6 className="mb-0 me-2">{complaint.complaintType}</h6>
                      <Badge bg={getSeverityColor(complaint.severity)}>
                        {complaint.severity}
                      </Badge>
                      {complaint.emergency && (
                        <Badge bg="danger" className="ms-1">
                          <AlertTriangle size={12} /> ACİL
                        </Badge>
                      )}
                    </div>
                    <p className="text-muted mb-1 small">
                      {complaint.description.substring(0, 100)}...
                    </p>
                    <div className="d-flex align-items-center text-muted small">
                      <Clock size={12} style={{ marginRight: '4px' }} />
                      {formatDate(complaint.timestamp)} • 
                      <span className="ms-1">{complaint.duration}</span>
                    </div>
                  </Col>
                  <Col md={4} className="text-end">
                    <div className="d-flex flex-column align-items-end">
                      {getUrgencyIcon(complaint.urgency)}
                      <small className="text-muted mt-1">
                        {complaint.symptoms && complaint.symptoms.split(',').length} belirti
                      </small>
                    </div>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          ))}
        </div>

        {/* Seçili Şikayet Detayı */}
        {selectedComplaint && (
          <Card className="mt-3 border-primary">
            <Card.Header className="bg-light">
              <h6 className="mb-0">Şikayet Detayları</h6>
            </Card.Header>
            <Card.Body>
              <Row>
                <Col md={6}>
                  <p><strong>Tür:</strong> {selectedComplaint.complaintType}</p>
                  <p><strong>Şiddet:</strong> 
                    <Badge bg={getSeverityColor(selectedComplaint.severity)} className="ms-1">
                      {selectedComplaint.severity}
                    </Badge>
                  </p>
                  <p><strong>Süre:</strong> {selectedComplaint.duration}</p>
                  {selectedComplaint.symptoms && (
                    <p><strong>Belirtiler:</strong> {selectedComplaint.symptoms}</p>
                  )}
                </Col>
                <Col md={6}>
                  <p><strong>Tarih:</strong> {formatDate(selectedComplaint.timestamp)}</p>
                  <p><strong>Acil Durum:</strong> 
                    {selectedComplaint.emergency ? 
                      <Badge bg="danger" className="ms-1">Evet</Badge> : 
                      <Badge bg="success" className="ms-1">Hayır</Badge>
                    }
                  </p>
                </Col>
              </Row>
              <div className="mt-3">
                <p><strong>Açıklama:</strong></p>
                <p className="bg-light p-3 rounded">{selectedComplaint.description}</p>
                {selectedComplaint.additionalNotes && (
                  <>
                    <p><strong>Ek Notlar:</strong></p>
                    <p className="bg-light p-3 rounded">{selectedComplaint.additionalNotes}</p>
                  </>
                )}
              </div>
            </Card.Body>
          </Card>
        )}
      </Card.Body>

      {/* AI Analiz Modalı */}
      <Modal show={showAnalysis} onHide={() => setShowAnalysis(false)} size="lg" centered>
        <Modal.Header closeButton className="bg-primary text-white">
          <Modal.Title>
            <Brain size={20} style={{ marginRight: '8px' }} />
            AI Şikayet Analizi
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {aiAnalysis ? (
            <div>
              <Row className="mb-3">
                <Col md={4}>
                  <Card className="text-center">
                    <Card.Body>
                      <Activity size={24} className="text-primary mb-2" />
                      <h6>Öncelik</h6>
                      <Badge bg={getPriorityColor(aiAnalysis.priority)}>
                        {aiAnalysis.priority}
                      </Badge>
                    </Card.Body>
                  </Card>
                </Col>
                <Col md={4}>
                  <Card className="text-center">
                    <Card.Body>
                      <Clock size={24} className="text-warning mb-2" />
                      <h6>Aciliyet</h6>
                      <div className="d-flex align-items-center justify-content-center">
                        {getUrgencyIcon(aiAnalysis.urgency)}
                        <span className="ms-1">{aiAnalysis.urgency}</span>
                      </div>
                    </Card.Body>
                  </Card>
                </Col>
                <Col md={4}>
                  <Card className="text-center">
                    <Card.Body>
                      <TrendingUp size={24} className="text-info mb-2" />
                      <h6>Risk Seviyesi</h6>
                      <Badge bg={aiAnalysis.riskLevel === 'YÜKSEK' ? 'danger' : 
                               aiAnalysis.riskLevel === 'ORTA' ? 'warning' : 'success'}>
                        {aiAnalysis.riskLevel}
                      </Badge>
                    </Card.Body>
                  </Card>
                </Col>
              </Row>

              <Alert variant="info">
                <h6>AI Analizi:</h6>
                <p>{aiAnalysis.aiAnalysis}</p>
                <small>Güvenilirlik: %{Math.round(aiAnalysis.confidence * 100)}</small>
              </Alert>

              <Row>
                <Col md={6}>
                  <h6>Öneriler:</h6>
                  <ul>
                    {aiAnalysis.recommendations.map((rec, index) => (
                      <li key={index}>{rec}</li>
                    ))}
                  </ul>
                </Col>
                <Col md={6}>
                  <h6>Önerilen Testler:</h6>
                  <ul>
                    {aiAnalysis.suggestedTests.map((test, index) => (
                      <li key={index}>{test}</li>
                    ))}
                  </ul>
                </Col>
              </Row>

              {aiAnalysis.relatedConditions && (
                <Alert variant="light">
                  <h6>İlgili Durumlar:</h6>
                  <div className="d-flex flex-wrap gap-1">
                    {aiAnalysis.relatedConditions.map((condition, index) => (
                      <Badge key={index} bg="secondary">{condition}</Badge>
                    ))}
                  </div>
                </Alert>
              )}

              {aiAnalysis.warningSigns && (
                <Alert variant="warning">
                  <h6>Dikkat Edilmesi Gerekenler:</h6>
                  <ul className="mb-0">
                    {aiAnalysis.warningSigns.map((sign, index) => (
                      <li key={index}>{sign}</li>
                    ))}
                  </ul>
                </Alert>
              )}
            </div>
          ) : (
            <div className="text-center py-4">
              <Brain size={48} className="text-muted mb-3" />
              <p>AI analizi yükleniyor...</p>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowAnalysis(false)}>
            Kapat
          </Button>
        </Modal.Footer>
      </Modal>
    </Card>
  );
};

export default ComplaintPanel;
