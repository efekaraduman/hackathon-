import React, { useState, useEffect } from 'react';
import { Activity, TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Download, Eye, Calendar } from 'lucide-react';

const LabResultsIntegration = ({ patient, onLabResultUpdate }) => {
  const [labResults, setLabResults] = useState([]);
  const [selectedTest, setSelectedTest] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [filterType, setFilterType] = useState('all');

  // Örnek lab sonuçları verileri
  useEffect(() => {
    const sampleLabResults = [
      {
        id: 1,
        date: '2024-01-15',
        testName: 'Kan Sayımı (Hemogram)',
        results: [
          { parameter: 'Hemoglobin', value: '14.2', unit: 'g/dL', normalRange: '12-16', status: 'normal' },
          { parameter: 'Hematokrit', value: '42.5', unit: '%', normalRange: '36-46', status: 'normal' },
          { parameter: 'Lökosit', value: '8500', unit: '/μL', normalRange: '4000-10000', status: 'normal' },
          { parameter: 'Trombosit', value: '320000', unit: '/μL', normalRange: '150000-450000', status: 'normal' }
        ],
        doctor: 'Dr. Ahmet Yılmaz',
        notes: 'Rutin kontrol',
        status: 'completed',
        patientId: patient?.id
      },
      {
        id: 2,
        date: '2024-01-10',
        testName: 'Biyokimya Paneli',
        results: [
          { parameter: 'Glukoz', value: '95', unit: 'mg/dL', normalRange: '70-100', status: 'normal' },
          { parameter: 'Kolesterol', value: '220', unit: 'mg/dL', normalRange: '<200', status: 'high' },
          { parameter: 'HDL', value: '45', unit: 'mg/dL', normalRange: '>40', status: 'normal' },
          { parameter: 'LDL', value: '145', unit: 'mg/dL', normalRange: '<100', status: 'high' },
          { parameter: 'Trigliserit', value: '180', unit: 'mg/dL', normalRange: '<150', status: 'high' }
        ],
        doctor: 'Dr. Mehmet Kaya',
        notes: 'Kardiyovasküler risk değerlendirmesi',
        status: 'completed',
        patientId: patient?.id
      },
      {
        id: 3,
        date: '2024-01-08',
        testName: 'Karaciğer Fonksiyon Testleri',
        results: [
          { parameter: 'ALT', value: '35', unit: 'U/L', normalRange: '<40', status: 'normal' },
          { parameter: 'AST', value: '28', unit: 'U/L', normalRange: '<40', status: 'normal' },
          { parameter: 'Bilirubin Total', value: '1.2', unit: 'mg/dL', normalRange: '<1.2', status: 'normal' },
          { parameter: 'Albumin', value: '4.2', unit: 'g/dL', normalRange: '3.5-5.0', status: 'normal' }
        ],
        doctor: 'Dr. Ayşe Demir',
        notes: 'Karaciğer sağlığı kontrolü',
        status: 'completed',
        patientId: patient?.id
      },
      {
        id: 4,
        date: '2024-01-05',
        testName: 'Böbrek Fonksiyon Testleri',
        results: [
          { parameter: 'Kreatinin', value: '1.1', unit: 'mg/dL', normalRange: '0.6-1.2', status: 'normal' },
          { parameter: 'BUN', value: '18', unit: 'mg/dL', normalRange: '7-20', status: 'normal' },
          { parameter: 'GFR', value: '85', unit: 'mL/min/1.73m²', normalRange: '>90', status: 'low' }
        ],
        doctor: 'Dr. Fatma Özkan',
        notes: 'Böbrek fonksiyon takibi',
        status: 'completed',
        patientId: patient?.id
      }
    ];
    setLabResults(sampleLabResults);
  }, [patient]);

  const testTypes = [
    { value: 'all', label: 'Tümü', count: labResults.length },
    { value: 'blood', label: 'Kan Testleri', count: labResults.filter(r => r.testName.includes('Kan')).length },
    { value: 'biochemistry', label: 'Biyokimya', count: labResults.filter(r => r.testName.includes('Biyokimya')).length },
    { value: 'liver', label: 'Karaciğer', count: labResults.filter(r => r.testName.includes('Karaciğer')).length },
    { value: 'kidney', label: 'Böbrek', count: labResults.filter(r => r.testName.includes('Böbrek')).length }
  ];

  const getStatusIcon = (status) => {
    switch (status) {
      case 'normal':
        return <CheckCircle size={16} className="text-success" />;
      case 'high':
        return <TrendingUp size={16} className="text-danger" />;
      case 'low':
        return <TrendingDown size={16} className="text-warning" />;
      default:
        return <AlertTriangle size={16} className="text-info" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'normal':
        return 'gov-badge-success';
      case 'high':
        return 'gov-badge-danger';
      case 'low':
        return 'gov-badge-warning';
      default:
        return 'gov-badge-info';
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'normal':
        return 'Normal';
      case 'high':
        return 'Yüksek';
      case 'low':
        return 'Düşük';
      default:
        return 'Bilinmiyor';
    }
  };

  const filteredResults = filterType === 'all' 
    ? labResults 
    : labResults.filter(result => {
        switch (filterType) {
          case 'blood':
            return result.testName.includes('Kan');
          case 'biochemistry':
            return result.testName.includes('Biyokimya');
          case 'liver':
            return result.testName.includes('Karaciğer');
          case 'kidney':
            return result.testName.includes('Böbrek');
          default:
            return true;
        }
      });

  const abnormalResults = labResults.flatMap(result => 
    result.results.filter(r => r.status !== 'normal')
  );

  const recentResults = labResults.filter(result => 
    new Date(result.date) >= new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
  );

  const handleViewDetails = (result) => {
    setSelectedTest(result);
    setShowModal(true);
  };

  return (
    <div className="gov-card">
      <div className="gov-card-header">
        <div className="d-flex align-items-center justify-content-between">
          <h6 className="mb-0">
            <Activity size={16} style={{ marginRight: '5px' }} />
            Lab Sonuçları
          </h6>
          <div className="d-flex gap-2">
            <button className="gov-btn gov-btn-sm gov-btn-outline-primary">
              <Download size={14} />
              Rapor İndir
            </button>
          </div>
        </div>
      </div>
      <div className="gov-card-body">
        {/* İstatistikler */}
        <div className="gov-stats mb-4">
          <div className="gov-stat">
            <div className="gov-stat-value">{labResults.length}</div>
            <div className="gov-stat-label">Toplam Test</div>
          </div>
          <div className="gov-stat">
            <div className="gov-stat-value">{recentResults.length}</div>
            <div className="gov-stat-label">Son 30 Gün</div>
          </div>
          <div className="gov-stat">
            <div className="gov-stat-value">{abnormalResults.length}</div>
            <div className="gov-stat-label">Anormal Sonuç</div>
          </div>
          <div className="gov-stat">
            <div className="gov-stat-value">
              {labResults.filter(r => r.status === 'pending').length}
            </div>
            <div className="gov-stat-label">Bekleyen</div>
          </div>
        </div>

        {/* Test Tipi Filtreleri */}
        <div className="gov-filters mb-4">
          {testTypes.map(type => (
            <span
              key={type.value}
              className={`gov-filter-tag ${filterType === type.value ? 'active' : ''}`}
              onClick={() => setFilterType(type.value)}
            >
              {type.label} ({type.count})
            </span>
          ))}
        </div>

        {/* Lab Sonuçları Listesi */}
        <div className="table-responsive">
          <table className="gov-table">
            <thead>
              <tr>
                <th>Tarih</th>
                <th>Test Adı</th>
                <th>Doktor</th>
                <th>Sonuç Durumu</th>
                <th>Notlar</th>
                <th>İşlemler</th>
              </tr>
            </thead>
            <tbody>
              {filteredResults.map(result => {
                const abnormalCount = result.results.filter(r => r.status !== 'normal').length;
                const hasAbnormal = abnormalCount > 0;
                
                return (
                  <tr key={result.id}>
                    <td>
                      <Calendar size={14} style={{ marginRight: '5px' }} />
                      {new Date(result.date).toLocaleDateString('tr-TR')}
                    </td>
                    <td>
                      <div className="d-flex align-items-center">
                        <Activity size={14} style={{ marginRight: '5px' }} />
                        {result.testName}
                      </div>
                    </td>
                    <td>{result.doctor}</td>
                    <td>
                      {hasAbnormal ? (
                        <span className="gov-badge gov-badge-warning">
                          <AlertTriangle size={12} className="me-1" />
                          {abnormalCount} Anormal
                        </span>
                      ) : (
                        <span className="gov-badge gov-badge-success">
                          <CheckCircle size={12} className="me-1" />
                          Normal
                        </span>
                      )}
                    </td>
                    <td>{result.notes}</td>
                    <td>
                      <div className="d-flex gap-1">
                        <button
                          className="gov-btn gov-btn-sm gov-btn-outline-primary"
                          onClick={() => handleViewDetails(result)}
                          title="Detayları Görüntüle"
                        >
                          <Eye size={12} />
                        </button>
                        <button
                          className="gov-btn gov-btn-sm gov-btn-outline-success"
                          title="Rapor İndir"
                        >
                          <Download size={12} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredResults.length === 0 && (
          <div className="text-center py-4">
            <Activity size={48} className="mb-3 text-muted" />
            <p className="text-muted">Seçilen kategoride lab sonucu bulunmuyor</p>
          </div>
        )}
      </div>

      {/* Lab Sonucu Detay Modal */}
      {showModal && selectedTest && (
        <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-xl">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  <Activity size={20} style={{ marginRight: '8px' }} />
                  {selectedTest.testName} - Detaylı Sonuçlar
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => {
                    setShowModal(false);
                    setSelectedTest(null);
                  }}
                ></button>
              </div>
              <div className="modal-body">
                <div className="row mb-4">
                  <div className="col-md-6">
                    <strong>Tarih:</strong> {new Date(selectedTest.date).toLocaleDateString('tr-TR')}
                  </div>
                  <div className="col-md-6">
                    <strong>Doktor:</strong> {selectedTest.doctor}
                  </div>
                </div>
                
                {selectedTest.notes && (
                  <div className="alert alert-info mb-4">
                    <strong>Notlar:</strong> {selectedTest.notes}
                  </div>
                )}

                <div className="table-responsive">
                  <table className="gov-table">
                    <thead>
                      <tr>
                        <th>Parametre</th>
                        <th>Sonuç</th>
                        <th>Birim</th>
                        <th>Normal Aralık</th>
                        <th>Durum</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedTest.results.map((result, index) => (
                        <tr key={index}>
                          <td>
                            <strong>{result.parameter}</strong>
                          </td>
                          <td>
                            <span className={`fw-bold ${
                              result.status === 'normal' ? 'text-success' : 
                              result.status === 'high' ? 'text-danger' : 'text-warning'
                            }`}>
                              {result.value}
                            </span>
                          </td>
                          <td>{result.unit}</td>
                          <td>{result.normalRange}</td>
                          <td>
                            <div className="d-flex align-items-center">
                              {getStatusIcon(result.status)}
                              <span className={`gov-badge ${getStatusColor(result.status)} ms-2`}>
                                {getStatusLabel(result.status)}
                              </span>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Anormal Sonuçlar Uyarısı */}
                {selectedTest.results.some(r => r.status !== 'normal') && (
                  <div className="alert alert-warning mt-4">
                    <AlertTriangle size={20} className="me-2" />
                    <strong>Dikkat:</strong> Bu testte anormal sonuçlar bulunmaktadır. 
                    Lütfen doktorunuzla görüşünüz.
                  </div>
                )}
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="gov-btn gov-btn-secondary"
                  onClick={() => {
                    setShowModal(false);
                    setSelectedTest(null);
                  }}
                >
                  Kapat
                </button>
                <button
                  type="button"
                  className="gov-btn gov-btn-primary"
                >
                  <Download size={16} />
                  Rapor İndir
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LabResultsIntegration;
