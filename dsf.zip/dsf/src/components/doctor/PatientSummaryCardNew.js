import React from 'react';
import { Row, Col, Alert } from 'react-bootstrap';
import { 
  User, 
  AlertTriangle, 
  Heart, 
  Activity, 
  Clock,
  Shield,
  TrendingUp,
  AlertCircle,
  Pill,
  Calendar,
  TestTube,
  Stethoscope,
  Brain
} from 'lucide-react';
import { calculateRiskScore, categorizePatient } from '../../utils/aiAnalysis';

const PatientSummaryCard = ({ patient, aiSummary }) => {
  if (!patient) return null;

  const riskScore = calculateRiskScore(patient);
  const riskCategory = categorizePatient(patient);
  const criticalAlerts = [];
  const warnings = [];

  // Kritik uyarıları tespit et
  if (patient.labResults) {
    patient.labResults.forEach(result => {
      if (result.status === 'Yüksek' && (result.testName.includes('HbA1c') || result.testName.includes('Kreatinin'))) {
        criticalAlerts.push(`${result.testName}: ${result.value} ${result.unit} (${result.status})`);
      }
    });
  }

  // İlaç uyarıları
  if (patient.medications && patient.medications.length > 6) {
    warnings.push(`${patient.medications.length} aktif ilaç - etkileşim riski`);
  }

  // Alerji uyarıları
  if (patient.allergies && patient.allergies.length > 0) {
    warnings.push(`${patient.allergies.length} alerji mevcut`);
  }

  // Yaş uyarıları
  if (patient.age > 70) {
    warnings.push('İleri yaş - yakın takip gerekli');
  }

  const getRiskColor = (category) => {
    switch (category) {
      case 'Yüksek Risk': return 'minimal-badge-danger';
      case 'Orta Risk': return 'minimal-badge-warning';
      default: return 'minimal-badge-success';
    }
  };

  const getRiskText = (category) => {
    switch (category) {
      case 'Yüksek Risk': return 'Yüksek Risk';
      case 'Orta Risk': return 'Orta Risk';
      default: return 'Düşük Risk';
    }
  };

  const getRiskScore = (category) => {
    switch (category) {
      case 'Yüksek Risk': return '8/10';
      case 'Orta Risk': return '5/10';
      default: return '2/10';
    }
  };

  return (
    <div className="minimal-card">
      <div className="minimal-card-header">
        <div className="d-flex justify-content-between align-items-center">
          <h4 className="minimal-card-title">
            <User size={24} />
            {patient.name} {patient.surname} - Hasta Özeti
          </h4>
          <span className={`minimal-badge ${getRiskColor(riskCategory)}`}>
            {getRiskText(riskCategory)} ({getRiskScore(riskCategory)})
          </span>
        </div>
      </div>
      
      <div className="minimal-card-body">
        <Row>
          {/* Sol Kolon - Temel Bilgiler */}
          <Col md={4}>
            <div className="patient-basic-info">
              <h6 className="minimal-card-title mb-3">
                <User size={18} />
                Temel Bilgiler
              </h6>
              
              <div className="info-item">
                <span className="info-label">Yaş:</span>
                <span className="info-value">{patient.age}</span>
              </div>
              
              <div className="info-item">
                <span className="info-label">Cinsiyet:</span>
                <span className="info-value">{patient.gender}</span>
              </div>
              
              <div className="info-item">
                <span className="info-label">TC:</span>
                <span className="info-value">{patient.tcNo}</span>
              </div>
              
              <div className="info-item">
                <span className="info-label">Telefon:</span>
                <span className="info-value">{patient.phone}</span>
              </div>
            </div>
          </Col>

          {/* Orta Kolon - Sağlık Bilgileri */}
          <Col md={4}>
            <div className="patient-health-info">
              <h6 className="minimal-card-title mb-3">
                <Heart size={18} />
                Sağlık Bilgileri
              </h6>
              
              {/* Kronik Hastalıklar */}
              <div className="info-section mb-3">
                <span className="info-label">Kronik Hastalıklar:</span>
                <div className="info-tags">
                  {patient.chronicDiseases && patient.chronicDiseases.map((disease, index) => (
                    <span key={index} className="minimal-badge minimal-badge-warning">
                      {disease}
                    </span>
                  ))}
                </div>
              </div>
              
              {/* Alerjiler */}
              <div className="info-section mb-3">
                <span className="info-label">Alerjiler:</span>
                <div className="info-tags">
                  {patient.allergies && patient.allergies.map((allergy, index) => (
                    <span key={index} className="minimal-badge minimal-badge-danger">
                      {allergy}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </Col>

          {/* Sağ Kolon - İstatistikler */}
          <Col md={4}>
            <div className="patient-stats">
              <h6 className="minimal-card-title mb-3">
                <Activity size={18} />
                İstatistikler
              </h6>
              
              <div className="minimal-stats">
                <div className="minimal-stat">
                  <div className="minimal-stat-value">
                    {patient.medications ? patient.medications.length : 0}
                  </div>
                  <div className="minimal-stat-label">İlaç</div>
                </div>
                <div className="minimal-stat">
                  <div className="minimal-stat-value">
                    {patient.surgeries ? patient.surgeries.length : 0}
                  </div>
                  <div className="minimal-stat-label">Operasyon</div>
                </div>
                <div className="minimal-stat">
                  <div className="minimal-stat-value">
                    {patient.appointments ? patient.appointments.length : 0}
                  </div>
                  <div className="minimal-stat-label">Randevu</div>
                </div>
              </div>
            </div>
          </Col>
        </Row>

        {/* Uyarılar */}
        {warnings.length > 0 && (
          <div className="mt-4">
            <h6 className="minimal-card-title mb-3">
              <AlertTriangle size={18} />
              Dikkat Edilmesi Gerekenler:
            </h6>
            <div className="warning-list">
              {warnings.map((warning, index) => (
                <div key={index} className="warning-item">
                  <AlertCircle size={16} className="me-2" style={{ color: 'var(--warning)' }} />
                  <span className="minimal-timeline-description">{warning}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* AI Analiz */}
        {aiSummary && (
          <div className="mt-4">
            <Alert variant="info" className="minimal-alert minimal-alert-info">
              <Brain size={20} className="me-2" />
              <strong>AI Analiz:</strong> {aiSummary.summary}
            </Alert>
          </div>
        )}
      </div>
    </div>
  );
};

export default PatientSummaryCard;
