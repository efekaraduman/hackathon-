import React, { useState } from 'react';
import { Button, ProgressBar, Alert, Modal, Form } from 'react-bootstrap';
import { 
  Brain, 
  CheckCircle, 
  XCircle, 
  Edit, 
  AlertTriangle, 
  Shield,
  TrendingUp,
  Activity,
  Clock,
  FileText,
  ThumbsUp,
  ThumbsDown,
  Target,
  Zap,
  Eye,
  Heart,
  Calendar
} from 'lucide-react';

const AdvancedAIPanel = ({ patient, aiSummary, drugInteractions, onApprovalChange }) => {
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [confidenceLevel, setConfidenceLevel] = useState('high');

  if (!patient) {
    return (
      <div className="minimal-card">
        <div className="minimal-card-body text-center py-5">
          <Brain size={64} className="mb-3" style={{ color: 'var(--primary-light)' }} />
          <h5 className="minimal-card-title">AI Analiz Paneli</h5>
          <p className="minimal-timeline-description">Hasta seçildiğinde AI analizi burada görünecek</p>
        </div>
      </div>
    );
  }

  // Güven seviyesi hesaplama
  const calculateConfidenceLevel = () => {
    let confidence = 0;
    let factors = [];

    // Veri kalitesi faktörleri
    if (patient.medications && patient.medications.length >= 3) {
      confidence += 20;
      factors.push('Yeterli ilaç verisi');
    }
    
    if (patient.labResults && patient.labResults.length >= 2) {
      confidence += 20;
      factors.push('Laboratuvar verileri mevcut');
    }
    
    if (patient.appointments && patient.appointments.length >= 1) {
      confidence += 15;
      factors.push('Randevu geçmişi var');
    }
    
    if (patient.allergies && patient.allergies.length > 0) {
      confidence += 15;
      factors.push('Alerji bilgileri mevcut');
    }
    
    if (patient.chronicDiseases && patient.chronicDiseases.length > 0) {
      confidence += 15;
      factors.push('Kronik hastalık bilgisi mevcut');
    }
    
    if (patient.surgeries && patient.surgeries.length > 0) {
      confidence += 10;
      factors.push('Operasyon geçmişi var');
    }
    
    if (patient.medications && patient.medications.length <= 2) {
      confidence += 5;
      factors.push('Sınırlı doktor sayısı');
    }

    return { confidence: Math.min(confidence, 100), factors };
  };

  const confidenceData = calculateConfidenceLevel();
  const confidenceText = confidenceData.confidence >= 80 ? 'Yüksek Güven' : 
                        confidenceData.confidence >= 60 ? 'Orta Güven' : 'Düşük Güven';

  const getConfidenceColor = () => {
    if (confidenceData.confidence >= 80) return 'var(--success)';
    if (confidenceData.confidence >= 60) return 'var(--warning)';
    return 'var(--danger)';
  };

  const getRiskLevel = () => {
    const riskFactors = [];
    
    if (patient.allergies && patient.allergies.length > 1) {
      riskFactors.push('Çoklu alerji');
    }
    
    if (patient.medications && patient.medications.length > 5) {
      riskFactors.push('Çoklu ilaç kullanımı');
    }
    
    if (patient.age > 65) {
      riskFactors.push('İleri yaş');
    }
    
    if (patient.chronicDiseases && patient.chronicDiseases.length > 2) {
      riskFactors.push('Çoklu kronik hastalık');
    }

    return riskFactors;
  };

  const riskFactors = getRiskLevel();
  const riskLevel = riskFactors.length > 2 ? 'Yüksek' : riskFactors.length > 1 ? 'Orta' : 'Düşük';

  const getRiskColor = () => {
    if (riskLevel === 'Yüksek') return 'minimal-badge-danger';
    if (riskLevel === 'Orta') return 'minimal-badge-warning';
    return 'minimal-badge-success';
  };

  const getRecommendations = () => {
    const recommendations = [];
    
    if (patient.medications && patient.medications.length > 0) {
      recommendations.push({
        icon: CheckCircle,
        text: 'Düzenli ilaç takibi yapılmalı',
        type: 'success'
      });
    }
    
    if (patient.labResults && patient.labResults.some(r => r.status === 'Yüksek')) {
      recommendations.push({
        icon: AlertTriangle,
        text: 'Laboratuvar değerleri yakından izlenmeli',
        type: 'warning'
      });
    }
    
    if (patient.allergies && patient.allergies.length > 0) {
      recommendations.push({
        icon: Shield,
        text: 'Hasta eğitimi verilmeli',
        type: 'info'
      });
    }
    
    if (patient.appointments && patient.appointments.length < 2) {
      recommendations.push({
        icon: Calendar,
        text: 'Randevu takvimi güncellenmeli',
        type: 'info'
      });
    }

    return recommendations;
  };

  const recommendations = getRecommendations();

  const handleApproval = (type) => {
    if (onApprovalChange) {
      onApprovalChange({
        type,
        timestamp: new Date().toISOString(),
        patientId: patient.id
      });
    }
  };

  return (
    <>
      <div className="minimal-card">
        <div className="minimal-card-header">
          <h5 className="minimal-card-title">
            <Brain size={20} />
            AI Analiz Paneli
          </h5>
        </div>
        
        <div className="minimal-card-body">
          {/* Güven Seviyesi */}
          <div className="confidence-section mb-4">
            <div className="d-flex justify-content-between align-items-center mb-2">
              <span className="minimal-label">Güven Seviyesi:</span>
              <span className={`minimal-badge ${confidenceData.confidence >= 80 ? 'minimal-badge-success' : confidenceData.confidence >= 60 ? 'minimal-badge-warning' : 'minimal-badge-danger'}`}>
                {confidenceText}
              </span>
            </div>
            <div className="minimal-progress mb-2">
              <div 
                className="minimal-progress-bar"
                style={{ 
                  width: `${confidenceData.confidence}%`,
                  backgroundColor: getConfidenceColor()
                }}
              ></div>
            </div>
            <div className="text-center">
              <span className="minimal-stat-value">{confidenceData.confidence}%</span>
              <span className="minimal-stat-label">Güven</span>
            </div>
          </div>

          {/* Güven Faktörleri */}
          <div className="confidence-factors mb-4">
            <h6 className="minimal-card-title mb-3">
              <Shield size={18} />
              Güven Faktörleri:
            </h6>
            <div className="factors-list">
              {confidenceData.factors.map((factor, index) => (
                <div key={index} className="factor-item">
                  <CheckCircle size={16} className="me-2" style={{ color: 'var(--success)' }} />
                  <span className="minimal-timeline-description">{factor}</span>
                </div>
              ))}
            </div>
          </div>

          {/* AI Hasta Özeti */}
          <div className="ai-summary mb-4">
            <h6 className="minimal-card-title mb-3">
              <Brain size={18} />
              AI Hasta Özeti
            </h6>
            
            <div className="summary-content">
              <div className="mb-3">
                <span className="minimal-label">Risk Seviyesi:</span>
                <span className={`minimal-badge ${getRiskColor()} ms-2`}>
                  {riskLevel}
                </span>
              </div>
              
              <div className="mb-3">
                <span className="minimal-label">Ana Problemler:</span>
                <ul className="mt-2">
                  {riskFactors.map((factor, index) => (
                    <li key={index} className="minimal-timeline-description">
                      <AlertTriangle size={14} className="me-1" style={{ color: 'var(--warning)' }} />
                      {factor}
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="mb-3">
                <span className="minimal-label">Öneriler:</span>
                <p className="minimal-timeline-description mt-2">
                  Hasta düzenli aralıklarla kontrol edilmeli ve ilaç uyumu takip edilmelidir.
                </p>
              </div>
            </div>
          </div>

          {/* Hasta İstatistikleri */}
          <div className="patient-stats mb-4">
            <h6 className="minimal-card-title mb-3">
              <Activity size={18} />
              Hasta İstatistikleri
            </h6>
            
            <div className="minimal-stats">
              <div className="minimal-stat">
                <div className="minimal-stat-value">
                  {patient.medications ? patient.medications.length : 0}
                </div>
                <div className="minimal-stat-label">Aktif İlaç</div>
              </div>
              <div className="minimal-stat">
                <div className="minimal-stat-value">
                  {patient.chronicDiseases ? patient.chronicDiseases.length : 0}
                </div>
                <div className="minimal-stat-label">Kronik Hastalık</div>
              </div>
              <div className="minimal-stat">
                <div className="minimal-stat-value">
                  {patient.allergies ? patient.allergies.length : 0}
                </div>
                <div className="minimal-stat-label">Alerji</div>
              </div>
              <div className="minimal-stat">
                <div className="minimal-stat-value">
                  {patient.surgeries ? patient.surgeries.length : 0}
                </div>
                <div className="minimal-stat-label">Operasyon</div>
              </div>
            </div>
          </div>

          {/* Doktor Onayı */}
          <div className="doctor-approval mb-4">
            <h6 className="minimal-card-title mb-3">
              <Target size={18} />
              Doktor Onayı
            </h6>
            
            <div className="d-flex gap-2">
              <button
                className="minimal-btn minimal-btn-success"
                onClick={() => handleApproval('approve')}
              >
                <CheckCircle size={16} />
                Onayla
              </button>
              <button
                className="minimal-btn minimal-btn-warning"
                onClick={() => setShowFeedbackModal(true)}
              >
                <Edit size={16} />
                Düzenle
              </button>
              <button
                className="minimal-btn minimal-btn-danger"
                onClick={() => handleApproval('reject')}
              >
                <XCircle size={16} />
                Reddet
              </button>
            </div>
          </div>

          {/* AI Önerileri */}
          <div className="ai-recommendations">
            <h6 className="minimal-card-title mb-3">
              <Zap size={18} />
              AI Önerileri
            </h6>
            
            <div className="recommendations-list">
              {recommendations.map((rec, index) => {
                const IconComponent = rec.icon;
                return (
                  <div key={index} className="recommendation-item">
                    <IconComponent size={16} className="me-2" style={{ color: 'var(--primary-light)' }} />
                    <span className="minimal-timeline-description">{rec.text}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Feedback Modal */}
      <Modal show={showFeedbackModal} onHide={() => setShowFeedbackModal(false)}>
        <Modal.Header closeButton className="minimal-card-header">
          <Modal.Title className="minimal-card-title">
            <Edit size={20} />
            AI Analiz Geri Bildirimi
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className="minimal-card-body">
          <Form>
            <div className="minimal-form-group">
              <label className="minimal-label">Geri Bildirim:</label>
              <textarea
                className="minimal-input"
                rows={4}
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                placeholder="AI analizi hakkında geri bildiriminizi yazın..."
              />
            </div>
          </Form>
        </Modal.Body>
        <Modal.Footer className="minimal-card-header">
          <button 
            className="minimal-btn minimal-btn-secondary"
            onClick={() => setShowFeedbackModal(false)}
          >
            İptal
          </button>
          <button 
            className="minimal-btn minimal-btn-primary"
            onClick={() => {
              handleApproval('feedback');
              setShowFeedbackModal(false);
            }}
          >
            Gönder
          </button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default AdvancedAIPanel;
