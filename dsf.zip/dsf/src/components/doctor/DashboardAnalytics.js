import React, { useState, useEffect } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import { Line, Bar, Doughnut } from 'react-chartjs-2';
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  Activity, 
  AlertTriangle, 
  CheckCircle,
  Calendar,
  Pill,
  Heart,
  Brain
} from 'lucide-react';

// Chart.js kayıt
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

const DashboardAnalytics = ({ patient, allPatients }) => {
  const [dashboardData, setDashboardData] = useState({
    patientStats: {},
    medicationTrends: [],
    labResults: [],
    appointmentStats: [],
    healthMetrics: []
  });

  // Örnek dashboard verileri
  useEffect(() => {
    const sampleData = {
      patientStats: {
        totalPatients: allPatients?.length || 150,
        activePatients: 120,
        newPatients: 15,
        criticalPatients: 8
      },
      medicationTrends: [
        { month: 'Ocak', prescriptions: 45, interactions: 3 },
        { month: 'Şubat', prescriptions: 52, interactions: 2 },
        { month: 'Mart', prescriptions: 48, interactions: 4 },
        { month: 'Nisan', prescriptions: 61, interactions: 1 },
        { month: 'Mayıs', prescriptions: 55, interactions: 3 },
        { month: 'Haziran', prescriptions: 58, interactions: 2 }
      ],
      labResults: [
        { test: 'Kan Sayımı', normal: 85, abnormal: 15 },
        { test: 'Biyokimya', normal: 78, abnormal: 22 },
        { test: 'Karaciğer', normal: 92, abnormal: 8 },
        { test: 'Böbrek', normal: 88, abnormal: 12 }
      ],
      appointmentStats: [
        { day: 'Pzt', appointments: 12, completed: 10 },
        { day: 'Sal', appointments: 15, completed: 14 },
        { day: 'Çar', appointments: 18, completed: 16 },
        { day: 'Per', appointments: 14, completed: 13 },
        { day: 'Cum', appointments: 16, completed: 15 },
        { day: 'Cmt', appointments: 8, completed: 7 },
        { day: 'Paz', appointments: 3, completed: 3 }
      ],
      healthMetrics: [
        { metric: 'Ortalama Yaş', value: '45.2', unit: 'yaş', trend: 'up', change: '+2.1' },
        { metric: 'Kronik Hastalık', value: '68%', unit: '', trend: 'down', change: '-5.2' },
        { metric: 'İlaç Etkileşimi', value: '12', unit: 'vaka', trend: 'down', change: '-3' },
        { metric: 'Randevu Tamamlama', value: '94%', unit: '', trend: 'up', change: '+1.8' }
      ]
    };
    setDashboardData(sampleData);
  }, [allPatients]);

  // Grafik verileri
  const medicationChartData = {
    labels: dashboardData.medicationTrends.map(item => item.month),
    datasets: [
      {
        label: 'Reçete Sayısı',
        data: dashboardData.medicationTrends.map(item => item.prescriptions),
        borderColor: 'rgb(13, 110, 253)',
        backgroundColor: 'rgba(13, 110, 253, 0.1)',
        tension: 0.4
      },
      {
        label: 'İlaç Etkileşimi',
        data: dashboardData.medicationTrends.map(item => item.interactions),
        borderColor: 'rgb(220, 53, 69)',
        backgroundColor: 'rgba(220, 53, 69, 0.1)',
        tension: 0.4
      }
    ]
  };

  const appointmentChartData = {
    labels: dashboardData.appointmentStats.map(item => item.day),
    datasets: [
      {
        label: 'Planlanan Randevular',
        data: dashboardData.appointmentStats.map(item => item.appointments),
        backgroundColor: 'rgba(13, 110, 253, 0.8)',
      },
      {
        label: 'Tamamlanan Randevular',
        data: dashboardData.appointmentStats.map(item => item.completed),
        backgroundColor: 'rgba(25, 135, 84, 0.8)',
      }
    ]
  };

  const labResultsChartData = {
    labels: dashboardData.labResults.map(item => item.test),
    datasets: [
      {
        label: 'Normal Sonuçlar',
        data: dashboardData.labResults.map(item => item.normal),
        backgroundColor: [
          'rgba(25, 135, 84, 0.8)',
          'rgba(13, 110, 253, 0.8)',
          'rgba(253, 126, 20, 0.8)',
          'rgba(13, 202, 240, 0.8)'
        ],
      },
      {
        label: 'Anormal Sonuçlar',
        data: dashboardData.labResults.map(item => item.abnormal),
        backgroundColor: [
          'rgba(220, 53, 69, 0.8)',
          'rgba(108, 117, 125, 0.8)',
          'rgba(255, 193, 7, 0.8)',
          'rgba(111, 66, 193, 0.8)'
        ],
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Hasta Veri Analizi'
      }
    },
    scales: {
      y: {
        beginAtZero: true
      }
    }
  };

  const doughnutOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom',
      }
    }
  };

  const getTrendIcon = (trend) => {
    return trend === 'up' ? 
      <TrendingUp size={16} className="text-success" /> : 
      <TrendingDown size={16} className="text-danger" />;
  };

  const getTrendColor = (trend) => {
    return trend === 'up' ? 'text-success' : 'text-danger';
  };

  return (
    <div className="gov-card">
      <div className="gov-card-header">
        <h6 className="mb-0">
          <Brain size={16} style={{ marginRight: '5px' }} />
          Dashboard ve Analitik
        </h6>
      </div>
      <div className="gov-card-body">
        {/* KPI Kartları */}
        <div className="row mb-4">
          <div className="col-md-3">
            <div className="gov-card">
              <div className="gov-card-body text-center">
                <Users size={32} className="text-primary mb-2" />
                <h4 className="mb-1">{dashboardData.patientStats.totalPatients}</h4>
                <p className="mb-0 text-muted">Toplam Hasta</p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="gov-card">
              <div className="gov-card-body text-center">
                <Activity size={32} className="text-success mb-2" />
                <h4 className="mb-1">{dashboardData.patientStats.activePatients}</h4>
                <p className="mb-0 text-muted">Aktif Hasta</p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="gov-card">
              <div className="gov-card-body text-center">
                <AlertTriangle size={32} className="text-warning mb-2" />
                <h4 className="mb-1">{dashboardData.patientStats.criticalPatients}</h4>
                <p className="mb-0 text-muted">Kritik Hasta</p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="gov-card">
              <div className="gov-card-body text-center">
                <CheckCircle size={32} className="text-info mb-2" />
                <h4 className="mb-1">{dashboardData.patientStats.newPatients}</h4>
                <p className="mb-0 text-muted">Yeni Hasta</p>
              </div>
            </div>
          </div>
        </div>

        {/* Sağlık Metrikleri */}
        <div className="row mb-4">
          {dashboardData.healthMetrics.map((metric, index) => (
            <div key={index} className="col-md-3">
              <div className="gov-card">
                <div className="gov-card-body">
                  <div className="d-flex align-items-center justify-content-between">
                    <div>
                      <h6 className="mb-1">{metric.metric}</h6>
                      <h4 className="mb-0">{metric.value} {metric.unit}</h4>
                    </div>
                    <div className="text-end">
                      {getTrendIcon(metric.trend)}
                      <small className={`d-block ${getTrendColor(metric.trend)}`}>
                        {metric.change}
                      </small>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Grafikler */}
        <div className="row">
          {/* Reçete Trendleri */}
          <div className="col-md-6 mb-4">
            <div className="gov-card">
              <div className="gov-card-header">
                <h6 className="mb-0">
                  <Pill size={16} style={{ marginRight: '5px' }} />
                  Reçete Trendleri
                </h6>
              </div>
              <div className="gov-card-body">
                <Line data={medicationChartData} options={chartOptions} />
              </div>
            </div>
          </div>

          {/* Randevu İstatistikleri */}
          <div className="col-md-6 mb-4">
            <div className="gov-card">
              <div className="gov-card-header">
                <h6 className="mb-0">
                  <Calendar size={16} style={{ marginRight: '5px' }} />
                  Haftalık Randevular
                </h6>
              </div>
              <div className="gov-card-body">
                <Bar data={appointmentChartData} options={chartOptions} />
              </div>
            </div>
          </div>
        </div>

        <div className="row">
          {/* Lab Sonuçları Dağılımı */}
          <div className="col-md-6 mb-4">
            <div className="gov-card">
              <div className="gov-card-header">
                <h6 className="mb-0">
                  <Activity size={16} style={{ marginRight: '5px' }} />
                  Lab Sonuçları Dağılımı
                </h6>
              </div>
              <div className="gov-card-body">
                <Doughnut data={labResultsChartData} options={doughnutOptions} />
              </div>
            </div>
          </div>

          {/* Hasta Yaş Dağılımı */}
          <div className="col-md-6 mb-4">
            <div className="gov-card">
              <div className="gov-card-header">
                <h6 className="mb-0">
                  <Heart size={16} style={{ marginRight: '5px' }} />
                  Hasta Yaş Dağılımı
                </h6>
              </div>
              <div className="gov-card-body">
                <div className="text-center py-4">
                  <div className="row">
                    <div className="col-6">
                      <div className="gov-stat">
                        <div className="gov-stat-value">25%</div>
                        <div className="gov-stat-label">0-30 Yaş</div>
                      </div>
                    </div>
                    <div className="col-6">
                      <div className="gov-stat">
                        <div className="gov-stat-value">35%</div>
                        <div className="gov-stat-label">31-50 Yaş</div>
                      </div>
                    </div>
                    <div className="col-6">
                      <div className="gov-stat">
                        <div className="gov-stat-value">30%</div>
                        <div className="gov-stat-label">51-70 Yaş</div>
                      </div>
                    </div>
                    <div className="col-6">
                      <div className="gov-stat">
                        <div className="gov-stat-value">10%</div>
                        <div className="gov-stat-label">70+ Yaş</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Özet Tablo */}
        <div className="gov-card">
          <div className="gov-card-header">
            <h6 className="mb-0">Haftalık Özet</h6>
          </div>
          <div className="gov-card-body">
            <div className="table-responsive">
              <table className="gov-table">
                <thead>
                  <tr>
                    <th>Kategori</th>
                    <th>Bu Hafta</th>
                    <th>Geçen Hafta</th>
                    <th>Değişim</th>
                    <th>Trend</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Yeni Hasta</td>
                    <td>15</td>
                    <td>12</td>
                    <td>+3</td>
                    <td><TrendingUp size={16} className="text-success" /></td>
                  </tr>
                  <tr>
                    <td>Randevu</td>
                    <td>86</td>
                    <td>92</td>
                    <td>-6</td>
                    <td><TrendingDown size={16} className="text-danger" /></td>
                  </tr>
                  <tr>
                    <td>Reçete</td>
                    <td>58</td>
                    <td>55</td>
                    <td>+3</td>
                    <td><TrendingUp size={16} className="text-success" /></td>
                  </tr>
                  <tr>
                    <td>Lab Testi</td>
                    <td>42</td>
                    <td>38</td>
                    <td>+4</td>
                    <td><TrendingUp size={16} className="text-success" /></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardAnalytics;
