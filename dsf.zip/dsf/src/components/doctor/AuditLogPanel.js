import React, { useState, useEffect } from 'react';
import { Card, Table, Badge, Button, Form, Row, Col, Modal, Alert } from 'react-bootstrap';
import { 
  FileText, 
  Download, 
  Filter, 
  Search, 
  Calendar,
  User,
  Activity,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Edit
} from 'lucide-react';
import auditLogger from '../../utils/auditLog';

const AuditLogPanel = ({ patientId, show, onHide }) => {
  const [logs, setLogs] = useState([]);
  const [filteredLogs, setFilteredLogs] = useState([]);
  const [filters, setFilters] = useState({
    action: '',
    type: '',
    dateFrom: '',
    dateTo: ''
  });
  const [statistics, setStatistics] = useState(null);

  useEffect(() => {
    if (show) {
      loadLogs();
      loadStatistics();
    }
  }, [show, patientId]);

  useEffect(() => {
    applyFilters();
  }, [logs, filters]);

  const loadLogs = () => {
    const logFilter = patientId ? { patientId } : {};
    const allLogs = auditLogger.getLogs(logFilter);
    setLogs(allLogs.map(log => auditLogger.formatLog(log)));
  };

  const loadStatistics = () => {
    const stats = auditLogger.getStatistics();
    setStatistics(stats);
  };

  const applyFilters = () => {
    let filtered = [...logs];

    if (filters.action) {
      filtered = filtered.filter(log => log.action === filters.action);
    }

    if (filters.type) {
      filtered = filtered.filter(log => log.details.type === filters.type);
    }

    if (filters.dateFrom) {
      filtered = filtered.filter(log => 
        new Date(log.timestamp) >= new Date(filters.dateFrom)
      );
    }

    if (filters.dateTo) {
      filtered = filtered.filter(log => 
        new Date(log.timestamp) <= new Date(filters.dateTo)
      );
    }

    setFilteredLogs(filtered);
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({
      action: '',
      type: '',
      dateFrom: '',
      dateTo: ''
    });
  };

  const exportLogs = (format) => {
    const data = auditLogger.exportLogs(format);
    const blob = new Blob([data], { 
      type: format === 'json' ? 'application/json' : 'text/csv' 
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit_logs_${new Date().toISOString().split('T')[0]}.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getActionIcon = (action) => {
    switch (action) {
      case 'PATIENT_APPROVAL': return CheckCircle;
      case 'MEDICATION_CHANGE': return Edit;
      case 'AI_ANALYSIS': return Activity;
      case 'DATA_ACCESS': return FileText;
      case 'USER_LOGIN': return User;
      case 'SYSTEM_ERROR': return AlertTriangle;
      default: return Activity;
    }
  };

  const getActionColor = (action) => {
    switch (action) {
      case 'PATIENT_APPROVAL': return 'success';
      case 'MEDICATION_CHANGE': return 'warning';
      case 'AI_ANALYSIS': return 'info';
      case 'DATA_ACCESS': return 'primary';
      case 'USER_LOGIN': return 'secondary';
      case 'SYSTEM_ERROR': return 'danger';
      default: return 'secondary';
    }
  };

  if (!show) return null;

  return (
    <Modal show={show} onHide={onHide} size="xl">
      <Modal.Header closeButton>
        <Modal.Title>
          <FileText size={20} style={{ marginRight: '8px' }} />
          Audit Log - {patientId ? `Hasta: ${patientId}` : 'Tüm Loglar'}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {/* İstatistikler */}
        {statistics && (
          <Row className="mb-4">
            <Col md={3}>
              <Card className="text-center">
                <Card.Body>
                  <h5 className="text-primary">{statistics.totalLogs}</h5>
                  <small className="text-muted">Toplam Log</small>
                </Card.Body>
              </Card>
            </Col>
            <Col md={3}>
              <Card className="text-center">
                <Card.Body>
                  <h5 className="text-success">{statistics.byAction.PATIENT_APPROVAL || 0}</h5>
                  <small className="text-muted">Onay Değişikliği</small>
                </Card.Body>
              </Card>
            </Col>
            <Col md={3}>
              <Card className="text-center">
                <Card.Body>
                  <h5 className="text-warning">{statistics.byAction.MEDICATION_CHANGE || 0}</h5>
                  <small className="text-muted">İlaç Değişikliği</small>
                </Card.Body>
              </Card>
            </Col>
            <Col md={3}>
              <Card className="text-center">
                <Card.Body>
                  <h5 className="text-info">{statistics.byAction.AI_ANALYSIS || 0}</h5>
                  <small className="text-muted">AI Analizi</small>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        )}

        {/* Filtreler */}
        <Card className="mb-4">
          <Card.Header>
            <h6 className="mb-0">
              <Filter size={16} style={{ marginRight: '5px' }} />
              Filtreler
            </h6>
          </Card.Header>
          <Card.Body>
            <Row>
              <Col md={3}>
                <Form.Select
                  value={filters.action}
                  onChange={(e) => handleFilterChange('action', e.target.value)}
                >
                  <option value="">Tüm Aksiyonlar</option>
                  <option value="PATIENT_APPROVAL">Hasta Onayı</option>
                  <option value="MEDICATION_CHANGE">İlaç Değişikliği</option>
                  <option value="AI_ANALYSIS">AI Analizi</option>
                  <option value="DATA_ACCESS">Veri Erişimi</option>
                  <option value="USER_LOGIN">Kullanıcı Girişi</option>
                  <option value="SYSTEM_ERROR">Sistem Hatası</option>
                </Form.Select>
              </Col>
              <Col md={3}>
                <Form.Select
                  value={filters.type}
                  onChange={(e) => handleFilterChange('type', e.target.value)}
                >
                  <option value="">Tüm Tipler</option>
                  <option value="approval_change">Onay Değişikliği</option>
                  <option value="medication_update">İlaç Güncelleme</option>
                  <option value="ai_analysis">AI Analiz</option>
                  <option value="data_access">Veri Erişimi</option>
                  <option value="authentication">Kimlik Doğrulama</option>
                  <option value="system_error">Sistem Hatası</option>
                </Form.Select>
              </Col>
              <Col md={2}>
                <Form.Control
                  type="date"
                  value={filters.dateFrom}
                  onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
                  placeholder="Başlangıç"
                />
              </Col>
              <Col md={2}>
                <Form.Control
                  type="date"
                  value={filters.dateTo}
                  onChange={(e) => handleFilterChange('dateTo', e.target.value)}
                  placeholder="Bitiş"
                />
              </Col>
              <Col md={2}>
                <div className="d-flex gap-1">
                  <Button variant="outline-secondary" size="sm" onClick={clearFilters}>
                    <XCircle size={14} />
                  </Button>
                  <Button variant="outline-primary" size="sm" onClick={() => exportLogs('json')}>
                    <Download size={14} />
                  </Button>
                </div>
              </Col>
            </Row>
          </Card.Body>
        </Card>

        {/* Log Tablosu */}
        <div className="table-responsive">
          <Table striped hover>
            <thead>
              <tr>
                <th>Zaman</th>
                <th>Aksiyon</th>
                <th>Tip</th>
                <th>Hasta ID</th>
                <th>Detaylar</th>
                <th>Session</th>
              </tr>
            </thead>
            <tbody>
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center text-muted py-4">
                    <FileText size={48} className="mb-3" />
                    <p>Log bulunamadı</p>
                  </td>
                </tr>
              ) : (
                filteredLogs.map(log => {
                  const ActionIcon = getActionIcon(log.action);
                  return (
                    <tr key={log.id}>
                      <td>
                        <small>{log.formattedTime}</small>
                      </td>
                      <td>
                        <Badge bg={getActionColor(log.action)}>
                          <ActionIcon size={12} style={{ marginRight: '4px' }} />
                          {log.actionText}
                        </Badge>
                      </td>
                      <td>
                        <Badge bg="secondary">{log.typeText}</Badge>
                      </td>
                      <td>
                        <code>{log.details.patientId || '-'}</code>
                      </td>
                      <td>
                        <div className="log-details">
                          {log.action === 'PATIENT_APPROVAL' && (
                            <div>
                              <strong>Aksiyon:</strong> {log.details.action}<br/>
                              <strong>Güven:</strong> {log.details.confidence}%<br/>
                              {log.details.feedback && (
                                <>
                                  <strong>Geri Bildirim:</strong> {log.details.feedback}
                                </>
                              )}
                            </div>
                          )}
                          {log.action === 'MEDICATION_CHANGE' && (
                            <div>
                              <strong>İlaç ID:</strong> {log.details.medicationId}<br/>
                              <strong>Değişiklik:</strong> {JSON.stringify(log.details.newData)}
                            </div>
                          )}
                          {log.action === 'AI_ANALYSIS' && (
                            <div>
                              <strong>Analiz Tipi:</strong> {log.details.analysisType}<br/>
                              <strong>Güven:</strong> {log.details.confidence}%
                            </div>
                          )}
                          {log.action === 'DATA_ACCESS' && (
                            <div>
                              <strong>Veri Tipi:</strong> {log.details.dataType}<br/>
                              <strong>Erişim:</strong> {log.details.accessType}
                            </div>
                          )}
                          {log.action === 'USER_LOGIN' && (
                            <div>
                              <strong>Kullanıcı:</strong> {log.details.userId}<br/>
                              <strong>Rol:</strong> {log.details.role}<br/>
                              <strong>Başarı:</strong> {log.details.success ? 'Evet' : 'Hayır'}
                            </div>
                          )}
                          {log.action === 'SYSTEM_ERROR' && (
                            <div>
                              <strong>Hata:</strong> {log.details.error}<br/>
                              <strong>Bağlam:</strong> {log.details.context}
                            </div>
                          )}
                        </div>
                      </td>
                      <td>
                        <small className="text-muted">
                          {log.sessionId?.substring(0, 8)}...
                        </small>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </Table>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="outline-secondary" onClick={onHide}>
          Kapat
        </Button>
        <Button variant="outline-primary" onClick={() => exportLogs('csv')}>
          <Download size={16} style={{ marginRight: '5px' }} />
          CSV İndir
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default AuditLogPanel;
