import React, { useState } from 'react';
import { Card, Button, Badge, ProgressBar, Alert, Modal, Form } from 'react-bootstrap';
import { 
  Brain, 
  CheckCircle, 
  XCircle, 
  Edit, 
  AlertTriangle, 
  Shield,
  TrendingUp,
  Activity,
  Clock,
  FileText,
  ThumbsUp,
  ThumbsDown
} from 'lucide-react';

const AdvancedAIPanel = ({ patient, aiSummary, drugInteractions, onApprovalChange }) => {
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [confidenceLevel, setConfidenceLevel] = useState('high');

  if (!patient) {
    return (
      <div className="ai-panel">
        <div className="text-center text-muted py-5">
          <Brain size={64} className="mb-3" />
          <h5>AI Analiz Paneli</h5>
          <p>Hasta seçildiğinde AI analizi burada görünecek</p>
        </div>
      </div>
    );
  }

  // Güven seviyesi hesaplama
  const calculateConfidenceLevel = () => {
    let confidence = 0;
    let factors = [];

    // Veri kalitesi faktörleri
    if (patient.medications.length >= 3) {
      confidence += 20;
      factors.push('Yeterli ilaç verisi');
    }
    
    if (patient.labResults.length >= 2) {
      confidence += 20;
      factors.push('Laboratuvar verileri mevcut');
    }
    
    if (patient.appointments.length >= 1) {
      confidence += 15;
      factors.push('Randevu geçmişi var');
    }
    
    if (patient.allergies.length > 0) {
      confidence += 10;
      factors.push('Alerji bilgileri mevcut');
    }
    
    if (patient.surgeries.length > 0) {
      confidence += 10;
      factors.push('Operasyon geçmişi var');
    }
    
    // Tutarlılık faktörleri
    const uniqueCities = new Set(patient.medications.map(med => med.city));
    if (uniqueCities.size <= 2) {
      confidence += 15;
      factors.push('Tutarlı veri kaynakları');
    }
    
    const uniqueDoctors = new Set(patient.medications.map(med => med.prescribingDoctor));
    if (uniqueDoctors.size <= 3) {
      confidence += 10;
      factors.push('Sınırlı doktor sayısı');
    }

    let level = 'low';
    if (confidence >= 80) level = 'high';
    else if (confidence >= 60) level = 'medium';

    return { confidence, level, factors };
  };

  const confidenceData = calculateConfidenceLevel();

  const getConfidenceColor = (level) => {
    switch (level) {
      case 'high': return 'success';
      case 'medium': return 'warning';
      default: return 'danger';
    }
  };

  const getConfidenceText = (level) => {
    switch (level) {
      case 'high': return 'Yüksek Güven';
      case 'medium': return 'Orta Güven';
      default: return 'Düşük Güven';
    }
  };

  const handleApproval = (action) => {
    if (onApprovalChange) {
      onApprovalChange({
        action,
        timestamp: new Date().toISOString(),
        patientId: patient.id,
        confidence: confidenceData.confidence,
        feedback: feedback
      });
    }

    // Bildirim göster
    if (window.showNotification) {
      switch (action) {
        case 'approve':
          window.showNotification(
            'success',
            'Onay Başarılı',
            `${patient.name} ${patient.surname} adlı hastanın verileri başarıyla onaylandı.`,
            5000
          );
          break;
        case 'reject':
          window.showNotification(
            'error',
            'Onay Reddedildi',
            `${patient.name} ${patient.surname} adlı hastanın verileri reddedildi.`,
            5000
          );
          break;
        case 'modify':
          window.showNotification(
            'edit',
            'Düzenleme Gerekli',
            `${patient.name} ${patient.surname} adlı hastanın verileri düzenleme için işaretlendi.`,
            5000
          );
          break;
        case 'feedback':
          window.showNotification(
            'info',
            'Geri Bildirim Gönderildi',
            'AI analiz geri bildiriminiz başarıyla kaydedildi.',
            3000
          );
          break;
        default:
          window.showNotification(
            'info',
            'İşlem Tamamlandı',
            'İşlem başarıyla gerçekleştirildi.',
            3000
          );
      }
    }
  };

  const handleFeedback = () => {
    setShowFeedbackModal(true);
  };

  return (
    <div className="gov-ai-panel">
      <div className="gov-ai-header">
        <Brain size={24} />
        <h5 className="gov-ai-title">AI Analiz Paneli</h5>
      </div>

      {/* Güven Seviyesi */}
      <Card className="mb-4">
        <Card.Header className={`bg-${getConfidenceColor(confidenceData.level)} text-white`}>
          <h6 className="mb-0">
            <Shield size={16} style={{ marginRight: '5px' }} />
            Güven Seviyesi: {getConfidenceText(confidenceData.level)}
          </h6>
        </Card.Header>
        <Card.Body>
          <div className="gov-confidence-bar">
            <div 
              className="gov-confidence-fill"
              style={{ width: `${confidenceData.confidence}%` }}
            />
          </div>
          <div className="text-center mt-2">
            <small>{confidenceData.confidence}% Güven</small>
          </div>
          
          <div className="confidence-factors">
            <h6 className="text-muted mb-2">Güven Faktörleri:</h6>
            <ul className="list-unstyled">
              {confidenceData.factors.map((factor, index) => (
                <li key={index} className="mb-1">
                  <CheckCircle size={14} className="text-success me-2" />
                  <small>{factor}</small>
                </li>
              ))}
            </ul>
          </div>
        </Card.Body>
      </Card>

      {/* AI Özet */}
      {aiSummary && (
        <Card className="mb-4">
          <Card.Header className="bg-primary text-white">
            <h6 className="mb-0">
              <Brain size={16} style={{ marginRight: '5px' }} />
              AI Hasta Özeti
            </h6>
          </Card.Header>
          <Card.Body>
            <div className="ai-summary-content">
              <div className="mb-3">
                <strong>Risk Seviyesi:</strong>
                <Badge bg={aiSummary.riskLevel === 'Yüksek' ? 'danger' : 
                          aiSummary.riskLevel === 'Orta' ? 'warning' : 'success'} 
                       className="ms-2">
                  {aiSummary.riskLevel}
                </Badge>
              </div>
              
              <div className="mb-3">
                <strong>Ana Problemler:</strong>
                <ul className="mb-0 mt-2">
                  {aiSummary.mainProblems.map((problem, index) => (
                    <li key={index}><small>{problem}</small></li>
                  ))}
                </ul>
              </div>
              
              <div>
                <strong>Öneriler:</strong>
                <p className="mb-0 mt-2"><small>{aiSummary.recommendations}</small></p>
              </div>
            </div>
          </Card.Body>
        </Card>
      )}

      {/* İlaç Etkileşim Analizi */}
      {drugInteractions.length > 0 && (
        <Card className="mb-4">
          <Card.Header className="bg-warning text-dark">
            <h6 className="mb-0">
              <AlertTriangle size={16} style={{ marginRight: '5px' }} />
              İlaç Etkileşim Analizi
            </h6>
          </Card.Header>
          <Card.Body>
            {drugInteractions.map((interaction, index) => (
              <Alert key={index} variant="warning" className="mb-2">
                <small>{interaction}</small>
              </Alert>
            ))}
          </Card.Body>
        </Card>
      )}

      {/* Hasta İstatistikleri */}
      <Card className="mb-4">
        <Card.Header className="bg-info text-white">
          <h6 className="mb-0">
            <TrendingUp size={16} style={{ marginRight: '5px' }} />
            Hasta İstatistikleri
          </h6>
        </Card.Header>
        <Card.Body>
          <div className="row text-center">
            <div className="col-6 mb-2">
              <div className="stat-item">
                <h6 className="text-primary mb-1">{patient.medications.length}</h6>
                <small className="text-muted">Aktif İlaç</small>
              </div>
            </div>
            <div className="col-6 mb-2">
              <div className="stat-item">
                <h6 className="text-secondary mb-1">{patient.chronicDiseases.length}</h6>
                <small className="text-muted">Kronik Hastalık</small>
              </div>
            </div>
            <div className="col-6 mb-2">
              <div className="stat-item">
                <h6 className="text-danger mb-1">{patient.allergies.length}</h6>
                <small className="text-muted">Alerji</small>
              </div>
            </div>
            <div className="col-6 mb-2">
              <div className="stat-item">
                <h6 className="text-warning mb-1">{patient.surgeries.length}</h6>
                <small className="text-muted">Operasyon</small>
              </div>
            </div>
          </div>
        </Card.Body>
      </Card>

      {/* Onay Butonları */}
      <Card className="mb-4">
        <Card.Header className="bg-success text-white">
          <h6 className="mb-0">
            <CheckCircle size={16} style={{ marginRight: '5px' }} />
            Doktor Onayı
          </h6>
        </Card.Header>
        <Card.Body>
          <div className="d-grid gap-2">
            <button 
              className="gov-btn gov-btn-success"
              onClick={() => handleApproval('approve')}
            >
              <ThumbsUp size={16} />
              Onayla
            </button>
            <button 
              className="gov-btn gov-btn-warning"
              onClick={() => handleApproval('modify')}
            >
              <Edit size={16} />
              Düzenle
            </button>
            <button 
              className="gov-btn gov-btn-danger"
              onClick={() => handleApproval('reject')}
            >
              <XCircle size={16} />
              Reddet
            </button>
            <Button 
              variant="outline-secondary" 
              size="sm"
              onClick={handleFeedback}
            >
              <FileText size={16} style={{ marginRight: '5px' }} />
              Geri Bildirim
            </Button>
          </div>
        </Card.Body>
      </Card>

      {/* AI Önerileri */}
      <Card className="mb-4">
        <Card.Header className="bg-primary text-white">
          <h6 className="mb-0">
            <Activity size={16} style={{ marginRight: '5px' }} />
            AI Önerileri
          </h6>
        </Card.Header>
        <Card.Body>
          <div className="ai-recommendations">
            <div className="mb-2">
              <Badge bg="success" className="me-2">✓</Badge>
              <small>Düzenli ilaç takibi yapılmalı</small>
            </div>
            <div className="mb-2">
              <Badge bg="warning" className="me-2">⚠</Badge>
              <small>Laboratuvar değerleri yakından izlenmeli</small>
            </div>
            <div className="mb-2">
              <Badge bg="info" className="me-2">ℹ</Badge>
              <small>Hasta eğitimi verilmeli</small>
            </div>
            <div className="mb-2">
              <Badge bg="primary" className="me-2">📋</Badge>
              <small>Randevu takvimi güncellenmeli</small>
            </div>
          </div>
        </Card.Body>
      </Card>

      {/* Geri Bildirim Modal */}
      <Modal show={showFeedbackModal} onHide={() => setShowFeedbackModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>AI Analiz Geri Bildirimi</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Geri Bildiriminiz</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                placeholder="AI analizinin doğruluğu hakkında görüşlerinizi paylaşın..."
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowFeedbackModal(false)}>
            İptal
          </Button>
          <Button variant="primary" onClick={() => {
            handleApproval('feedback');
            setShowFeedbackModal(false);
          }}>
            Gönder
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default AdvancedAIPanel;
