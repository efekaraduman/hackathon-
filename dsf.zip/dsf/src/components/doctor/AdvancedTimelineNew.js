import React, { useState } from 'react';
import { Row, Col, Button, Modal, Alert } from 'react-bootstrap';
import { 
  Calendar, 
  Pill, 
  AlertTriangle, 
  Activity, 
  MapPin, 
  TrendingUp,
  TrendingDown,
  Minus,
  Eye,
  FileText,
  Heart,
  Stethoscope,
  TestTube,
  User,
  Clock
} from 'lucide-react';

const AdvancedTimeline = ({ patient }) => {
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [showEventModal, setShowEventModal] = useState(false);
  const [filterType, setFilterType] = useState('all');

  if (!patient) return null;

  // Genişletilmiş timeline verileri
  const allEvents = [
    // İlaçlar
    {
      id: 1,
      type: 'medication',
      date: '01 Haz 2023',
      title: 'Amlodipin 5mg',
      description: '1x1 - Dr. Zeynep Ak',
      location: 'Kardiyoloji Kliniği, İstanbul',
      icon: Pill,
      category: 'medication',
      priority: 'medium',
      tags: ['ilaç', 'reçete', 'hipertansiyon'],
      details: {
        activeSubstance: 'Amlodipin Besilat',
        dosage: '1x1',
        prescribingDoctor: 'Dr. Zeynep Ak',
        hospital: 'Kardiyoloji Kliniği',
        city: 'İstanbul',
        notes: 'Hipertansiyon tedavisi için reçete edildi'
      }
    },
    {
      id: 2,
      type: 'medication',
      date: '15 Ağu 2023',
      title: 'Sumatriptan 50mg',
      description: 'Gerektiğinde - Dr. Can Yılmaz',
      location: 'Nöroloji Kliniği, Ankara',
      icon: Pill,
      category: 'medication',
      priority: 'medium',
      tags: ['ilaç', 'reçete', 'migren'],
      details: {
        activeSubstance: 'Sumatriptan',
        dosage: 'Gerektiğinde',
        prescribingDoctor: 'Dr. Can Yılmaz',
        hospital: 'Nöroloji Kliniği',
        city: 'Ankara',
        notes: 'Migren atakları için acil kullanım'
      }
    },
    {
      id: 3,
      type: 'medication',
      date: '10 Eyl 2023',
      title: 'Metformin 850mg',
      description: '2x1 - Dr. Ayşe Demir',
      location: 'Endokrinoloji Kliniği, İzmir',
      icon: Pill,
      category: 'medication',
      priority: 'high',
      tags: ['ilaç', 'reçete', 'diyabet'],
      details: {
        activeSubstance: 'Metformin HCl',
        dosage: '2x1',
        prescribingDoctor: 'Dr. Ayşe Demir',
        hospital: 'Endokrinoloji Kliniği',
        city: 'İzmir',
        notes: 'Tip 2 diyabet tedavisi'
      }
    },
    {
      id: 4,
      type: 'medication',
      date: '05 Eki 2023',
      title: 'Atorvastatin 20mg',
      description: '1x1 - Dr. Mehmet Kaya',
      location: 'Kardiyoloji Kliniği, Bursa',
      icon: Pill,
      category: 'medication',
      priority: 'medium',
      tags: ['ilaç', 'reçete', 'kolesterol'],
      details: {
        activeSubstance: 'Atorvastatin Kalsiyum',
        dosage: '1x1',
        prescribingDoctor: 'Dr. Mehmet Kaya',
        hospital: 'Kardiyoloji Kliniği',
        city: 'Bursa',
        notes: 'Kolesterol düşürücü tedavi'
      }
    },

    // Randevular
    {
      id: 5,
      type: 'appointment',
      date: '20 Ara 2023',
      title: 'Kardiyoloji - Dr. Zeynep Ak',
      description: 'Hipertansiyon takibi',
      location: 'Kardiyoloji Kliniği, İstanbul',
      icon: Calendar,
      category: 'appointment',
      priority: 'high',
      tags: ['randevu', 'kardiyoloji', 'takip'],
      details: {
        doctor: 'Dr. Zeynep Ak',
        department: 'Kardiyoloji',
        purpose: 'Hipertansiyon takibi',
        hospital: 'Kardiyoloji Kliniği',
        city: 'İstanbul',
        notes: 'Kan basıncı kontrolü ve ilaç dozajı değerlendirmesi'
      }
    },
    {
      id: 6,
      type: 'appointment',
      date: '15 Kas 2023',
      title: 'Endokrinoloji - Dr. Ayşe Demir',
      description: 'Diyabet takibi',
      location: 'Endokrinoloji Kliniği, İzmir',
      icon: Calendar,
      category: 'appointment',
      priority: 'high',
      tags: ['randevu', 'endokrinoloji', 'diyabet'],
      details: {
        doctor: 'Dr. Ayşe Demir',
        department: 'Endokrinoloji',
        purpose: 'Diyabet takibi',
        hospital: 'Endokrinoloji Kliniği',
        city: 'İzmir',
        notes: 'HbA1c kontrolü ve ilaç dozajı ayarlaması'
      }
    },

    // Lab Sonuçları
    {
      id: 7,
      type: 'lab',
      date: '20 Kas 2023',
      title: 'Kan Basıncı - Yüksek',
      description: 'Değer: 140/90 mmHg (Normal: <120/80)',
      location: 'Laboratuvar, İstanbul',
      icon: TestTube,
      category: 'lab',
      priority: 'high',
      tags: ['lab', 'kan basıncı', 'yüksek'],
      details: {
        testName: 'Kan Basıncı',
        value: '140/90 mmHg',
        normalRange: '<120/80',
        status: 'Yüksek',
        lab: 'Laboratuvar',
        city: 'İstanbul',
        notes: 'Hipertansiyon tanısı için takip gerekli'
      }
    },
    {
      id: 8,
      type: 'lab',
      date: '18 Kas 2023',
      title: 'HbA1c - Kontrol Altında',
      description: 'Değer: 6.2% (Hedef: <7%)',
      location: 'Laboratuvar, İzmir',
      icon: TestTube,
      category: 'lab',
      priority: 'medium',
      tags: ['lab', 'hbA1c', 'diyabet'],
      details: {
        testName: 'HbA1c',
        value: '6.2%',
        normalRange: '<7%',
        status: 'Kontrol Altında',
        lab: 'Laboratuvar',
        city: 'İzmir',
        notes: 'Diyabet kontrolü iyi durumda'
      }
    },
    {
      id: 9,
      type: 'lab',
      date: '16 Kas 2023',
      title: 'Kolesterol - Yüksek',
      description: 'Total: 240 mg/dL (Normal: <200)',
      location: 'Laboratuvar, Bursa',
      icon: TestTube,
      category: 'lab',
      priority: 'high',
      tags: ['lab', 'kolesterol', 'yüksek'],
      details: {
        testName: 'Total Kolesterol',
        value: '240 mg/dL',
        normalRange: '<200 mg/dL',
        status: 'Yüksek',
        lab: 'Laboratuvar',
        city: 'Bursa',
        notes: 'Statin tedavisi başlandı'
      }
    },

    // Operasyonlar
    {
      id: 10,
      type: 'surgery',
      date: '10 Mar 2023',
      title: 'Katarakt Ameliyatı',
      description: 'Sol göz katarakt cerrahisi',
      location: 'Göz Hastalıkları Kliniği, İstanbul',
      icon: Stethoscope,
      category: 'surgery',
      priority: 'high',
      tags: ['operasyon', 'katarakt', 'göz'],
      details: {
        procedure: 'Katarakt Ameliyatı',
        location: 'Sol göz',
        surgeon: 'Dr. Ali Veli',
        hospital: 'Göz Hastalıkları Kliniği',
        city: 'İstanbul',
        notes: 'Başarılı operasyon, iyileşme süreci normal'
      }
    }
  ];

  // Filtreleme
  const filteredEvents = filterType === 'all' 
    ? allEvents 
    : allEvents.filter(event => event.category === filterType);

  // İstatistikler
  const stats = {
    total: allEvents.length,
    medication: allEvents.filter(e => e.category === 'medication').length,
    appointment: allEvents.filter(e => e.category === 'appointment').length,
    surgery: allEvents.filter(e => e.category === 'surgery').length,
    lab: allEvents.filter(e => e.category === 'lab').length
  };

  const handleEventClick = (event) => {
    setSelectedEvent(event);
    setShowEventModal(true);
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'minimal-badge-danger';
      case 'medium': return 'minimal-badge-warning';
      case 'low': return 'minimal-badge-success';
      default: return 'minimal-badge-gray';
    }
  };

  const getPriorityText = (priority) => {
    switch (priority) {
      case 'high': return 'Yüksek Öncelik';
      case 'medium': return 'Orta Öncelik';
      case 'low': return 'Düşük Öncelik';
      default: return 'Bilinmiyor';
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'medication': return Pill;
      case 'appointment': return Calendar;
      case 'surgery': return Stethoscope;
      case 'lab': return TestTube;
      default: return Activity;
    }
  };

  const getCategoryColor = (category) => {
    switch (category) {
      case 'medication': return 'var(--primary-light)';
      case 'appointment': return 'var(--success)';
      case 'surgery': return 'var(--warning)';
      case 'lab': return 'var(--info)';
      default: return 'var(--gray-400)';
    }
  };

  return (
    <>
      <div className="minimal-card">
        <div className="minimal-card-header">
          <div className="d-flex justify-content-between align-items-center">
            <h5 className="minimal-card-title">
              <Activity size={20} />
              Gelişmiş Timeline
            </h5>
            <div className="d-flex gap-2">
              <button
                className={`minimal-btn minimal-btn-sm ${filterType === 'all' ? 'minimal-btn-primary' : 'minimal-btn-secondary'}`}
                onClick={() => setFilterType('all')}
              >
                Tümü ({stats.total})
              </button>
              <button
                className={`minimal-btn minimal-btn-sm ${filterType === 'medication' ? 'minimal-btn-primary' : 'minimal-btn-secondary'}`}
                onClick={() => setFilterType('medication')}
              >
                İlaç ({stats.medication})
              </button>
              <button
                className={`minimal-btn minimal-btn-sm ${filterType === 'appointment' ? 'minimal-btn-primary' : 'minimal-btn-secondary'}`}
                onClick={() => setFilterType('appointment')}
              >
                Randevu ({stats.appointment})
              </button>
              <button
                className={`minimal-btn minimal-btn-sm ${filterType === 'surgery' ? 'minimal-btn-primary' : 'minimal-btn-secondary'}`}
                onClick={() => setFilterType('surgery')}
              >
                Operasyon ({stats.surgery})
              </button>
              <button
                className={`minimal-btn minimal-btn-sm ${filterType === 'lab' ? 'minimal-btn-primary' : 'minimal-btn-secondary'}`}
                onClick={() => setFilterType('lab')}
              >
                Lab ({stats.lab})
              </button>
            </div>
          </div>
        </div>
        
        <div className="minimal-card-body">
          <div className="minimal-timeline">
            {filteredEvents.map((event, index) => {
              const IconComponent = event.icon;
              const CategoryIcon = getCategoryIcon(event.category);
              
              return (
                <div key={event.id} className="minimal-timeline-item">
                  <div className="minimal-timeline-marker">
                    <div 
                      className="minimal-timeline-icon"
                      style={{ backgroundColor: getCategoryColor(event.category) }}
                    >
                      <IconComponent size={16} />
                    </div>
                    {index < filteredEvents.length - 1 && (
                      <div className="minimal-timeline-line"></div>
                    )}
                  </div>
                  
                  <div className="minimal-timeline-content">
                    <div className="minimal-timeline-header">
                      <div className="minimal-timeline-date">
                        <Clock size={14} className="me-1" />
                        {event.date}
                      </div>
                      <span className={`minimal-badge ${getPriorityColor(event.priority)}`}>
                        {getPriorityText(event.priority)}
                      </span>
                    </div>
                    
                    <div className="minimal-timeline-title">
                      <CategoryIcon size={16} className="me-2" />
                      {event.title}
                    </div>
                    
                    <div className="minimal-timeline-description">
                      {event.description}
                    </div>
                    
                    <div className="minimal-timeline-location">
                      <MapPin size={14} className="me-1" />
                      {event.location}
                    </div>
                    
                    <div className="minimal-timeline-tags">
                      {event.tags.map((tag, tagIndex) => (
                        <span key={tagIndex} className="minimal-badge minimal-badge-gray">
                          {tag}
                        </span>
                      ))}
                    </div>
                    
                    <button
                      className="minimal-btn minimal-btn-sm minimal-btn-secondary mt-2"
                      onClick={() => handleEventClick(event)}
                    >
                      <Eye size={14} />
                      Detayları Görüntüle
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Event Detail Modal */}
      <Modal show={showEventModal} onHide={() => setShowEventModal(false)} size="lg">
        <Modal.Header closeButton className="minimal-card-header">
          <Modal.Title className="minimal-card-title">
            <Activity size={20} />
            Olay Detayları
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className="minimal-card-body">
          {selectedEvent && (
            <div>
              <Row className="mb-3">
                <Col md={6}>
                  <strong>Tarih:</strong> {selectedEvent.date}
                </Col>
                <Col md={6}>
                  <strong>Öncelik:</strong>
                  <span className={`minimal-badge ${getPriorityColor(selectedEvent.priority)} ms-2`}>
                    {getPriorityText(selectedEvent.priority)}
                  </span>
                </Col>
              </Row>
              <Row className="mb-3">
                <Col md={6}>
                  <strong>Başlık:</strong> {selectedEvent.title}
                </Col>
                <Col md={6}>
                  <strong>Açıklama:</strong> {selectedEvent.description}
                </Col>
              </Row>
              <Row className="mb-3">
                <Col md={6}>
                  <strong>Konum:</strong> {selectedEvent.location}
                </Col>
                <Col md={6}>
                  <strong>Kategori:</strong> {selectedEvent.category}
                </Col>
              </Row>
              <Row className="mb-3">
                <Col>
                  <strong>Etiketler:</strong>
                  <div className="mt-2">
                    {selectedEvent.tags.map((tag, index) => (
                      <span key={index} className="minimal-badge minimal-badge-gray me-1">
                        {tag}
                      </span>
                    ))}
                  </div>
                </Col>
              </Row>
              <Row>
                <Col>
                  <strong>Detaylar:</strong>
                  <div className="mt-2">
                    {Object.entries(selectedEvent.details).map(([key, value]) => (
                      <div key={key} className="mb-1">
                        <strong>{key}:</strong> {value}
                      </div>
                    ))}
                  </div>
                </Col>
              </Row>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer className="minimal-card-header">
          <button 
            className="minimal-btn minimal-btn-secondary"
            onClick={() => setShowEventModal(false)}
          >
            Kapat
          </button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default AdvancedTimeline;
