import React, { useState } from 'react';
import { Button, Modal, Form, Row, Col, Alert } from 'react-bootstrap';
import { 
  Eye, 
  Edit, 
  Check, 
  X, 
  AlertTriangle, 
  MapPin,
  Calendar,
  User,
  Pill,
  Activity,
  Shield
} from 'lucide-react';

const ReconciledMedicationList = ({ patient, onMedicationUpdate }) => {
  const [showSourceModal, setShowSourceModal] = useState(false);
  const [selectedMedication, setSelectedMedication] = useState(null);
  const [editingMedication, setEditingMedication] = useState(null);
  const [editForm, setEditForm] = useState({});

  if (!patient) return null;

  // Genişletilmiş ilaç verileri
  const enhancedMedications = [
    {
      id: 1,
      name: 'Amlodipin 5mg',
      activeSubstance: 'Amlodipin Besilat',
      dosage: '1x1',
      status: 'active',
      source: 'Dr. Zeynep Ak - Kardiyoloji',
      city: 'İstanbul',
      doctor: 'Dr. Zeynep Ak',
      date: '01 Haz 2023',
      notes: 'Hipertansiyon tedavisi için reçete edildi',
      interactions: ['Düşük risk - Diğer antihipertansiflerle uyumlu']
    },
    {
      id: 2,
      name: 'Sumatriptan 50mg',
      activeSubstance: 'Sumatriptan',
      dosage: 'Gerektiğinde',
      status: 'active',
      source: 'Dr. Can Yılmaz - Nöroloji',
      city: 'Ankara',
      doctor: 'Dr. Can Yılmaz',
      date: '15 Ağu 2023',
      notes: 'Migren atakları için acil kullanım',
      interactions: ['Düşük risk - İzole kullanım']
    },
    {
      id: 3,
      name: 'Metformin 850mg',
      activeSubstance: 'Metformin HCl',
      dosage: '2x1',
      status: 'active',
      source: 'Dr. Ayşe Demir - Endokrinoloji',
      city: 'İzmir',
      doctor: 'Dr. Ayşe Demir',
      date: '10 Eyl 2023',
      notes: 'Tip 2 diyabet tedavisi',
      interactions: ['Yüksek risk - Böbrek fonksiyonları takip edilmeli']
    },
    {
      id: 4,
      name: 'Atorvastatin 20mg',
      activeSubstance: 'Atorvastatin Kalsiyum',
      dosage: '1x1',
      status: 'active',
      source: 'Dr. Mehmet Kaya - Kardiyoloji',
      city: 'Bursa',
      doctor: 'Dr. Mehmet Kaya',
      date: '05 Eki 2023',
      notes: 'Kolesterol düşürücü tedavi',
      interactions: ['Orta risk - Karaciğer enzimleri kontrol edilmeli']
    },
    {
      id: 5,
      name: 'Omeprazol 20mg',
      activeSubstance: 'Omeprazol',
      dosage: '1x1',
      status: 'discontinued',
      source: 'Dr. Fatma Öz - Gastroenteroloji',
      city: 'Antalya',
      doctor: 'Dr. Fatma Öz',
      date: '20 Kas 2023',
      notes: 'Gastrit tedavisi - 3 ay sonra kesildi',
      interactions: ['Düşük risk - Diğer ilaçlarla etkileşim minimal']
    }
  ];

  const handleShowSource = (medication) => {
    setSelectedMedication(medication);
    setShowSourceModal(true);
  };

  const handleEdit = (medication) => {
    setEditingMedication(medication);
    setEditForm({
      dosage: medication.dosage,
      notes: medication.notes || '',
      status: medication.status || 'active'
    });
  };

  const handleSaveEdit = () => {
    if (editingMedication && onMedicationUpdate) {
      onMedicationUpdate(editingMedication.id, editForm);
    }
    setEditingMedication(null);
    setEditForm({});
  };

  const handleCancelEdit = () => {
    setEditingMedication(null);
    setEditForm({});
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'minimal-badge-success';
      case 'discontinued': return 'minimal-badge-gray';
      case 'modified': return 'minimal-badge-warning';
      default: return 'minimal-badge-primary';
    }
  };

  const getInteractionLevel = (medication) => {
    const highRiskSubstances = ['metformin', 'insulin', 'warfarin', 'digoxin'];
    const substance = medication.activeSubstance.toLowerCase();
    
    if (highRiskSubstances.some(risk => substance.includes(risk))) {
      return { level: 'high', color: 'minimal-badge-danger', text: 'Yüksek Risk' };
    } else if (medication.dosage.includes('2x') || medication.dosage.includes('3x')) {
      return { level: 'medium', color: 'minimal-badge-warning', text: 'Orta Risk' };
    } else {
      return { level: 'low', color: 'minimal-badge-success', text: 'Düşük Risk' };
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'active': return 'Aktif';
      case 'discontinued': return 'Kesildi';
      case 'modified': return 'Değiştirildi';
      default: return 'Bilinmiyor';
    }
  };

  // İstatistikler
  const stats = {
    total: enhancedMedications.length,
    highRisk: enhancedMedications.filter(med => getInteractionLevel(med).level === 'high').length,
    differentCities: [...new Set(enhancedMedications.map(med => med.city))].length,
    differentDoctors: [...new Set(enhancedMedications.map(med => med.doctor))].length
  };

  return (
    <>
      <div className="minimal-card">
        <div className="minimal-card-header">
          <div className="d-flex justify-content-between align-items-center">
            <h5 className="minimal-card-title">
              <Pill size={20} />
              Reconciled Medication List ({enhancedMedications.length})
            </h5>
            <button className="minimal-btn minimal-btn-sm minimal-btn-secondary">
              <Edit size={16} />
              Düzenle
            </button>
          </div>
        </div>
        
        <div className="minimal-card-body">
          {/* İstatistikler */}
          <div className="minimal-stats mb-4">
            <div className="minimal-stat">
              <div className="minimal-stat-value">{stats.total}</div>
              <div className="minimal-stat-label">Toplam İlaç</div>
            </div>
            <div className="minimal-stat">
              <div className="minimal-stat-value">{stats.highRisk}</div>
              <div className="minimal-stat-label">Yüksek Risk</div>
            </div>
            <div className="minimal-stat">
              <div className="minimal-stat-value">{stats.differentCities}</div>
              <div className="minimal-stat-label">Farklı Şehir</div>
            </div>
            <div className="minimal-stat">
              <div className="minimal-stat-value">{stats.differentDoctors}</div>
              <div className="minimal-stat-label">Farklı Doktor</div>
            </div>
          </div>

          {/* İlaç Tablosu */}
          <div className="table-responsive">
            <table className="minimal-table">
              <thead>
                <tr>
                  <th>İlaç Adı</th>
                  <th>Etken Madde</th>
                  <th>Dozaj</th>
                  <th>Durum</th>
                  <th>Etkileşim</th>
                  <th>Kaynak</th>
                  <th>İşlemler</th>
                </tr>
              </thead>
              <tbody>
                {enhancedMedications.map(medication => {
                  const interaction = getInteractionLevel(medication);
                  const isEditing = editingMedication?.id === medication.id;

                  return (
                    <tr key={medication.id}>
                      <td>
                        <div className="d-flex align-items-center">
                          <Pill size={16} className="me-2" style={{ color: 'var(--primary-light)' }} />
                          <strong>{medication.name}</strong>
                        </div>
                      </td>
                      <td>{medication.activeSubstance}</td>
                      <td>
                        {isEditing ? (
                          <input
                            type="text"
                            className="minimal-input"
                            value={editForm.dosage}
                            onChange={(e) => setEditForm({...editForm, dosage: e.target.value})}
                            style={{ width: '100px' }}
                          />
                        ) : (
                          medication.dosage
                        )}
                      </td>
                      <td>
                        <span className={`minimal-badge ${getStatusColor(medication.status)}`}>
                          {getStatusText(medication.status)}
                        </span>
                      </td>
                      <td>
                        <span className={`minimal-badge ${interaction.color}`}>
                          {interaction.text}
                        </span>
                      </td>
                      <td>
                        <div className="d-flex align-items-center">
                          <MapPin size={14} className="me-1" />
                          <small>{medication.city}</small>
                        </div>
                        <div className="d-flex align-items-center">
                          <User size={14} className="me-1" />
                          <small>{medication.doctor}</small>
                        </div>
                      </td>
                      <td>
                        <div className="d-flex gap-1">
                          <button
                            className="minimal-btn minimal-btn-sm minimal-btn-secondary"
                            onClick={() => handleShowSource(medication)}
                            title="Kaynak Görüntüle"
                          >
                            <Eye size={14} />
                          </button>
                          {isEditing ? (
                            <>
                              <button
                                className="minimal-btn minimal-btn-sm minimal-btn-success"
                                onClick={handleSaveEdit}
                                title="Kaydet"
                              >
                                <Check size={14} />
                              </button>
                              <button
                                className="minimal-btn minimal-btn-sm minimal-btn-danger"
                                onClick={handleCancelEdit}
                                title="İptal"
                              >
                                <X size={14} />
                              </button>
                            </>
                          ) : (
                            <button
                              className="minimal-btn minimal-btn-sm minimal-btn-warning"
                              onClick={() => handleEdit(medication)}
                              title="Düzenle"
                            >
                              <Edit size={14} />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Uyarılar */}
          {stats.highRisk > 0 && (
            <Alert variant="warning" className="minimal-alert minimal-alert-warning mt-3">
              <AlertTriangle size={20} className="me-2" />
              <strong>Dikkat!</strong> {stats.highRisk} ilaç yüksek risk kategorisinde. 
              Düzenli takip ve doktor kontrolü önerilir.
            </Alert>
          )}
        </div>
      </div>

      {/* Kaynak Modal */}
      <Modal show={showSourceModal} onHide={() => setShowSourceModal(false)} size="lg">
        <Modal.Header closeButton className="minimal-card-header">
          <Modal.Title className="minimal-card-title">
            <Shield size={20} />
            İlaç Kaynak Bilgileri
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className="minimal-card-body">
          {selectedMedication && (
            <div>
              <Row className="mb-3">
                <Col md={6}>
                  <strong>İlaç Adı:</strong> {selectedMedication.name}
                </Col>
                <Col md={6}>
                  <strong>Etken Madde:</strong> {selectedMedication.activeSubstance}
                </Col>
              </Row>
              <Row className="mb-3">
                <Col md={6}>
                  <strong>Dozaj:</strong> {selectedMedication.dosage}
                </Col>
                <Col md={6}>
                  <strong>Durum:</strong> 
                  <span className={`minimal-badge ${getStatusColor(selectedMedication.status)} ms-2`}>
                    {getStatusText(selectedMedication.status)}
                  </span>
                </Col>
              </Row>
              <Row className="mb-3">
                <Col md={6}>
                  <strong>Doktor:</strong> {selectedMedication.doctor}
                </Col>
                <Col md={6}>
                  <strong>Şehir:</strong> {selectedMedication.city}
                </Col>
              </Row>
              <Row className="mb-3">
                <Col md={6}>
                  <strong>Tarih:</strong> {selectedMedication.date}
                </Col>
                <Col md={6}>
                  <strong>Etkileşim:</strong>
                  <span className={`minimal-badge ${getInteractionLevel(selectedMedication).color} ms-2`}>
                    {getInteractionLevel(selectedMedication).text}
                  </span>
                </Col>
              </Row>
              <Row>
                <Col>
                  <strong>Notlar:</strong>
                  <p className="mt-2">{selectedMedication.notes}</p>
                </Col>
              </Row>
              <Row>
                <Col>
                  <strong>Etkileşim Detayları:</strong>
                  <ul className="mt-2">
                    {selectedMedication.interactions.map((interaction, index) => (
                      <li key={index}>{interaction}</li>
                    ))}
                  </ul>
                </Col>
              </Row>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer className="minimal-card-header">
          <button 
            className="minimal-btn minimal-btn-secondary"
            onClick={() => setShowSourceModal(false)}
          >
            Kapat
          </button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default ReconciledMedicationList;
