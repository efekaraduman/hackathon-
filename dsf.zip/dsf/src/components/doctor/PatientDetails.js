import React from 'react';
import { Card, Row, Col, Badge, Alert } from 'react-bootstrap';
import { 
  User, 
  Pill, 
  AlertTriangle, 
  Calendar, 
  Activity,
  MapPin,
  Phone,
  FileText
} from 'lucide-react';
import Timeline from './Timeline';
import MedicationChart from './MedicationChart';

const PatientDetails = ({ patient, drugInteractions }) => {
  if (!patient) {
    return (
      <div className="main-content">
        <div className="text-center text-muted py-5">
          <User size={64} className="mb-3" />
          <h4>Hasta Seçiniz</h4>
          <p>Detayları görüntülemek için sol panelden bir hasta seçin</p>
        </div>
      </div>
    );
  }

  // Güvenli erişim için default değerler
  const medications = patient.medications || [];
  const allergies = patient.allergies || [];
  const chronicDiseases = patient.chronicDiseases || [];
  const interactions = drugInteractions || [];

  return (
    <div className="main-content">
      {/* Hasta Bilgileri */}
      <Card className="mb-4">
        <Card.Header className="bg-primary text-white">
          <h5 className="mb-0">
            <User size={20} style={{ marginRight: '8px' }} />
            Hasta Bilgileri
          </h5>
        </Card.Header>
        <Card.Body>
          <Row>
            <Col md={6}>
              <h4>{patient.name} {patient.surname}</h4>
              <p><strong>Yaş:</strong> {patient.age} • <strong>Cinsiyet:</strong> {patient.gender}</p>
              <p><strong>TC No:</strong> {patient.tcNo}</p>
            </Col>
            <Col md={6}>
              <p><Phone size={16} style={{ marginRight: '5px' }} /> {patient.phone}</p>
              <p><MapPin size={16} style={{ marginRight: '5px' }} /> {patient.address}</p>
            </Col>
          </Row>
          
          <div className="mt-3">
            <h6>Kronik Hastalıklar:</h6>
            <div>
              {patient.chronicDiseases.map(disease => (
                <Badge key={disease} bg="info" className="me-2 mb-1">
                  {disease}
                </Badge>
              ))}
            </div>
          </div>
        </Card.Body>
      </Card>

      {/* İlaç Etkileşim Uyarıları */}
      {interactions.length > 0 && (
        <Alert variant="warning" className="mb-4">
          <AlertTriangle size={20} style={{ marginRight: '8px' }} />
          <strong>İlaç Etkileşim Uyarıları</strong>
          <ul className="mb-0 mt-2">
            {interactions.map((interaction, index) => (
              <li key={index}>{interaction}</li>
            ))}
          </ul>
        </Alert>
      )}

      <Row>
        {/* İlaçlar */}
        <Col md={6}>
          <Card className="mb-4">
            <Card.Header className="bg-success text-white">
              <h6 className="mb-0">
                <Pill size={16} style={{ marginRight: '5px' }} />
                Aktif İlaçlar ({medications.length})
              </h6>
            </Card.Header>
            <Card.Body>
              {medications.map(medication => (
                <div key={medication.id} className="medication-item">
                  <div className="d-flex justify-content-between align-items-start">
                    <div>
                      <h6 className="mb-1">{medication.name}</h6>
                      <p className="mb-1"><strong>Dozaj:</strong> {medication.dosage}</p>
                      <p className="mb-1"><strong>Etken Madde:</strong> {medication.activeSubstance}</p>
                      <p className="mb-1"><strong>Başlangıç:</strong> {new Date(medication.startDate).toLocaleDateString('tr-TR')}</p>
                    </div>
                    <Badge bg="secondary">{medication.city}</Badge>
                  </div>
                  <div className="mt-2">
                    <small className="text-muted">
                      <strong>Doktor:</strong> {medication.prescribingDoctor} • 
                      <strong> Hastane:</strong> {medication.hospital}
                    </small>
                  </div>
                </div>
              ))}
            </Card.Body>
          </Card>
        </Col>

        {/* Alerjiler */}
        <Col md={6}>
          <Card className="mb-4">
            <Card.Header className="bg-danger text-white">
              <h6 className="mb-0">
                <AlertTriangle size={16} style={{ marginRight: '5px' }} />
                Alerjiler ({allergies.length})
              </h6>
            </Card.Header>
            <Card.Body>
              {allergies.length === 0 ? (
                <p className="text-muted">Bilinen alerji yok</p>
              ) : (
                allergies.map(allergy => (
                  <div key={allergy} className="allergy-item">
                    <h6 className="mb-1 text-danger">{allergy}</h6>
                    <small className="text-muted">Alerji</small>
                  </div>
                ))
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* Laboratuvar Sonuçları */}
      <Card className="mb-4">
        <Card.Header className="bg-info text-white">
          <h6 className="mb-0">
            <FileText size={16} style={{ marginRight: '5px' }} />
            Son Laboratuvar Sonuçları
          </h6>
        </Card.Header>
        <Card.Body>
          <Row>
            {patient.labResults.map(result => (
              <Col md={6} key={result.id} className="mb-3">
                <div className="border rounded p-3">
                  <div className="d-flex justify-content-between align-items-center">
                    <h6 className="mb-1">{result.testName}</h6>
                    <Badge bg={result.status === 'Normal' ? 'success' : 'warning'}>
                      {result.status}
                    </Badge>
                  </div>
                  <p className="mb-1"><strong>Değer:</strong> {result.value} {result.unit}</p>
                  <p className="mb-0"><strong>Normal Aralık:</strong> {result.normalRange}</p>
                  <small className="text-muted">
                    {new Date(result.date).toLocaleDateString('tr-TR')}
                  </small>
                </div>
              </Col>
            ))}
          </Row>
        </Card.Body>
      </Card>

      {/* Grafik */}
      <MedicationChart patient={patient} />

      {/* Timeline */}
      <Timeline patient={patient} />
    </div>
  );
};

export default PatientDetails;
