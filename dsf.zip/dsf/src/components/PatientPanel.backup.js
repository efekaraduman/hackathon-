
import React, { useState, useEffect } from 'react';
import { Row, Col, Container, Card, Button, Alert, Modal, Form } from 'react-bootstrap';


import { User, Search, Calendar, Phone, MapPin, FileText, LogOut, Edit3, Save, X } from 'lucide-react';
import { generateAISummary, analyzeDrugInteractions, determineComplaintPriority, analyzeComplaint } from '../utils/aiAnalysis';

const PatientPanel = ({ patients, user, onLogout, setPatients }) => {
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [aiSummary, setAiSummary] = useState(null);
  const [drugInteractions, setDrugInteractions] = useState([]);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showComplaintModal, setShowComplaintModal] = useState(false);
  const [editForm, setEditForm] = useState({
    name: '',
    surname: '',
    age: '',
    gender: '',
    phone: '',
    address: '',
    tcNo: ''
  });
  const [complaintForm, setComplaintForm] = useState({
    title: '',
    description: '',
    symptoms: '',
    duration: '',
    previousTreatment: ''
  });
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [complaints, setComplaints] = useState([]);

  // Hasta girişi için kendi verilerini bul
  useEffect(() => {
    if (user && user.role === 'patient') {
      // Demo için ilk hastayı seç (gerçek uygulamada TC no ile eşleştirme yapılır)
      const patient = patients.find(p => p.name === user.name) || patients[0];
      setSelectedPatient(patient);
    }
  }, [user, patients]);

  useEffect(() => {
    if (selectedPatient) {
      const summary = generateAISummary(selectedPatient);
      setAiSummary(summary);

      const interactions = analyzeDrugInteractions(selectedPatient.medications);
      setDrugInteractions(interactions);
    }
  }, [selectedPatient]);

  const handleSearch = (e) => {
    e.preventDefault();
    const patient = patients.find(p => 
      p.tcNo === searchTerm || 
      p.phone === searchTerm ||
      (p.name + ' ' + p.surname).toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    if (patient) {
      setSelectedPatient(patient);
    } else {
      alert('Hasta bulunamadı. Lütfen TC numarası, telefon numarası veya ad-soyad ile arama yapın.');
    }
  };

  const handleEditClick = () => {
    if (selectedPatient) {
      setEditForm({
        name: selectedPatient.name,
        surname: selectedPatient.surname,
        age: selectedPatient.age,
        gender: selectedPatient.gender,
        phone: selectedPatient.phone,
        address: selectedPatient.address,
        tcNo: selectedPatient.tc || selectedPatient.tcNo
      });
      setShowEditModal(true);
    }
  };

  const handleEditChange = (field, value) => {
    setEditForm(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSaveEdit = () => {
    if (setPatients && selectedPatient) {
      setPatients(prevPatients => 
        prevPatients.map(patient => 
          patient.id === selectedPatient.id 
            ? { ...patient, ...editForm }
            : patient
        )
      );
      
      // Güncellenmiş hasta bilgilerini seç
      const updatedPatient = { ...selectedPatient, ...editForm };
      setSelectedPatient(updatedPatient);
      
      setShowEditModal(false);
      
      // Scroll sorununu çözmek için
      setTimeout(() => {
        // Body'nin scroll lock'unu kaldır
        document.body.style.overflow = '';
        document.body.style.paddingRight = '';
        
        // Sayfa scroll'unu etkinleştir
        document.documentElement.style.overflow = '';
        
        // Focus'u sayfaya geri ver
        window.focus();
        
        alert('Bilgileriniz başarıyla güncellendi!');
      }, 150);
    }
  };

  const handleCancelEdit = () => {
    setShowEditModal(false);
    setEditForm({
      name: '',
      surname: '',
      age: '',
      gender: '',
      phone: '',
      address: '',
      tcNo: ''
    });
    
    // Scroll sorununu çözmek için
    setTimeout(() => {
      // Body'nin scroll lock'unu kaldır
      document.body.style.overflow = '';
      document.body.style.paddingRight = '';
      
      // Sayfa scroll'unu etkinleştir
      document.documentElement.style.overflow = '';
      
      // Focus'u sayfaya geri ver
      window.focus();
    }, 150);
  };

  const handleComplaintClick = () => {
    setShowComplaintModal(true);
  };

  const handleComplaintChange = (field, value) => {
    const newForm = {
      ...complaintForm,
      [field]: value
    };
    setComplaintForm(newForm);
    
    // AI analizi yap (başlık ve açıklama dolu ise)
    if (newForm.title && newForm.description && selectedPatient) {
      const analysis = analyzeComplaint(newForm, selectedPatient);
      setAiAnalysis(analysis);
    }
  };

  const handleSaveComplaint = () => {
    if (complaintForm.title && complaintForm.description) {
      // AI ile öncelik belirle
      const analysis = analyzeComplaint(complaintForm, selectedPatient);
      
      const newComplaint = {
        id: Date.now().toString(),
        patientId: selectedPatient.id,
        patientName: selectedPatient.name + ' ' + selectedPatient.surname,
        title: complaintForm.title,
        description: complaintForm.description,
        urgency: analysis.priority, // AI tarafından belirlenen öncelik
        symptoms: complaintForm.symptoms,
        duration: complaintForm.duration,
        previousTreatment: complaintForm.previousTreatment,
        date: new Date().toISOString(),
        status: 'pending',
        doctorNotified: false,
        aiAnalysis: analysis // AI analiz sonuçları
      };

      setComplaints(prev => [newComplaint, ...prev]);
      
      // Form'u temizle
      setComplaintForm({
        title: '',
        description: '',
        symptoms: '',
        duration: '',
        previousTreatment: ''
      });
      
      setAiAnalysis(null);
      setShowComplaintModal(false);
      
      const urgencyText = {
        urgent: 'ACİL',
        high: 'YÜKSEK',
        normal: 'NORMAL',
        low: 'DÜŞÜK'
      };
      
      alert(`Şikayetiniz başarıyla gönderildi!\n\nAI Analizi:\nÖncelik: ${urgencyText[analysis.priority]}\n${analysis.urgencyLevel}\n\nDoktorunuza bildirildi.`);
    } else {
      alert('Lütfen başlık ve açıklama alanlarını doldurun.');
    }
  };

  const handleCancelComplaint = () => {
    setShowComplaintModal(false);
    setComplaintForm({
      title: '',
      description: '',
      symptoms: '',
      duration: '',
      previousTreatment: ''
    });
    setAiAnalysis(null);
  };

  if (user?.role === 'patient' && selectedPatient) {
    return (
      <Container fluid>
        {/* Üst Panel - Hasta Başlık ve Çıkış */}
        <Row className="mb-4">
          <Col>
            <div className="panel-header">
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <h2 className="panel-title">👤 Hasta Paneli</h2>
                  <p className="panel-subtitle">Hoş geldiniz, {user.name}</p>
                </div>
                <Button 
                  variant="danger" 
                  onClick={onLogout}
                  className="logout-btn d-flex align-items-center"
                  style={{ gap: '8px' }}
                >
                  <LogOut size={18} />
                  Çıkış Yap
                </Button>
              </div>
            </div>
          </Col>
        </Row>

        <Row>
          <Col lg={8} md={12}>
            <PatientDashboard 
              patient={selectedPatient} 
              onEditClick={handleEditClick}
              onComplaintClick={handleComplaintClick}
              complaints={complaints}
            />
          </Col>
          <Col lg={4} md={12}>
            <PatientAIPanel 
              patient={selectedPatient} 
              aiSummary={aiSummary}
              drugInteractions={drugInteractions}
            />
          </Col>
        </Row>

        {/* Düzenleme Modal */}
        <Modal 
          show={showEditModal} 
          onHide={handleCancelEdit} 
          size="lg"
          backdrop="static"
          keyboard={false}
        >
          <Modal.Header closeButton>
            <Modal.Title>
              <Edit3 size={20} style={{ marginRight: '8px' }} />
              Kişisel Bilgilerimi Düzenle
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form>
              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Ad *</Form.Label>
                    <Form.Control
                      type="text"
                      value={editForm.name}
                      onChange={(e) => handleEditChange('name', e.target.value)}
                      required
                    />
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Soyad *</Form.Label>
                    <Form.Control
                      type="text"
                      value={editForm.surname}
                      onChange={(e) => handleEditChange('surname', e.target.value)}
                      required
                    />
                  </Form.Group>
                </Col>
              </Row>
              
              <Row>
                <Col md={4}>
                  <Form.Group className="mb-3">
                    <Form.Label>Yaş *</Form.Label>
                    <Form.Control
                      type="number"
                      value={editForm.age}
                      onChange={(e) => handleEditChange('age', e.target.value)}
                      min="0"
                      max="120"
                      required
                    />
                  </Form.Group>
                </Col>
                <Col md={4}>
                  <Form.Group className="mb-3">
                    <Form.Label>Cinsiyet *</Form.Label>
                    <Form.Select
                      value={editForm.gender}
                      onChange={(e) => handleEditChange('gender', e.target.value)}
                      required
                    >
                      <option value="">Seçiniz</option>
                      <option value="Erkek">Erkek</option>
                      <option value="Kadın">Kadın</option>
                    </Form.Select>
                  </Form.Group>
                </Col>
                <Col md={4}>
                  <Form.Group className="mb-3">
                    <Form.Label>TC No *</Form.Label>
                    <Form.Control
                      type="text"
                      value={editForm.tcNo}
                      onChange={(e) => handleEditChange('tcNo', e.target.value)}
                      maxLength="11"
                      pattern="[0-9]{11}"
                      required
                    />
                  </Form.Group>
                </Col>
              </Row>

              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Telefon *</Form.Label>
                    <Form.Control
                      type="tel"
                      value={editForm.phone}
                      onChange={(e) => handleEditChange('phone', e.target.value)}
                      placeholder="0555 123 45 67"
                      required
                    />
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Adres *</Form.Label>
                    <Form.Control
                      type="text"
                      value={editForm.address}
                      onChange={(e) => handleEditChange('address', e.target.value)}
                      required
                    />
                  </Form.Group>
                </Col>
              </Row>
            </Form>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleCancelEdit}>
              <X size={16} style={{ marginRight: '5px' }} />
              İptal
            </Button>
            <Button variant="primary" onClick={handleSaveEdit}>
              <Save size={16} style={{ marginRight: '5px' }} />
              Kaydet
            </Button>
          </Modal.Footer>
        </Modal>

        {/* Şikayet Modal */}
        <Modal 
          show={showComplaintModal} 
          onHide={handleCancelComplaint} 
          size="lg"
          backdrop="static"
          keyboard={false}
        >
          <Modal.Header closeButton>
            <Modal.Title>
              📝 Şikayet Bildirimi
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form>
              <Form.Group className="mb-3">
                <Form.Label>Şikayet Başlığı *</Form.Label>
                <Form.Control
                  type="text"
                  value={complaintForm.title}
                  onChange={(e) => handleComplaintChange('title', e.target.value)}
                  placeholder="Örn: Baş ağrısı, mide bulantısı..."
                  required
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Şikayet Açıklaması *</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={4}
                  value={complaintForm.description}
                  onChange={(e) => handleComplaintChange('description', e.target.value)}
                  placeholder="Şikayetinizi detaylı olarak açıklayın..."
                  required
                />
              </Form.Group>

              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Semptomlar</Form.Label>
                    <Form.Control
                      as="textarea"
                      rows={2}
                      value={complaintForm.symptoms}
                      onChange={(e) => handleComplaintChange('symptoms', e.target.value)}
                      placeholder="Hangi semptomları yaşıyorsunuz?"
                    />
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Süre</Form.Label>
                    <Form.Control
                      type="text"
                      value={complaintForm.duration}
                      onChange={(e) => handleComplaintChange('duration', e.target.value)}
                      placeholder="Ne kadar süredir devam ediyor?"
                    />
                  </Form.Group>
                </Col>
              </Row>

              <Form.Group className="mb-3">
                <Form.Label>Önceki Tedavi</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={2}
                  value={complaintForm.previousTreatment}
                  onChange={(e) => handleComplaintChange('previousTreatment', e.target.value)}
                  placeholder="Daha önce bu konuda aldığınız tedavi var mı?"
                />
              </Form.Group>

              {/* AI Analiz Sonuçları */}
              {aiAnalysis && (
                <Alert variant={aiAnalysis.priority === 'urgent' ? 'danger' : 
                              aiAnalysis.priority === 'high' ? 'warning' : 
                              aiAnalysis.priority === 'normal' ? 'info' : 'success'}>
                  <div className="d-flex align-items-center justify-content-between mb-3">
                    <strong>🤖 AI Analizi:</strong>
                    <div className="d-flex align-items-center">
                      <span className="me-2">Güven Skoru:</span>
                      <div className="progress" style={{ width: '100px', height: '20px' }}>
                        <div 
                          className={`progress-bar ${aiAnalysis.confidence >= 80 ? 'bg-success' : 
                                                      aiAnalysis.confidence >= 60 ? 'bg-warning' : 'bg-danger'}`}
                          style={{ width: `${aiAnalysis.confidence}%` }}
                        >
                          {aiAnalysis.confidence}%
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <strong>Öncelik Seviyesi:</strong> 
                      <span className={`badge bg-${aiAnalysis.priority === 'urgent' ? 'danger' : 
                                                        aiAnalysis.priority === 'high' ? 'warning' : 
                                                        aiAnalysis.priority === 'normal' ? 'primary' : 'success'} ms-2`}>
                        {aiAnalysis.priority === 'urgent' ? 'ACİL' :
                         aiAnalysis.priority === 'high' ? 'YÜKSEK' :
                         aiAnalysis.priority === 'normal' ? 'NORMAL' : 'DÜŞÜK'}
                      </span>
                    </div>
                    <div className="col-md-6">
                      <strong>Müdahale Süresi:</strong>
                      <span className="ms-2 text-muted">
                        {aiAnalysis.priority === 'urgent' ? '0-30 dakika' :
                         aiAnalysis.priority === 'high' ? '24 saat içinde' :
                         aiAnalysis.priority === 'normal' ? '1-3 gün içinde' : '1 hafta içinde'}
                      </span>
                    </div>
                  </div>
                  
                  <div className="mb-3">
                    <strong>Açıklama:</strong> {aiAnalysis.urgencyLevel}
                  </div>
                  
                  {aiAnalysis.recommendations.length > 0 && (
                    <div className="mb-3">
                      <strong>📋 Öneriler:</strong>
                      <ul className="mb-0 mt-1">
                        {aiAnalysis.recommendations.map((rec, index) => (
                          <li key={index}>{rec}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {aiAnalysis.riskFactors.length > 0 && (
                    <div className="mb-3">
                      <strong>⚠️ Risk Faktörleri:</strong>
                      <div className="mt-1">
                        {aiAnalysis.riskFactors.map((factor, index) => (
                          <span key={index} className="badge bg-secondary me-1 mb-1">{factor}</span>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {aiAnalysis.aiInsights && aiAnalysis.aiInsights.length > 0 && (
                    <div>
                      <strong>💡 AI İçgörüleri:</strong>
                      <ul className="mb-0 mt-1">
                        {aiAnalysis.aiInsights.map((insight, index) => (
                          <li key={index} className="small">{insight}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </Alert>
              )}

              <Alert variant="info">
                <strong>Bilgi:</strong> Şikayetiniz AI tarafından analiz edilerek öncelik seviyesi belirlenir ve doktorunuza otomatik olarak bildirilir. 
                Acil durumlar için 112'yi arayın.
              </Alert>
            </Form>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleCancelComplaint}>
              <X size={16} style={{ marginRight: '5px' }} />
              İptal
            </Button>
            <Button variant="primary" onClick={handleSaveComplaint}>
              <Save size={16} style={{ marginRight: '5px' }} />
              Şikayeti Gönder
            </Button>
          </Modal.Footer>
        </Modal>
      </Container>
    );
  }

  return (
    <Container fluid>
      <Row>
        <Col lg={6} md={12} className="mx-auto">
          <Card className="mt-5">
            <Card.Header className="bg-primary text-white">
              <h5 className="mb-0">
                <User size={20} style={{ marginRight: '8px' }} />
                Hasta Girişi
              </h5>
            </Card.Header>
            <Card.Body>
              <Alert variant="info">
                <strong>Bilgi:</strong> Hasta bilgilerinizi görüntülemek için arama yapabilirsiniz.
              </Alert>
              
              <form onSubmit={handleSearch}>
                <div className="mb-3">
                  <label htmlFor="search" className="form-label">
                    TC Numarası, Telefon veya Ad-Soyad
                  </label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <Search size={16} />
                    </span>
                    <input
                      type="text"
                      className="form-control"
                      id="search"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="TC: 12345678901 veya Ad: Ahmet Yılmaz"
                      required
                    />
                  </div>
                </div>
                
                <Button type="submit" variant="primary" className="w-100">
                  Hasta Bilgilerini Görüntüle
                </Button>
              </form>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {selectedPatient && (
        <Row className="mt-4">
          <Col lg={8} md={12}>
            <PatientDashboard patient={selectedPatient} />
          </Col>
          <Col lg={4} md={12}>
            <PatientAIPanel 
              patient={selectedPatient} 
              aiSummary={aiSummary}
              drugInteractions={drugInteractions}
            />
          </Col>
        </Row>
      )}
    </Container>
  );
};

const PatientDashboard = ({ patient, onEditClick, onComplaintClick, complaints }) => {
  if (!patient) return null;

  return (
    <div className="main-content">
      {/* Hasta Bilgileri */}
      <Card className="mb-4">
        <Card.Header className="bg-primary text-white d-flex justify-content-between align-items-center">
          <h5 className="mb-0">
            <User size={20} style={{ marginRight: '8px' }} />
            Kişisel Bilgilerim
          </h5>
          <Button 
            variant="outline-light" 
            size="sm"
            onClick={onEditClick}
            className="d-flex align-items-center"
            style={{ gap: '5px' }}
          >
            <Edit3 size={16} />
            Düzenle
          </Button>
        </Card.Header>
        <Card.Body>
          <Row>
            <Col md={6}>
              <h4>{patient.name} {patient.surname}</h4>
              <p><strong>Yaş:</strong> {patient.age} • <strong>Cinsiyet:</strong> {patient.gender}</p>
              <p><strong>TC No:</strong> {patient.tc || patient.tcNo}</p>
            </Col>
            <Col md={6}>
              <p><Phone size={16} style={{ marginRight: '5px' }} /> {patient.phone}</p>
              <p><MapPin size={16} style={{ marginRight: '5px' }} /> {patient.address}</p>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      {/* Şikayet Bildirimi */}
      <Card className="mb-4">
        <Card.Header className="bg-warning text-dark d-flex justify-content-between align-items-center">
          <h5 className="mb-0">
            📝 Şikayetlerim
          </h5>
          <Button 
            variant="outline-dark" 
            size="sm"
            onClick={onComplaintClick}
            className="d-flex align-items-center"
            style={{ gap: '5px' }}
          >
            <FileText size={16} />
            Yeni Şikayet
          </Button>
        </Card.Header>
        <Card.Body>
          {complaints.length === 0 ? (
            <div className="text-center py-4">
              <p className="text-muted mb-3">Henüz şikayet bildiriminiz yok.</p>
              <Button variant="outline-primary" onClick={onComplaintClick}>
                İlk Şikayetinizi Bildirin
              </Button>
            </div>
          ) : (
            <div className="complaints-list">
              {complaints.map((complaint) => {
                const urgencyColors = {
                  low: 'success',
                  normal: 'primary',
                  high: 'warning',
                  urgent: 'danger'
                };
                
                const urgencyTexts = {
                  low: 'Düşük',
                  normal: 'Normal',
                  high: 'Yüksek',
                  urgent: 'Acil'
                };

                return (
                  <div key={complaint.id} className="complaint-item mb-3 p-3 border rounded">
                    <div className="d-flex justify-content-between align-items-start mb-2">
                      <h6 className="mb-1">{complaint.title}</h6>
                      <div className="d-flex gap-2">
                        <span className={`badge bg-${urgencyColors[complaint.urgency]}`}>
                          {urgencyTexts[complaint.urgency]}
                        </span>
                        <span className="badge bg-secondary">
                          {new Date(complaint.date).toLocaleDateString('tr-TR')}
                        </span>
                      </div>
                    </div>
                    <p className="mb-2 text-muted">{complaint.description}</p>
                    {complaint.symptoms && (
                      <p className="mb-1"><strong>Semptomlar:</strong> {complaint.symptoms}</p>
                    )}
                    {complaint.duration && (
                      <p className="mb-1"><strong>Süre:</strong> {complaint.duration}</p>
                    )}
                    {complaint.previousTreatment && (
                      <p className="mb-1"><strong>Önceki Tedavi:</strong> {complaint.previousTreatment}</p>
                    )}
                    <div className="mt-2">
                      <small className="text-success">
                        ✅ Doktorunuza bildirildi
                      </small>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card.Body>
      </Card>

      {/* Aktif İlaçlarım */}
      <Card className="mb-4">
        <Card.Header className="bg-success text-white">
          <h6 className="mb-0">
            <FileText size={16} style={{ marginRight: '5px' }} />
            Aktif İlaçlarım ({patient.medications.length})
          </h6>
        </Card.Header>
        <Card.Body>
          {patient.medications.map(medication => (
            <div key={medication.id} className="medication-item">
              <div className="d-flex justify-content-between align-items-start">
                <div>
                  <h6 className="mb-1">{medication.name}</h6>
                  <p className="mb-1"><strong>Dozaj:</strong> {medication.dosage}</p>
                  <p className="mb-1"><strong>Etken Madde:</strong> {medication.activeSubstance}</p>
                  <p className="mb-1"><strong>Başlangıç:</strong> {new Date(medication.startDate).toLocaleDateString('tr-TR')}</p>
                </div>
                <span className="badge bg-secondary">{medication.city}</span>
              </div>
              <div className="mt-2">
                <small className="text-muted">
                  <strong>Doktor:</strong> {medication.prescribingDoctor} • 
                  <strong> Hastane:</strong> {medication.hospital}
                </small>
              </div>
            </div>
          ))}
        </Card.Body>
      </Card>

      {/* Alerjilerim */}
      <Card className="mb-4">
        <Card.Header className="bg-danger text-white">
          <h6 className="mb-0">
            <FileText size={16} style={{ marginRight: '5px' }} />
            Alerjilerim ({patient.allergies.length})
          </h6>
        </Card.Header>
        <Card.Body>
          {patient.allergies.length === 0 ? (
            <p className="text-muted">Bilinen alerji yok</p>
          ) : (
            patient.allergies.map(allergy => (
              <div key={allergy} className="allergy-item">
                <h6 className="mb-1 text-danger">{allergy}</h6>
                <small className="text-muted">Alerji</small>
              </div>
            ))
          )}
        </Card.Body>
      </Card>

      {/* Yaklaşan Randevularım */}
      <Card className="mb-4">
        <Card.Header className="bg-warning text-dark">
          <h6 className="mb-0">
            <Calendar size={16} style={{ marginRight: '5px' }} />
            Yaklaşan Randevularım
          </h6>
        </Card.Header>
        <Card.Body>
          {patient.appointments.length === 0 ? (
            <p className="text-muted">Yaklaşan randevu yok</p>
          ) : (
            patient.appointments.map(appointment => (
              <div key={appointment.id} className="border rounded p-3 mb-3">
                <div className="d-flex justify-content-between align-items-start">
                  <div>
                    <h6 className="mb-1">{appointment.department}</h6>
                    <p className="mb-1"><strong>Doktor:</strong> {appointment.doctor}</p>
                    <p className="mb-1"><strong>Hastane:</strong> {appointment.hospital}</p>
                    <p className="mb-0"><strong>Not:</strong> {appointment.notes}</p>
                  </div>
                  <span className="badge bg-warning text-dark">
                    {new Date(appointment.date).toLocaleDateString('tr-TR')}
                  </span>
                </div>
              </div>
            ))
          )}
        </Card.Body>
      </Card>
    </div>
  );
};

const PatientAIPanel = ({ patient, aiSummary, drugInteractions }) => {
  if (!patient) return null;

  return (
    <div className="ai-panel">
      <div className="d-flex align-items-center mb-4">
        <h5 className="mb-0">💡 AI Sağlık Asistanım</h5>
      </div>

      {/* AI Özet */}
      {aiSummary && (
        <div className="ai-summary mb-4">
          <h6 className="mb-3">Sağlık Durumum</h6>
          <p className="mb-2"><strong>Risk Seviyesi:</strong> {aiSummary.riskLevel}</p>
          <p className="mb-2"><strong>Ana Durumlar:</strong></p>
          <ul className="mb-3">
            {aiSummary.mainProblems.map((problem, index) => (
              <li key={index}>{problem}</li>
            ))}
          </ul>
          <p className="mb-0"><strong>Öneriler:</strong> {aiSummary.recommendations}</p>
        </div>
      )}

      {/* İlaç Uyarıları */}
      {drugInteractions.length > 0 && (
        <Card className="mb-4">
          <Card.Header className="bg-warning text-dark">
            <h6 className="mb-0">⚠️ İlaç Uyarıları</h6>
          </Card.Header>
          <Card.Body>
            {drugInteractions.map((interaction, index) => (
              <div key={index} className="drug-interaction-warning mb-2">
                <small>{interaction}</small>
              </div>
            ))}
          </Card.Body>
        </Card>
      )}

      {/* Aile Geçmişi */}
      {patient.familyHistory && (
        <Card className="mb-4">
          <Card.Header>
            <h6 className="mb-0">👨‍👩‍👧‍👦 Aile Geçmişi</h6>
          </Card.Header>
          <Card.Body>
            <Row>
              {/* Anne-Baba Bilgileri */}
              <Col md={6}>
                <h6 className="text-primary mb-3">Anne-Baba</h6>
                
                {patient.familyHistory.father && (
                  <div className="mb-3">
                    <strong>👨 Baba:</strong>
                    <div className="ms-3">
                      {patient.familyHistory.father.alive ? (
                        <span className="text-success">
                          ✅ Sağ ({patient.familyHistory.father.age} yaş)
                        </span>
                      ) : (
                        <span className="text-danger">
                          ❌ Vefat etmiş ({patient.familyHistory.father.age} yaş)
                          <br />
                          <small><strong>Ölüm nedeni:</strong> {patient.familyHistory.father.causeOfDeath}</small>
                        </span>
                      )}
                      {patient.familyHistory.father.conditions && patient.familyHistory.father.conditions.length > 0 && (
                        <div className="mt-2">
                          <small><strong>Hastalıkları:</strong></small>
                          <div className="d-flex flex-wrap gap-1 mt-1">
                            {patient.familyHistory.father.conditions.map((condition, index) => (
                              <span key={index} className="badge bg-secondary">{condition}</span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {patient.familyHistory.mother && (
                  <div className="mb-3">
                    <strong>👩 Anne:</strong>
                    <div className="ms-3">
                      {patient.familyHistory.mother.alive ? (
                        <span className="text-success">
                          ✅ Sağ ({patient.familyHistory.mother.age} yaş)
                        </span>
                      ) : (
                        <span className="text-danger">
                          ❌ Vefat etmiş ({patient.familyHistory.mother.age} yaş)
                          <br />
                          <small><strong>Ölüm nedeni:</strong> {patient.familyHistory.mother.causeOfDeath}</small>
                        </span>
                      )}
                      {patient.familyHistory.mother.conditions && patient.familyHistory.mother.conditions.length > 0 && (
                        <div className="mt-2">
                          <small><strong>Hastalıkları:</strong></small>
                          <div className="d-flex flex-wrap gap-1 mt-1">
                            {patient.familyHistory.mother.conditions.map((condition, index) => (
                              <span key={index} className="badge bg-secondary">{condition}</span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </Col>

              {/* Kardeşler ve Büyükanne-Büyükbaba */}
              <Col md={6}>
                {/* Kardeşler */}
                {patient.familyHistory.siblings && patient.familyHistory.siblings.length > 0 && (
                  <div className="mb-3">
                    <h6 className="text-primary mb-2">Kardeşler</h6>
                    {patient.familyHistory.siblings.map((sibling, index) => (
                      <div key={index} className="mb-2">
                        <strong>{sibling.gender === 'erkek' ? '👨' : '👩'} {sibling.relation} ({sibling.age} yaş):</strong>
                        {sibling.conditions && sibling.conditions.length > 0 && (
                          <div className="ms-3">
                            <small><strong>Hastalıkları:</strong></small>
                            <div className="d-flex flex-wrap gap-1 mt-1">
                              {sibling.conditions.map((condition, idx) => (
                                <span key={idx} className="badge bg-info">{condition}</span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* Büyükanne-Büyükbaba */}
                {patient.familyHistory.grandparents && patient.familyHistory.grandparents.length > 0 && (
                  <div className="mb-3">
                    <h6 className="text-primary mb-2">Büyükanne-Büyükbaba</h6>
                    {patient.familyHistory.grandparents.map((grandparent, index) => (
                      <div key={index} className="mb-2">
                        <strong>👴 {grandparent.relation} ({grandparent.side}):</strong>
                        <div className="ms-3">
                          {grandparent.alive ? (
                            <span className="text-success">✅ Sağ</span>
                          ) : (
                            <span className="text-danger">
                              ❌ Vefat etmiş
                              {grandparent.causeOfDeath && (
                                <>
                                  <br />
                                  <small><strong>Ölüm nedeni:</strong> {grandparent.causeOfDeath}</small>
                                </>
                              )}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </Col>
            </Row>

            {/* Genetik Risk Faktörleri */}
            {patient.familyHistory.geneticRiskFactors && patient.familyHistory.geneticRiskFactors.length > 0 && (
              <div className="mt-4 pt-3 border-top">
                <h6 className="text-warning mb-2">⚠️ Genetik Risk Faktörleri</h6>
                <div className="d-flex flex-wrap gap-2">
                  {patient.familyHistory.geneticRiskFactors.map((risk, index) => (
                    <span 
                      key={index} 
                      className={`badge ${
                        risk.includes('Çok Yüksek') ? 'bg-danger' :
                        risk.includes('Yüksek') ? 'bg-warning text-dark' :
                        risk.includes('Orta') ? 'bg-info' : 'bg-secondary'
                      }`}
                    >
                      {risk}
                    </span>
                  ))}
                </div>
                <div className="mt-3">
                  <small className="text-muted">
                    💡 <strong>Önemli:</strong> Genetik risk faktörleri kesin hastalık anlamına gelmez. 
                    Düzenli kontroller ve sağlıklı yaşam tarzı ile riskleri azaltabilirsiniz.
                  </small>
                </div>
              </div>
            )}
          </Card.Body>
        </Card>
      )}

      {/* Sağlık İpuçları */}
      <Card className="mb-4">
        <Card.Header className="bg-info text-white">
          <h6 className="mb-0">💡 Sağlık İpuçları</h6>
        </Card.Header>
        <Card.Body>
          <div className="health-tips">
            <div className="mb-2">
              <small>• İlaçlarınızı düzenli olarak alın</small>
            </div>
            <div className="mb-2">
              <small>• Doktor randevularınızı kaçırmayın</small>
            </div>
            <div className="mb-2">
              <small>• Alerjilerinizi her zaman belirtin</small>
            </div>
            <div className="mb-2">
              <small>• Yeni ilaç kullanmadan önce doktorunuza danışın</small>
            </div>
          </div>
        </Card.Body>
      </Card>

      {/* Acil Durum Bilgileri */}
      <Card className="mb-4">
        <Card.Header className="bg-danger text-white">
          <h6 className="mb-0">🚨 Acil Durum</h6>
        </Card.Header>
        <Card.Body>
          <p className="mb-2"><strong>Acil Durum:</strong> 112</p>
          <p className="mb-2"><strong>En Yakın Hastane:</strong> {patient.medications[0]?.hospital || 'Bilinmiyor'}</p>
          <p className="mb-0"><strong>Ana Doktor:</strong> {patient.medications[0]?.prescribingDoctor || 'Bilinmiyor'}</p>
        </Card.Body>
      </Card>
    </div>
  );
};

export default PatientPanel;