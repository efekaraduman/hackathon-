import React, { useState, useEffect } from 'react';
import { Row, Col, Container, Card, Button, Alert } from 'react-bootstrap';
import { User, Search, Calendar, Phone, MapPin, FileText, Edit, MessageSquare, Brain } from 'lucide-react';
import { generateAISummary, analyzeDrugInteractions } from '../utils/aiAnalysis';
import PatientEditModal from './patient/PatientEditModal';
import ComplaintForm from './patient/ComplaintForm';
import AIHealthAssistant from './patient/AIHealthAssistant';

const PatientPanel = ({ patients, user, onPatientsUpdate, complaints, onComplaintUpdate }) => {
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [aiSummary, setAiSummary] = useState(null);
  const [drugInteractions, setDrugInteractions] = useState([]);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showComplaintForm, setShowComplaintForm] = useState(false);

  // Hasta girişi için kendi verilerini bul
  useEffect(() => {
    if (user && user.role === 'patient') {
      // Hasta kendi bilgilerini otomatik görsün (user.id ile eşleştirme)
      const patient = patients.find(p => p.id === user.id) || 
                     patients.find(p => p.name === user.name) || 
                     patients[0]; // Demo için fallback
      setSelectedPatient(patient);
    }
  }, [user, patients]);

  useEffect(() => {
    if (selectedPatient) {
      const summary = generateAISummary(selectedPatient);
      setAiSummary(summary);

      const interactions = analyzeDrugInteractions(selectedPatient.medications);
      setDrugInteractions(interactions);
    }
  }, [selectedPatient]);

  const handleSearch = (e) => {
    e.preventDefault();
    
    // Eğer kullanıcı hasta ise, sadece kendi bilgilerini arayabilir
    if (user?.role === 'patient') {
      const patient = patients.find(p => 
        p.id === user.id && (
          p.tcNo === searchTerm || 
          p.phone === searchTerm ||
          (p.name + ' ' + p.surname).toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
      
      if (patient) {
        setSelectedPatient(patient);
      } else {
        alert('Sadece kendi bilgilerinizi görüntüleyebilirsiniz. Lütfen kendi TC numaranız, telefon numaranız veya adınızı giriniz.');
      }
      return;
    }
    
    // Doktor/Yönetici için tüm hastalar aranabilir
    const patient = patients.find(p => 
      p.tcNo === searchTerm || 
      p.phone === searchTerm ||
      (p.name + ' ' + p.surname).toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    if (patient) {
      setSelectedPatient(patient);
    } else {
      alert('Hasta bulunamadı. Lütfen TC numarası, telefon numarası veya ad-soyad ile arama yapın.');
    }
  };

  // Hasta bilgilerini güncelleme fonksiyonu
  const handlePatientUpdate = (updatedPatient) => {
    setSelectedPatient(updatedPatient);
    
    // Eğer onPatientsUpdate callback'i varsa (parent component'e güncelleme bildirimi)
    if (onPatientsUpdate) {
      onPatientsUpdate(updatedPatient);
    }
    
    // Modal'ı kapat
    setShowEditModal(false);
    
    console.log('Hasta bilgileri güncellendi:', updatedPatient);
  };

  // Şikayet gönderme fonksiyonu
  const handleComplaintSubmit = (complaintData) => {
    onComplaintUpdate(complaintData);
    console.log('Yeni şikayet gönderildi:', complaintData);
    alert('Şikayetiniz başarıyla gönderildi. Doktorunuz randevunuzda bu bilgileri görecek.');
  };

  // Hasta girişi yapıldığında sadece kendi bilgilerini göster
  if (user?.role === 'patient') {
    return (
      <Container fluid>
        {selectedPatient ? (
          <>
            {/* Hasta Hoş Geldiniz Mesajı */}
            <Row className="mb-4">
              <Col>
                <Alert variant="success" className="d-flex align-items-center justify-content-between">
                  <div className="d-flex align-items-center">
                    <User size={20} style={{ marginRight: '8px' }} />
                    <div>
                      <strong>Hoş geldiniz, {selectedPatient.name} {selectedPatient.surname}!</strong>
                      <br />
                      <small>Aşağıda kendi hasta bilgilerinizi görüntüleyebilirsiniz.</small>
                    </div>
                  </div>
                  <div className="d-flex gap-2">
                    <Button 
                      variant="outline-primary" 
                      size="sm"
                      onClick={() => setShowEditModal(true)}
                      className="d-flex align-items-center"
                    >
                      <Edit size={16} style={{ marginRight: '4px' }} />
                      Bilgilerimi Düzenle
                    </Button>
                    <Button 
                      variant="outline-success" 
                      size="sm"
                      onClick={() => setShowComplaintForm(true)}
                      className="d-flex align-items-center"
                    >
                      <MessageSquare size={16} style={{ marginRight: '4px' }} />
                      Şikayet Bildir
                    </Button>
                  </div>
                </Alert>
              </Col>
            </Row>
            
            {/* Hasta Bilgileri */}
            <Row>
              <Col lg={8} md={12}>
                <PatientDashboard patient={selectedPatient} />
              </Col>
              <Col lg={4} md={12}>
                <AIHealthAssistant 
                  patient={selectedPatient} 
                  complaints={complaints}
                />
              </Col>
            </Row>
          </>
        ) : (
          <Row>
            <Col lg={6} md={12} className="mx-auto">
              <Card className="mt-5">
                <Card.Header className="bg-warning text-dark">
                  <h5 className="mb-0">
                    <User size={20} style={{ marginRight: '8px' }} />
                    Hasta Bilgisi Yükleniyor...
                  </h5>
                </Card.Header>
                <Card.Body>
                  <Alert variant="info">
                    Hasta bilgileriniz yükleniyor. Lütfen bekleyiniz...
                  </Alert>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        )}
        
        {/* Hasta Bilgi Düzenleme Modalı */}
        <PatientEditModal
          show={showEditModal}
          onHide={() => setShowEditModal(false)}
          patient={selectedPatient}
          onSave={handlePatientUpdate}
        />
        
        {/* Şikayet Bildirimi Modalı */}
        <ComplaintForm
          show={showComplaintForm}
          onHide={() => setShowComplaintForm(false)}
          patient={selectedPatient}
          onSubmit={handleComplaintSubmit}
        />
      </Container>
    );
  }

  // Doktor/Yönetici için arama sistemi
  return (
    <Container fluid>
      <Row>
        <Col lg={6} md={12} className="mx-auto">
          <Card className="mt-5">
            <Card.Header className="bg-primary text-white">
              <h5 className="mb-0">
                <User size={20} style={{ marginRight: '8px' }} />
                Hasta Arama
              </h5>
            </Card.Header>
            <Card.Body>
              <Alert variant="info">
                <strong>Bilgi:</strong> Hasta bilgilerini görüntülemek için arama yapabilirsiniz.
              </Alert>
              
              <form onSubmit={handleSearch}>
                <div className="mb-3">
                  <label htmlFor="search" className="form-label">
                    TC Numarası, Telefon veya Ad-Soyad
                  </label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <Search size={16} />
                    </span>
                    <input
                      type="text"
                      className="form-control"
                      id="search"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="TC: 12345678901 veya Ad: Ahmet Yılmaz"
                      required
                    />
                  </div>
                </div>
                
                <Button type="submit" variant="primary" className="w-100">
                  Hasta Bilgilerini Görüntüle
                </Button>
              </form>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {selectedPatient && (
        <Row className="mt-4">
          <Col lg={8} md={12}>
            <PatientDashboard patient={selectedPatient} />
          </Col>
          <Col lg={4} md={12}>
            <PatientAIPanel 
              patient={selectedPatient} 
              aiSummary={aiSummary}
              drugInteractions={drugInteractions}
            />
          </Col>
        </Row>
      )}
    </Container>
  );
};

const PatientDashboard = ({ patient }) => {
  if (!patient) return null;

  return (
    <div className="main-content">
      {/* Hasta Bilgileri */}
      <Card className="mb-4">
        <Card.Header className="bg-primary text-white">
          <h5 className="mb-0">
            <User size={20} style={{ marginRight: '8px' }} />
            Kişisel Bilgilerim
          </h5>
        </Card.Header>
        <Card.Body>
          <Row>
            <Col md={6}>
              <h4>{patient.name} {patient.surname}</h4>
              <p><strong>Yaş:</strong> {patient.age} • <strong>Cinsiyet:</strong> {patient.gender}</p>
              <p><strong>TC No:</strong> {patient.tcNo}</p>
            </Col>
            <Col md={6}>
              <p><Phone size={16} style={{ marginRight: '5px' }} /> {patient.phone}</p>
              <p><MapPin size={16} style={{ marginRight: '5px' }} /> {patient.address}</p>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      {/* Aktif İlaçlarım */}
      <Card className="mb-4">
        <Card.Header className="bg-success text-white">
          <h6 className="mb-0">
            <FileText size={16} style={{ marginRight: '5px' }} />
            Aktif İlaçlarım ({patient.medications.length})
          </h6>
        </Card.Header>
        <Card.Body>
          {patient.medications.map(medication => (
            <div key={medication.id} className="medication-item">
              <div className="d-flex justify-content-between align-items-start">
                <div>
                  <h6 className="mb-1">{medication.name}</h6>
                  <p className="mb-1"><strong>Dozaj:</strong> {medication.dosage}</p>
                  <p className="mb-1"><strong>Etken Madde:</strong> {medication.activeSubstance}</p>
                  <p className="mb-1"><strong>Başlangıç:</strong> {new Date(medication.startDate).toLocaleDateString('tr-TR')}</p>
                </div>
                <span className="badge bg-secondary">{medication.city}</span>
              </div>
              <div className="mt-2">
                <small className="text-muted">
                  <strong>Doktor:</strong> {medication.prescribingDoctor} • 
                  <strong> Hastane:</strong> {medication.hospital}
                </small>
              </div>
            </div>
          ))}
        </Card.Body>
      </Card>

      {/* Alerjilerim */}
      <Card className="mb-4">
        <Card.Header className="bg-danger text-white">
          <h6 className="mb-0">
            <FileText size={16} style={{ marginRight: '5px' }} />
            Alerjilerim ({patient.allergies.length})
          </h6>
        </Card.Header>
        <Card.Body>
          {patient.allergies.length === 0 ? (
            <p className="text-muted">Bilinen alerji yok</p>
          ) : (
            patient.allergies.map(allergy => (
              <div key={allergy} className="allergy-item">
                <h6 className="mb-1 text-danger">{allergy}</h6>
                <small className="text-muted">Alerji</small>
              </div>
            ))
          )}
        </Card.Body>
      </Card>

      {/* Yaklaşan Randevularım */}
      <Card className="mb-4">
        <Card.Header className="bg-warning text-dark">
          <h6 className="mb-0">
            <Calendar size={16} style={{ marginRight: '5px' }} />
            Yaklaşan Randevularım
          </h6>
        </Card.Header>
        <Card.Body>
          {patient.appointments.length === 0 ? (
            <p className="text-muted">Yaklaşan randevu yok</p>
          ) : (
            patient.appointments.map(appointment => (
              <div key={appointment.id} className="border rounded p-3 mb-3">
                <div className="d-flex justify-content-between align-items-start">
                  <div>
                    <h6 className="mb-1">{appointment.department}</h6>
                    <p className="mb-1"><strong>Doktor:</strong> {appointment.doctor}</p>
                    <p className="mb-1"><strong>Hastane:</strong> {appointment.hospital}</p>
                    <p className="mb-0"><strong>Not:</strong> {appointment.notes}</p>
                  </div>
                  <span className="badge bg-warning text-dark">
                    {new Date(appointment.date).toLocaleDateString('tr-TR')}
                  </span>
                </div>
              </div>
            ))
          )}
        </Card.Body>
      </Card>
    </div>
  );
};

const PatientAIPanel = ({ patient, aiSummary, drugInteractions }) => {
  if (!patient) return null;

  return (
    <div className="ai-panel">
      <div className="d-flex align-items-center mb-4">
        <h5 className="mb-0">💡 AI Sağlık Asistanım</h5>
      </div>

      {/* AI Özet */}
      {aiSummary && (
        <div className="ai-summary mb-4">
          <h6 className="mb-3">Sağlık Durumum</h6>
          <p className="mb-2"><strong>Risk Seviyesi:</strong> {aiSummary.riskLevel}</p>
          <p className="mb-2"><strong>Ana Durumlar:</strong></p>
          <ul className="mb-3">
            {aiSummary.mainProblems.map((problem, index) => (
              <li key={index}>{problem}</li>
            ))}
          </ul>
          <p className="mb-0"><strong>Öneriler:</strong> {aiSummary.recommendations}</p>
        </div>
      )}

      {/* İlaç Uyarıları */}
      {drugInteractions.length > 0 && (
        <Card className="mb-4">
          <Card.Header className="bg-warning text-dark">
            <h6 className="mb-0">⚠️ İlaç Uyarıları</h6>
          </Card.Header>
          <Card.Body>
            {drugInteractions.map((interaction, index) => (
              <div key={index} className="drug-interaction-warning mb-2">
                <small>{interaction}</small>
              </div>
            ))}
          </Card.Body>
        </Card>
      )}

      {/* Sağlık İpuçları */}
      <Card className="mb-4">
        <Card.Header className="bg-info text-white">
          <h6 className="mb-0">💡 Sağlık İpuçları</h6>
        </Card.Header>
        <Card.Body>
          <div className="health-tips">
            <div className="mb-2">
              <small>• İlaçlarınızı düzenli olarak alın</small>
            </div>
            <div className="mb-2">
              <small>• Doktor randevularınızı kaçırmayın</small>
            </div>
            <div className="mb-2">
              <small>• Alerjilerinizi her zaman belirtin</small>
            </div>
            <div className="mb-2">
              <small>• Yeni ilaç kullanmadan önce doktorunuza danışın</small>
            </div>
          </div>
        </Card.Body>
      </Card>

      {/* Acil Durum Bilgileri */}
      <Card className="mb-4">
        <Card.Header className="bg-danger text-white">
          <h6 className="mb-0">🚨 Acil Durum</h6>
        </Card.Header>
        <Card.Body>
          <p className="mb-2"><strong>Acil Durum:</strong> 112</p>
          <p className="mb-2"><strong>En Yakın Hastane:</strong> {patient.medications[0]?.hospital || 'Bilinmiyor'}</p>
          <p className="mb-0"><strong>Ana Doktor:</strong> {patient.medications[0]?.prescribingDoctor || 'Bilinmiyor'}</p>
        </Card.Body>
      </Card>
    </div>
  );
};

export default PatientPanel;
