import React, { useState, useEffect } from 'react';
import { Alert, Toast, ToastContainer } from 'react-bootstrap';
import { CheckCircle, XCircle, Edit, Info, AlertTriangle } from 'lucide-react';

const NotificationSystem = () => {
  const [notifications, setNotifications] = useState([]);

  // Bildirim ekleme fonksiyonu
  const addNotification = (type, title, message, duration = 5000) => {
    const id = Date.now() + Math.random();
    const newNotification = {
      id,
      type,
      title,
      message,
      timestamp: new Date(),
      duration
    };

    setNotifications(prev => [...prev, newNotification]);

    // Otomatik kaldırma
    if (duration > 0) {
      setTimeout(() => {
        removeNotification(id);
      }, duration);
    }
  };

  // Bildirim kaldırma fonksiyonu
  const removeNotification = (id) => {
    setNotifications(prev => prev.filter(notification => notification.id !== id));
  };

  // Bildirim türüne göre ikon ve stil
  const getNotificationConfig = (type) => {
    switch (type) {
      case 'success':
        return {
          icon: <CheckCircle size={20} />,
          variant: 'success',
          bg: 'success'
        };
      case 'error':
        return {
          icon: <XCircle size={20} />,
          variant: 'danger',
          bg: 'danger'
        };
      case 'warning':
        return {
          icon: <AlertTriangle size={20} />,
          variant: 'warning',
          bg: 'warning'
        };
      case 'info':
        return {
          icon: <Info size={20} />,
          variant: 'info',
          bg: 'info'
        };
      case 'edit':
        return {
          icon: <Edit size={20} />,
          variant: 'primary',
          bg: 'primary'
        };
      default:
        return {
          icon: <Info size={20} />,
          variant: 'info',
          bg: 'info'
        };
    }
  };

  // Global bildirim fonksiyonunu window'a ekle
  useEffect(() => {
    window.showNotification = addNotification;
    return () => {
      delete window.showNotification;
    };
  }, []);

  return (
    <ToastContainer position="top-end" className="p-3" style={{ zIndex: 9999 }}>
      {notifications.map((notification) => {
        const config = getNotificationConfig(notification.type);
        return (
          <Toast
            key={notification.id}
            show={true}
            onClose={() => removeNotification(notification.id)}
            delay={notification.duration}
            autohide={notification.duration > 0}
            className="mb-2"
            style={{ minWidth: '300px' }}
          >
            <Toast.Header className={`bg-${config.bg} text-white`}>
              <div className="me-2">
                {config.icon}
              </div>
              <strong className="me-auto">{notification.title}</strong>
              <small className="text-white-50">
                {notification.timestamp.toLocaleTimeString('tr-TR')}
              </small>
            </Toast.Header>
            <Toast.Body>
              <div className="d-flex align-items-start">
                <div className="me-2">
                  {config.icon}
                </div>
                <div className="flex-grow-1">
                  <p className="mb-0">{notification.message}</p>
                </div>
              </div>
            </Toast.Body>
          </Toast>
        );
      })}
    </ToastContainer>
  );
};

export default NotificationSystem;
