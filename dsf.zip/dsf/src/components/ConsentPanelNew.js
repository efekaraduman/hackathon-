import React, { useState, useEffect } from 'react';
import { Form, Button, Alert, Modal, Row, Col } from 'react-bootstrap';
import { 
  Shield, 
  CheckCircle, 
  XCircle, 
  FileText, 
  Eye, 
  Lock,
  AlertTriangle,
  Info,
  User,
  Database,
  Brain,
  Share2,
  FileCheck,
  EyeOff
} from 'lucide-react';

const ConsentPanel = ({ patient, onConsentChange }) => {
  const [consentData, setConsentData] = useState({
    dataExtraction: false,
    aiAnalysis: false,
    dataSharing: false,
    auditLogging: true, // Varsayılan olarak true
    anonymization: true // Varsayılan olarak true
  });
  const [showConsentModal, setShowConsentModal] = useState(false);
  const [consentHistory, setConsentHistory] = useState([]);

  useEffect(() => {
    if (patient) {
      loadConsentData();
    }
  }, [patient]);

  const loadConsentData = () => {
    // LocalStorage'dan hasta rızası verilerini yükle
    const savedConsent = localStorage.getItem(`consent_${patient.id}`);
    if (savedConsent) {
      const parsed = JSON.parse(savedConsent);
      setConsentData(parsed.consent);
      setConsentHistory(parsed.history || []);
    }
  };

  const saveConsentData = (newConsent) => {
    const consentRecord = {
      timestamp: new Date().toISOString(),
      consent: newConsent,
      patientId: patient.id,
      changes: Object.keys(newConsent).filter(key => 
        consentData[key] !== newConsent[key]
      )
    };

    const updatedHistory = [consentRecord, ...consentHistory];
    setConsentHistory(updatedHistory);

    // LocalStorage'a kaydet
    localStorage.setItem(`consent_${patient.id}`, JSON.stringify({
      consent: newConsent,
      history: updatedHistory
    }));

    setConsentData(newConsent);
    
    if (onConsentChange) {
      onConsentChange({
        consent: newConsent,
        history: updatedHistory
      });
    }
  };

  const handleConsentChange = (key, value) => {
    const newConsent = { ...consentData, [key]: value };
    saveConsentData(newConsent);
  };

  const getConsentStatus = () => {
    const total = Object.keys(consentData).length;
    const granted = Object.values(consentData).filter(Boolean).length;
    return { granted, total, percentage: Math.round((granted / total) * 100) };
  };

  const getConsentIcon = (key) => {
    switch (key) {
      case 'dataExtraction': return Database;
      case 'aiAnalysis': return Brain;
      case 'dataSharing': return Share2;
      case 'auditLogging': return FileCheck;
      case 'anonymization': return EyeOff;
      default: return Shield;
    }
  };

  const getConsentTitle = (key) => {
    switch (key) {
      case 'dataExtraction': return 'Veri Çıkarımı ve İşleme';
      case 'aiAnalysis': return 'AI Analiz ve Özetleme';
      case 'dataSharing': return 'Veri Paylaşımı';
      case 'auditLogging': return 'Audit Logging';
      case 'anonymization': return 'Veri Anonimleştirme';
      default: return 'Bilinmeyen';
    }
  };

  const getConsentDescription = (key) => {
    switch (key) {
      case 'dataExtraction': return 'Hasta verilerinin sistem tarafından işlenmesi';
      case 'aiAnalysis': return 'Yapay zeka ile hasta verilerinin analiz edilmesi';
      case 'dataSharing': return 'Diğer sağlık kuruluşları ile veri paylaşımı';
      case 'auditLogging': return 'Sistem güvenliği için zorunlu log kayıtları';
      case 'anonymization': return 'Kişisel verilerin korunması için anonimleştirme';
      default: return 'Açıklama bulunamadı';
    }
  };

  const status = getConsentStatus();

  if (!patient) return null;

  return (
    <>
      <div className="minimal-card">
        <div className="minimal-card-header">
          <div className="d-flex justify-content-between align-items-center">
            <h5 className="minimal-card-title">
              <Shield size={20} />
              Hasta Rızası ve Veri Koruma
            </h5>
            <button
              className="minimal-btn minimal-btn-sm minimal-btn-secondary"
              onClick={() => setShowConsentModal(true)}
            >
              <Eye size={16} />
              Geçmiş
            </button>
          </div>
        </div>
        
        <div className="minimal-card-body">
          {/* Rıza Durumu */}
          <div className="minimal-stats mb-4">
            <div className="minimal-stat">
              <div className="minimal-stat-value">{status.granted}</div>
              <div className="minimal-stat-label">Verilen Rıza</div>
            </div>
            <div className="minimal-stat">
              <div className="minimal-stat-value">{status.total}</div>
              <div className="minimal-stat-label">Toplam Rıza</div>
            </div>
            <div className="minimal-stat">
              <div className="minimal-stat-value">{status.percentage}%</div>
              <div className="minimal-stat-label">Rıza Oranı</div>
            </div>
          </div>

          {/* Rıza Durumu Göstergesi */}
          <div className="mb-4">
            <div className="d-flex align-items-center mb-2">
              <span className="minimal-label">Genel Rıza Durumu:</span>
              <span className={`minimal-badge ${status.percentage >= 80 ? 'minimal-badge-success' : status.percentage >= 50 ? 'minimal-badge-warning' : 'minimal-badge-danger'} ms-2`}>
                {status.percentage >= 80 ? 'Tam Rıza' : status.percentage >= 50 ? 'Kısmi Rıza' : 'Rıza Yok'}
              </span>
            </div>
            <div className="minimal-progress">
              <div 
                className="minimal-progress-bar"
                style={{ width: `${status.percentage}%` }}
              ></div>
            </div>
          </div>

          {/* Rıza Kategorileri */}
          <div className="consent-categories">
            {Object.entries(consentData).map(([key, value]) => {
              const IconComponent = getConsentIcon(key);
              return (
                <div key={key} className="consent-category">
                  <div className="consent-category-header">
                    <div className="d-flex align-items-center">
                      <IconComponent size={20} className="me-3" style={{ color: 'var(--primary-light)' }} />
                      <div>
                        <h6 className="minimal-card-title mb-1">{getConsentTitle(key)}</h6>
                        <p className="minimal-timeline-description mb-0">{getConsentDescription(key)}</p>
                      </div>
                    </div>
                    <div className="consent-toggle">
                      <button
                        className={`minimal-btn minimal-btn-sm ${value ? 'minimal-btn-success' : 'minimal-btn-danger'}`}
                        onClick={() => handleConsentChange(key, !value)}
                      >
                        {value ? <CheckCircle size={16} /> : <XCircle size={16} />}
                        {value ? 'Verildi' : 'Verilmedi'}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Bilgi Uyarısı */}
          <Alert variant="info" className="minimal-alert minimal-alert-info mt-4">
            <Info size={20} className="me-2" />
            <strong>Bilgi:</strong> Hasta rızası KVKK ve GDPR uyumluluğu için gereklidir. 
            Rıza verilmeyen veriler işlenmeyecektir.
          </Alert>

          {/* Son Güncelleme */}
          <div className="mt-3">
            <small className="minimal-timeline-location">
              <FileText size={14} className="me-1" />
              Son güncelleme: {consentHistory.length > 0 ? 
                new Date(consentHistory[0].timestamp).toLocaleString('tr-TR') : 
                'Henüz güncelleme yok'
              }
            </small>
          </div>
        </div>
      </div>

      {/* Rıza Geçmişi Modal */}
      <Modal show={showConsentModal} onHide={() => setShowConsentModal(false)} size="lg">
        <Modal.Header closeButton className="minimal-card-header">
          <Modal.Title className="minimal-card-title">
            <FileText size={20} />
            Rıza Geçmişi
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className="minimal-card-body">
          {consentHistory.length === 0 ? (
            <div className="text-center py-4">
              <FileText size={48} className="mb-3" style={{ color: 'var(--gray-500)' }} />
              <p className="minimal-timeline-description">Henüz rıza geçmişi bulunmuyor.</p>
            </div>
          ) : (
            <div className="minimal-timeline">
              {consentHistory.map((record, index) => (
                <div key={index} className="minimal-timeline-item">
                  <div className="minimal-timeline-marker">
                    <div className="minimal-timeline-icon" style={{ backgroundColor: 'var(--primary-light)' }}>
                      <FileText size={16} />
                    </div>
                    {index < consentHistory.length - 1 && (
                      <div className="minimal-timeline-line"></div>
                    )}
                  </div>
                  
                  <div className="minimal-timeline-content">
                    <div className="minimal-timeline-header">
                      <div className="minimal-timeline-date">
                        <FileText size={14} className="me-1" />
                        {new Date(record.timestamp).toLocaleString('tr-TR')}
                      </div>
                      <span className="minimal-badge minimal-badge-primary">
                        {record.changes.length} Değişiklik
                      </span>
                    </div>
                    
                    <div className="minimal-timeline-title">
                      Rıza Güncellendi
                    </div>
                    
                    <div className="minimal-timeline-description">
                      Değişen kategoriler: {record.changes.join(', ')}
                    </div>
                    
                    <div className="minimal-timeline-tags">
                      {record.changes.map((change, changeIndex) => (
                        <span key={changeIndex} className="minimal-badge minimal-badge-gray">
                          {getConsentTitle(change)}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Modal.Body>
        <Modal.Footer className="minimal-card-header">
          <button 
            className="minimal-btn minimal-btn-secondary"
            onClick={() => setShowConsentModal(false)}
          >
            Kapat
          </button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default ConsentPanel;
