import React, { useState, useEffect } from 'react';
import { Row, Col, Container, Button, Modal } from 'react-bootstrap';
import PatientList from './doctor/PatientList';
import PatientDetails from './doctor/PatientDetails';
import PatientSummaryCard from './doctor/PatientSummaryCardNew';
import ReconciledMedicationList from './doctor/ReconciledMedicationListNew';
import AdvancedTimeline from './doctor/AdvancedTimelineNew';
import AuditLogPanel from './doctor/AuditLogPanel';
import KPIDashboard from './doctor/KPIDashboard';
import ConsentPanel from './ConsentPanelNew';
import AdvancedAIPanel from './doctor/AdvancedAIPanelNew';
import AppointmentScheduling from './doctor/AppointmentScheduling';
import PrescriptionManagement from './doctor/PrescriptionManagement';
import LabResultsIntegration from './doctor/LabResultsIntegration';
import DashboardAnalytics from './doctor/DashboardAnalytics';
import { generateAISummary, analyzeDrugInteractions } from '../utils/aiAnalysis';
import auditLogger from '../utils/auditLog';
import { Target, FileText, Activity, Calendar, Pill, Activity as ActivityIcon, BarChart3, Users } from 'lucide-react';

const DoctorPanel = ({ patients, setPatients, onLogout, user }) => {
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredPatients, setFilteredPatients] = useState(patients);
  const [selectedDiseases, setSelectedDiseases] = useState([]);
  const [aiSummary, setAiSummary] = useState(null);
  const [drugInteractions, setDrugInteractions] = useState([]);
  const [showAuditLog, setShowAuditLog] = useState(false);
  const [showKPIDashboard, setShowKPIDashboard] = useState(false);
  const [showConsentPanel, setShowConsentPanel] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  // Tüm hastalıkları topla
  const allDiseases = [...new Set(patients.flatMap(patient => patient.chronicDiseases))];

  useEffect(() => {
    setFilteredPatients(patients);
  }, [patients]);

  useEffect(() => {
    // Arama ve filtreleme
    let filtered = patients;

    // Arama filtresi
    if (searchTerm) {
      filtered = filtered.filter(patient =>
        `${patient.name} ${patient.surname}`.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Hastalık filtresi
    if (selectedDiseases.length > 0) {
      filtered = filtered.filter(patient =>
        selectedDiseases.some(disease => patient.chronicDiseases.includes(disease))
      );
    }

    setFilteredPatients(filtered);
  }, [patients, searchTerm, selectedDiseases]);

  useEffect(() => {
    if (selectedPatient) {
      // AI özet oluştur
      const summary = generateAISummary(selectedPatient);
      setAiSummary(summary);

      // İlaç etkileşimlerini analiz et
      const interactions = analyzeDrugInteractions(selectedPatient.medications);
      setDrugInteractions(interactions);
    }
  }, [selectedPatient]);

  const handlePatientSelect = (patient) => {
    setSelectedPatient(patient);
  };

  const handleDiseaseFilter = (disease) => {
    if (selectedDiseases.includes(disease)) {
      setSelectedDiseases(selectedDiseases.filter(d => d !== disease));
    } else {
      setSelectedDiseases([...selectedDiseases, disease]);
    }
  };

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedDiseases([]);
  };

  const handleApprovalChange = (approvalData) => {
    if (selectedPatient && approvalData) {
      auditLogger.logApprovalChange(
        selectedPatient.id, 
        approvalData.action || approvalData.type, 
        approvalData.confidence || 0, 
        approvalData.feedback || ''
      );
    }
  };

  const handleMedicationUpdate = (medicationId, newData) => {
    if (selectedPatient) {
      const oldMedication = selectedPatient.medications.find(med => med.id === medicationId);
      if (oldMedication) {
        auditLogger.logMedicationChange(selectedPatient.id, medicationId, oldMedication, newData);
        
        // Hasta verilerini güncelle
        const updatedPatients = patients.map(patient => {
          if (patient.id === selectedPatient.id) {
            return {
              ...patient,
              medications: patient.medications.map(med => 
                med.id === medicationId ? { ...med, ...newData } : med
              )
            };
          }
          return patient;
        });
        setPatients(updatedPatients);
        setSelectedPatient(updatedPatients.find(p => p.id === selectedPatient.id));
      }
    }
  };

  return (
    <Container fluid>
      {/* Üst Panel - Hasta Özet Kartı */}
      {selectedPatient && (
        <Row className="mb-4">
          <Col>
            <PatientSummaryCard patient={selectedPatient} aiSummary={aiSummary} />
          </Col>
        </Row>
      )}

      {/* Ana Panel */}
      <Row>
        {/* Sol Panel - Hasta Listesi */}
        <Col lg={4} md={12}>
          <PatientList
            patients={filteredPatients}
            selectedPatient={selectedPatient}
            onPatientSelect={handlePatientSelect}
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
            allDiseases={allDiseases}
            selectedDiseases={selectedDiseases}
            onDiseaseFilter={handleDiseaseFilter}
            onClearFilters={clearFilters}
          />
        </Col>

        {/* Orta Panel - Reconciled Medication List */}
        <Col lg={5} md={12}>
          {selectedPatient ? (
            <div>
              <ReconciledMedicationList
                patient={selectedPatient}
                onMedicationUpdate={handleMedicationUpdate}
              />
              <div className="mt-4">
                <AdvancedTimeline patient={selectedPatient} />
              </div>
            </div>
          ) : (
            <div className="main-content">
              <div className="text-center text-muted py-5">
                <h4>Hasta Seçiniz</h4>
                <p>Detayları görüntülemek için sol panelden bir hasta seçin</p>
              </div>
            </div>
          )}
        </Col>

        {/* Sağ Panel - AI Analiz */}
        <Col lg={3} md={12}>
          <AdvancedAIPanel
            patient={selectedPatient}
            aiSummary={aiSummary}
            drugInteractions={drugInteractions}
            onApprovalChange={handleApprovalChange}
          />
        </Col>
      </Row>

      {/* Alt Panel - Hasta Rızası */}
      {selectedPatient && (
        <Row className="mt-4">
          <Col>
            <ConsentPanel 
              patient={selectedPatient}
              onConsentChange={(consentData) => {
                auditLogger.addLog('CONSENT_CHANGE', {
                  patientId: selectedPatient.id,
                  consentData,
                  type: 'consent_update'
                });
              }}
            />
          </Col>
        </Row>
      )}

      {/* Tab Navigation */}
      <Row className="mt-4">
        <Col>
          <div className="d-flex justify-content-center gap-2 mb-4">
            <button
              className={`minimal-btn ${activeTab === 'overview' ? 'minimal-btn-primary' : 'minimal-btn-secondary'}`}
              onClick={() => setActiveTab('overview')}
            >
              <Activity size={16} />
              Genel Bakış
            </button>
            <button
              className={`minimal-btn ${activeTab === 'appointments' ? 'minimal-btn-primary' : 'minimal-btn-secondary'}`}
              onClick={() => setActiveTab('appointments')}
            >
              <Calendar size={16} />
              Randevular
            </button>
            <button
              className={`minimal-btn ${activeTab === 'prescriptions' ? 'minimal-btn-primary' : 'minimal-btn-secondary'}`}
              onClick={() => setActiveTab('prescriptions')}
            >
              <Pill size={16} />
              Reçeteler
            </button>
            <button
              className={`minimal-btn ${activeTab === 'lab' ? 'minimal-btn-primary' : 'minimal-btn-secondary'}`}
              onClick={() => setActiveTab('lab')}
            >
              <ActivityIcon size={16} />
              Lab Sonuçları
            </button>
            <button
              className={`minimal-btn ${activeTab === 'analytics' ? 'minimal-btn-primary' : 'minimal-btn-secondary'}`}
              onClick={() => setActiveTab('analytics')}
            >
              <BarChart3 size={16} />
              Analitik
            </button>
          </div>
        </Col>
      </Row>

      {/* Tab Content */}
      {activeTab === 'overview' && selectedPatient && (
        <Row>
          <Col>
            <div className="d-flex justify-content-center gap-3">
               <button 
                 className="minimal-btn minimal-btn-secondary"
                 onClick={() => setShowAuditLog(true)}
               >
                 <FileText size={16} />
                 Audit Log
               </button>
               <button 
                 className="minimal-btn minimal-btn-success"
                 onClick={() => setShowKPIDashboard(true)}
               >
                 <Target size={16} />
                 KPI Dashboard
               </button>
               <button 
                 className="minimal-btn minimal-btn-warning"
                 onClick={() => setShowConsentPanel(true)}
               >
                 <Activity size={16} />
                 Rıza Yönetimi
               </button>
            </div>
          </Col>
        </Row>
      )}

      {activeTab === 'appointments' && selectedPatient && (
        <Row>
          <Col>
            <AppointmentScheduling 
              patient={selectedPatient}
              onAppointmentUpdate={(appointments) => {
                console.log('Appointments updated:', appointments);
              }}
            />
          </Col>
        </Row>
      )}

      {activeTab === 'prescriptions' && selectedPatient && (
        <Row>
          <Col>
            <PrescriptionManagement 
              patient={selectedPatient}
              onPrescriptionUpdate={(prescriptions) => {
                console.log('Prescriptions updated:', prescriptions);
              }}
            />
          </Col>
        </Row>
      )}

      {activeTab === 'lab' && selectedPatient && (
        <Row>
          <Col>
            <LabResultsIntegration 
              patient={selectedPatient}
              onLabResultUpdate={(labResults) => {
                console.log('Lab results updated:', labResults);
              }}
            />
          </Col>
        </Row>
      )}

      {activeTab === 'analytics' && (
        <Row>
          <Col>
            <DashboardAnalytics 
              patient={selectedPatient}
              allPatients={patients}
            />
          </Col>
        </Row>
      )}

      {/* Modals */}
      <AuditLogPanel 
        show={showAuditLog} 
        onHide={() => setShowAuditLog(false)}
        patientId={selectedPatient?.id}
      />
      
      <Modal show={showKPIDashboard} onHide={() => setShowKPIDashboard(false)} size="xl">
        <Modal.Header closeButton>
          <Modal.Title>KPI Dashboard</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <KPIDashboard 
            patients={patients} 
            show={showKPIDashboard} 
            onHide={() => setShowKPIDashboard(false)}
          />
        </Modal.Body>
      </Modal>

      <Modal show={showConsentPanel} onHide={() => setShowConsentPanel(false)} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Hasta Rızası Yönetimi</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <ConsentPanel 
            patient={selectedPatient}
            onConsentUpdate={(consent) => {
              console.log('Consent updated:', consent);
            }}
          />
        </Modal.Body>
      </Modal>
    </Container>
  );
};

export default DoctorPanel;