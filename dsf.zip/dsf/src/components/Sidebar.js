import React, { useState } from 'react';
import { 
  Activity, 
  Users, 
  Calendar, 
  Pill, 
  FileText, 
  BarChart3, 
  Settings, 
  LogOut,
  Menu,
  X,
  User,
  Shield
} from 'lucide-react';

const Sidebar = ({ activeTab, setActiveTab, onLogout, user }) => {
  const [isCompact, setIsCompact] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const navigationItems = [
    {
      section: 'Ana Menü',
      items: [
        {
          id: 'overview',
          label: 'Genel Bakış',
          icon: Activity,
          description: 'Hasta özeti ve genel bilgiler'
        },
        {
          id: 'patients',
          label: 'Hasta Listesi',
          icon: Users,
          description: 'Tüm hastaları görüntüle'
        }
      ]
    },
    {
      section: 'Hasta Yönetimi',
      items: [
        {
          id: 'appointments',
          label: 'Randevular',
          icon: Calendar,
          description: 'Randevu planlama ve takip'
        },
        {
          id: 'prescriptions',
          label: 'Reçeteler',
          icon: Pill,
          description: 'Reçete yönetimi'
        },
        {
          id: 'lab',
          label: 'Lab Sonuçları',
          icon: FileText,
          description: 'Laboratuvar test sonuçları'
        }
      ]
    },
    {
      section: 'Analitik',
      items: [
        {
          id: 'analytics',
          label: 'Dashboard',
          icon: BarChart3,
          description: 'İstatistikler ve grafikler'
        }
      ]
    }
  ];

  const handleTabChange = (tabId) => {
    setActiveTab(tabId);
    setIsMobileOpen(false);
  };

  const toggleCompact = () => {
    setIsCompact(!isCompact);
  };

  const toggleMobile = () => {
    setIsMobileOpen(!isMobileOpen);
  };

  return (
    <>
      {/* Mobile Toggle Button */}
      <button
        className="health-mobile-toggle"
        onClick={toggleMobile}
        aria-label="Menüyü Aç/Kapat"
      >
        {isMobileOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div 
          className="health-sidebar-overlay show"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`health-sidebar ${isCompact ? 'compact' : ''} ${isMobileOpen ? 'open' : ''}`}>
        {/* Sidebar Header */}
        <div className="health-sidebar-header">
          <div className="health-sidebar-brand">
            <Shield size={24} />
            {!isCompact && <span>HVS</span>}
          </div>
        </div>

        {/* Navigation */}
        <nav className="health-sidebar-nav">
          {navigationItems.map((section, sectionIndex) => (
            <div key={sectionIndex} className="health-nav-section">
              {!isCompact && (
                <div className="health-nav-section-title">
                  {section.section}
                </div>
              )}
              
              {section.items.map((item) => {
                const IconComponent = item.icon;
                return (
                  <div key={item.id} className="health-nav-item">
                    <button
                      className={`health-nav-link ${activeTab === item.id ? 'active' : ''}`}
                      onClick={() => handleTabChange(item.id)}
                      title={isCompact ? item.label : ''}
                    >
                      <IconComponent size={20} className="health-nav-icon" />
                      {!isCompact && (
                        <span className="health-nav-text">{item.label}</span>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          ))}
        </nav>

        {/* Sidebar Footer */}
        <div className="health-sidebar-footer">
          <div className="health-user-info">
            <div className="health-user-avatar">
              <User size={16} />
            </div>
            {!isCompact && (
              <div className="health-user-details">
                <h6>{user?.name || 'Doktor'}</h6>
                <small>Sağlık Personeli</small>
              </div>
            )}
          </div>
          
          {!isCompact && (
            <div className="mt-2">
              <button
                className="health-btn health-btn-sm health-btn-danger w-100"
                onClick={onLogout}
              >
                <LogOut size={14} />
                Çıkış Yap
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Sidebar;
