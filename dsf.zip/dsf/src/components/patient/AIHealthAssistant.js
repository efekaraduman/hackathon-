import React, { useState, useEffect } from 'react';
import { Card, Button, Badge, Alert, Spinner } from 'react-bootstrap';
import { 
  Brain, 
  Pill, 
  Heart, 
  Calendar, 
  AlertTriangle, 
  CheckCircle, 
  Lightbulb,
  TrendingUp,
  Clock,
  Shield,
  Activity
} from 'lucide-react';

const AIHealthAssistant = ({ patient, complaints = [] }) => {
  const [aiRecommendations, setAiRecommendations] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);

  useEffect(() => {
    if (patient) {
      generateAIRecommendations();
    }
  }, [patient, complaints]);

  const generateAIRecommendations = async () => {
    setIsLoading(true);
    
    // Simüle edilmiş AI analizi - gerçek uygulamada API çağrısı yapılabilir
    setTimeout(() => {
      const recommendations = analyzePatientData(patient, complaints);
      setAiRecommendations(recommendations);
      setLastUpdated(new Date());
      setIsLoading(false);
    }, 1500);
  };

  const analyzePatientData = (patient, complaints) => {
    const recommendations = [];
    
    // İlaç analizi
    if (patient.medications && patient.medications.length > 0) {
      const activeMedications = patient.medications.filter(med => med.status === 'active');
      
      if (activeMedications.length > 0) {
        recommendations.push({
          id: 'medication-reminder',
          type: 'medication',
          priority: 'high',
          title: 'İlaç Hatırlatıcısı',
          description: `${activeMedications.length} aktif ilacınız var. Düzenli kullanım çok önemli.`,
          icon: Pill,
          color: 'primary',
          suggestions: [
            'İlaçlarınızı her gün aynı saatte alın',
            'Doktorunuzla görüşmeden dozajı değiştirmeyin',
            'Yan etkiler fark ederseniz hemen doktorunuza başvurun'
          ]
        });

        // İlaç etkileşim kontrolü
        const highRiskMeds = activeMedications.filter(med => 
          med.activeSubstance.toLowerCase().includes('warfarin') ||
          med.activeSubstance.toLowerCase().includes('digoxin') ||
          med.activeSubstance.toLowerCase().includes('insulin')
        );

        if (highRiskMeds.length > 1) {
          recommendations.push({
            id: 'drug-interaction',
            type: 'warning',
            priority: 'high',
            title: 'İlaç Etkileşim Uyarısı',
            description: 'Yüksek riskli ilaçlar kullanıyorsunuz. Dikkatli olun.',
            icon: AlertTriangle,
            color: 'warning',
            suggestions: [
              'Doktorunuzla düzenli görüşme yapın',
              'Yeni ilaç almadan önce eczacınıza danışın',
              'Kan tahlillerinizi düzenli yaptırın'
            ]
          });
        }
      }
    }

    // Kronik hastalık analizi
    if (patient.chronicDiseases && patient.chronicDiseases.length > 0) {
      patient.chronicDiseases.forEach(disease => {
        if (disease === 'Diyabet') {
          recommendations.push({
            id: 'diabetes-care',
            type: 'disease',
            priority: 'high',
            title: 'Diyabet Bakımı',
            description: 'Diyabet yönetimi için önemli öneriler.',
            icon: Heart,
            color: 'danger',
            suggestions: [
              'Kan şekerinizi düzenli ölçün',
              'Düzenli egzersiz yapın',
              'Beslenme planınıza uyun',
              'Ayak bakımınızı ihmal etmeyin'
            ]
          });
        } else if (disease === 'Hipertansiyon') {
          recommendations.push({
            id: 'hypertension-care',
            type: 'disease',
            priority: 'high',
            title: 'Hipertansiyon Yönetimi',
            description: 'Tansiyon kontrolü için öneriler.',
            icon: Activity,
            color: 'info',
            suggestions: [
              'Tansiyonunuzu düzenli ölçün',
              'Tuz tüketimini azaltın',
              'Stres yönetimi yapın',
              'Düzenli yürüyüş yapın'
            ]
          });
        }
      });
    }

    // Randevu analizi
    if (patient.appointments && patient.appointments.length > 0) {
      const upcomingAppointments = patient.appointments.filter(apt => 
        new Date(apt.date) > new Date()
      );

      if (upcomingAppointments.length > 0) {
        recommendations.push({
          id: 'appointment-reminder',
          type: 'appointment',
          priority: 'medium',
          title: 'Yaklaşan Randevular',
          description: `${upcomingAppointments.length} randevunuz var. Hazırlık yapın.`,
          icon: Calendar,
          color: 'success',
          suggestions: [
            'Randevu saatinden 15 dakika önce hazır olun',
            'Gerekli belgeleri yanınızda bulundurun',
            'Sorularınızı önceden hazırlayın',
            'İlaç listesini güncelleyin'
          ]
        });
      }
    }

    // Şikayet analizi
    if (complaints && complaints.length > 0) {
      const recentComplaints = complaints.filter(complaint => 
        new Date(complaint.date) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      );

      if (recentComplaints.length > 0) {
        recommendations.push({
          id: 'complaint-followup',
          type: 'complaint',
          priority: 'medium',
          title: 'Son Şikayetleriniz',
          description: 'Son 7 günde bildirdiğiniz şikayetler takip ediliyor.',
          icon: AlertTriangle,
          color: 'warning',
          suggestions: [
            'Şikayetlerinizin seyrini takip edin',
            'Kötüleşme durumunda acil servise başvurun',
            'Doktorunuzla durumu paylaşın',
            'Belirtileri not alın'
          ]
        });
      }
    }

    // Genel sağlık önerileri
    recommendations.push({
      id: 'general-health',
      type: 'general',
      priority: 'low',
      title: 'Genel Sağlık Önerileri',
      description: 'Sağlıklı yaşam için genel öneriler.',
      icon: Shield,
      color: 'info',
      suggestions: [
        'Günde en az 8 bardak su için',
        'Düzenli uyku uyuyun (7-8 saat)',
        'Stres yönetimi yapın',
        'Düzenli check-up yaptırın'
      ]
    });

    return recommendations.sort((a, b) => {
      const priorityOrder = { high: 3, medium: 2, low: 1 };
      return priorityOrder[b.priority] - priorityOrder[a.priority];
    });
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'danger';
      case 'medium': return 'warning';
      case 'low': return 'info';
      default: return 'secondary';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'medication': return Pill;
      case 'disease': return Heart;
      case 'appointment': return Calendar;
      case 'complaint': return AlertTriangle;
      case 'warning': return AlertTriangle;
      case 'general': return Shield;
      default: return Lightbulb;
    }
  };

  if (!patient) {
    return (
      <Card className="h-100">
        <Card.Body className="text-center">
          <Brain size={48} className="text-muted mb-3" />
          <h5>AI Sağlık Asistanı</h5>
          <p className="text-muted">Hasta seçildiğinde öneriler görüntülenecek</p>
        </Card.Body>
      </Card>
    );
  }

  return (
    <Card className="h-100">
      <Card.Header className="bg-gradient-primary text-white">
        <div className="d-flex align-items-center">
          <Brain size={20} className="me-2" />
          <h6 className="mb-0">AI Sağlık Asistanı</h6>
          {lastUpdated && (
            <small className="ms-auto">
              <Clock size={14} className="me-1" />
              {lastUpdated.toLocaleTimeString('tr-TR')}
            </small>
          )}
        </div>
      </Card.Header>
      
      <Card.Body className="p-0">
        {isLoading ? (
          <div className="text-center py-5">
            <Spinner animation="border" variant="primary" className="mb-3" />
            <p className="text-muted">AI analizi yapılıyor...</p>
          </div>
        ) : (
          <div className="ai-recommendations-container">
            {aiRecommendations.length === 0 ? (
              <div className="text-center py-4">
                <CheckCircle size={48} className="text-success mb-3" />
                <h6>Mükemmel!</h6>
                <p className="text-muted">Şu anda özel bir önerimiz yok</p>
              </div>
            ) : (
              aiRecommendations.map((recommendation, index) => {
                const IconComponent = getTypeIcon(recommendation.type);
                
                return (
                  <div key={recommendation.id} className="ai-recommendation-item">
                    <div className="recommendation-header">
                      <div className="recommendation-icon">
                        <IconComponent size={20} />
                      </div>
                      <div className="recommendation-content">
                        <div className="d-flex align-items-center justify-content-between">
                          <h6 className="mb-1">{recommendation.title}</h6>
                          <Badge bg={getPriorityColor(recommendation.priority)}>
                            {recommendation.priority === 'high' ? 'Yüksek' : 
                             recommendation.priority === 'medium' ? 'Orta' : 'Düşük'}
                          </Badge>
                        </div>
                        <p className="text-muted mb-2">{recommendation.description}</p>
                      </div>
                    </div>
                    
                    <div className="recommendation-suggestions">
                      <h6 className="suggestion-title">
                        <Lightbulb size={16} className="me-1" />
                        Önerilerim:
                      </h6>
                      <ul className="suggestion-list">
                        {recommendation.suggestions.map((suggestion, idx) => (
                          <li key={idx} className="suggestion-item">
                            <CheckCircle size={14} className="me-2 text-success" />
                            {suggestion}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}
      </Card.Body>
      
      <Card.Footer className="bg-light">
        <Button 
          variant="outline-primary" 
          size="sm" 
          onClick={generateAIRecommendations}
          disabled={isLoading}
          className="w-100"
        >
          <TrendingUp size={16} className="me-1" />
          Analizi Yenile
        </Button>
      </Card.Footer>
    </Card>
  );
};

export default AIHealthAssistant;
