import React, { useState } from 'react';
import { Modal, Button, Form, Row, Col, Alert, Card } from 'react-bootstrap';
import { MessageSquare, Save, X, AlertTriangle, Clock, Heart } from 'lucide-react';

const ComplaintForm = ({ show, onHide, patient, onSubmit }) => {
  const [formData, setFormData] = useState({
    complaintType: '',
    severity: '',
    duration: '',
    symptoms: '',
    description: '',
    additionalNotes: '',
    emergency: false
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const complaintTypes = [
    'Ağrı',
    'Ateş',
    'Nefes Darlığı',
    'Baş Ağrısı',
    'Mide Bulantısı',
    'Kusma',
    'İshal',
    'Kabızlık',
    'Uyku Problemi',
    'Yorgunluk',
    'Halsizlik',
    'Döküntü',
    'Kaşıntı',
    'Öksürük',
    'Boğaz Ağrısı',
    'Göğüs Ağrısı',
    'Karın Ağrısı',
    'Eklem Ağrısı',
    'Diğer'
  ];

  const severityLevels = [
    { value: 'mild', label: 'Hafif', color: '#10b981', icon: '😊' },
    { value: 'moderate', label: 'Orta', color: '#f59e0b', icon: '😐' },
    { value: 'severe', label: 'Şiddetli', color: '#ef4444', icon: '😰' },
    { value: 'critical', label: 'Kritik', color: '#dc2626', icon: '🚨' }
  ];

  const durationOptions = [
    'Son 1 saat',
    'Son 6 saat',
    'Son 24 saat',
    '2-3 gün',
    '1 hafta',
    '2-4 hafta',
    '1-3 ay',
    '3+ ay'
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Hata varsa temizle
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.complaintType) {
      newErrors.complaintType = 'Şikayet türü seçiniz';
    }
    
    if (!formData.severity) {
      newErrors.severity = 'Şiddet seviyesi seçiniz';
    }
    
    if (!formData.duration) {
      newErrors.duration = 'Süre seçiniz';
    }
    
    if (!formData.description.trim()) {
      newErrors.description = 'Şikayet açıklaması zorunludur';
    } else if (formData.description.trim().length < 10) {
      newErrors.description = 'Açıklama en az 10 karakter olmalıdır';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const complaintData = {
        id: `C${Date.now()}`,
        patientId: patient.id,
        patientName: `${patient.name} ${patient.surname}`,
        timestamp: new Date().toISOString(),
        ...formData,
        description: formData.description.trim(),
        additionalNotes: formData.additionalNotes.trim(),
        status: 'pending'
      };
      
      await onSubmit(complaintData);
      
      // Form'u temizle
      setFormData({
        complaintType: '',
        severity: '',
        duration: '',
        symptoms: '',
        description: '',
        additionalNotes: '',
        emergency: false
      });
      setErrors({});
      onHide();
    } catch (error) {
      console.error('Şikayet gönderilirken hata:', error);
      alert('Şikayetiniz gönderilirken bir hata oluştu. Lütfen tekrar deneyin.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    if (!isSubmitting) {
      setFormData({
        complaintType: '',
        severity: '',
        duration: '',
        symptoms: '',
        description: '',
        additionalNotes: '',
        emergency: false
      });
      setErrors({});
      onHide();
    }
  };

  const getSeverityStyle = (severity) => {
    const level = severityLevels.find(s => s.value === severity);
    return level ? { color: level.color, fontWeight: 'bold' } : {};
  };

  return (
    <Modal show={show} onHide={handleClose} size="lg" centered backdrop="static" keyboard={!isSubmitting}>
      <Modal.Header closeButton className="bg-primary text-white">
        <Modal.Title>
          <MessageSquare size={20} style={{ marginRight: '8px' }} />
          Randevu Öncesi Şikayet Bildirimi
        </Modal.Title>
      </Modal.Header>
      
      <Modal.Body>
        <Alert variant="info" className="mb-4">
          <strong>Bilgi:</strong> Randevunuzdan önce şikayetlerinizi bildirmeniz, doktorunuzun size daha iyi yardımcı olmasını sağlar. 
          Acil durumlar için lütfen hastaneyi arayın.
        </Alert>
        
        <Form onSubmit={handleSubmit}>
          {/* Acil Durum Uyarısı */}
          {formData.emergency && (
            <Alert variant="danger" className="mb-3">
              <AlertTriangle size={16} style={{ marginRight: '8px' }} />
              <strong>Acil Durum!</strong> Kritik şikayetler için lütfen derhal hastaneyi arayın: 112
            </Alert>
          )}
          
          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>
                  <strong>Şikayet Türü *</strong>
                </Form.Label>
                <Form.Select
                  value={formData.complaintType}
                  onChange={(e) => handleInputChange('complaintType', e.target.value)}
                  isInvalid={!!errors.complaintType}
                >
                  <option value="">Seçiniz</option>
                  {complaintTypes.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </Form.Select>
                <Form.Control.Feedback type="invalid">
                  {errors.complaintType}
                </Form.Control.Feedback>
              </Form.Group>
            </Col>
            
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>
                  <strong>Şiddet Seviyesi *</strong>
                </Form.Label>
                <Form.Select
                  value={formData.severity}
                  onChange={(e) => handleInputChange('severity', e.target.value)}
                  isInvalid={!!errors.severity}
                >
                  <option value="">Seçiniz</option>
                  {severityLevels.map(level => (
                    <option key={level.value} value={level.value}>
                      {level.icon} {level.label}
                    </option>
                  ))}
                </Form.Select>
                <Form.Control.Feedback type="invalid">
                  {errors.severity}
                </Form.Control.Feedback>
              </Form.Group>
            </Col>
          </Row>
          
          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>
                  <Clock size={16} style={{ marginRight: '4px' }} />
                  <strong>Süre *</strong>
                </Form.Label>
                <Form.Select
                  value={formData.duration}
                  onChange={(e) => handleInputChange('duration', e.target.value)}
                  isInvalid={!!errors.duration}
                >
                  <option value="">Seçiniz</option>
                  {durationOptions.map(duration => (
                    <option key={duration} value={duration}>{duration}</option>
                  ))}
                </Form.Select>
                <Form.Control.Feedback type="invalid">
                  {errors.duration}
                </Form.Control.Feedback>
              </Form.Group>
            </Col>
            
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>
                  <strong>Belirtiler</strong>
                </Form.Label>
                <Form.Control
                  type="text"
                  value={formData.symptoms}
                  onChange={(e) => handleInputChange('symptoms', e.target.value)}
                  placeholder="Ateş, titreme, terleme vb."
                />
                <Form.Text className="text-muted">
                  Virgülle ayırarak birden fazla belirti yazabilirsiniz
                </Form.Text>
              </Form.Group>
            </Col>
          </Row>
          
          <Form.Group className="mb-3">
            <Form.Label>
              <strong>Şikayet Açıklaması *</strong>
            </Form.Label>
            <Form.Control
              as="textarea"
              rows={4}
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              isInvalid={!!errors.description}
              placeholder="Şikayetinizi detaylı olarak açıklayın. Ne zaman başladı, nasıl hissediyorsunuz, hangi durumlarda artıyor/azalıyor?"
            />
            <Form.Control.Feedback type="invalid">
              {errors.description}
            </Form.Control.Feedback>
            <Form.Text className="text-muted">
              En az 10 karakter, maksimum 500 karakter
            </Form.Text>
          </Form.Group>
          
          <Form.Group className="mb-3">
            <Form.Label>
              <strong>Ek Notlar</strong>
            </Form.Label>
            <Form.Control
              as="textarea"
              rows={2}
              value={formData.additionalNotes}
              onChange={(e) => handleInputChange('additionalNotes', e.target.value)}
              placeholder="Doktorunuzun bilmesi gereken başka bir şey var mı? (İlaç kullanımı, alerjiler, geçmiş hastalıklar vb.)"
            />
          </Form.Group>
          
          <Form.Group className="mb-3">
            <Form.Check
              type="checkbox"
              label="Bu acil bir durum mu? (Kritik şikayetler için)"
              checked={formData.emergency}
              onChange={(e) => handleInputChange('emergency', e.target.checked)}
            />
          </Form.Group>
          
          {/* Özet Kartı */}
          {formData.complaintType && formData.severity && formData.duration && (
            <Card className="mt-3" style={{ backgroundColor: '#f8f9fa' }}>
              <Card.Header>
                <strong>Şikayet Özeti</strong>
              </Card.Header>
              <Card.Body>
                <Row>
                  <Col md={4}>
                    <strong>Tür:</strong> {formData.complaintType}
                  </Col>
                  <Col md={4}>
                    <strong>Şiddet:</strong> 
                    <span style={getSeverityStyle(formData.severity)}>
                      {severityLevels.find(s => s.value === formData.severity)?.label}
                    </span>
                  </Col>
                  <Col md={4}>
                    <strong>Süre:</strong> {formData.duration}
                  </Col>
                </Row>
                {formData.symptoms && (
                  <Row className="mt-2">
                    <Col>
                      <strong>Belirtiler:</strong> {formData.symptoms}
                    </Col>
                  </Row>
                )}
                {formData.emergency && (
                  <Row className="mt-2">
                    <Col>
                      <Alert variant="danger" className="mb-0 py-2">
                        <AlertTriangle size={16} style={{ marginRight: '8px' }} />
                        <strong>Acil Durum İşaretlendi!</strong>
                      </Alert>
                    </Col>
                  </Row>
                )}
              </Card.Body>
            </Card>
          )}
        </Form>
      </Modal.Body>
      
      <Modal.Footer>
        <Button 
          variant="secondary" 
          onClick={handleClose}
          disabled={isSubmitting}
        >
          <X size={16} style={{ marginRight: '4px' }} />
          İptal
        </Button>
        <Button 
          variant="primary" 
          type="submit"
          onClick={handleSubmit}
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <>
              <div className="spinner-border spinner-border-sm me-2" role="status">
                <span className="visually-hidden">Gönderiliyor...</span>
              </div>
              Gönderiliyor...
            </>
          ) : (
            <>
              <Save size={16} style={{ marginRight: '4px' }} />
              Şikayeti Gönder
            </>
          )}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default ComplaintForm;
