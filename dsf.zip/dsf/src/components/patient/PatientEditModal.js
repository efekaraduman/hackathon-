import React, { useState, useEffect } from 'react';
import { Modal, Button, Form, Row, Col, Alert } from 'react-bootstrap';
import { User, Phone, MapPin, Save, X } from 'lucide-react';

const PatientEditModal = ({ show, onHide, patient, onSave }) => {
  const [formData, setFormData] = useState({
    name: '',
    surname: '',
    phone: '',
    address: '',
    email: ''
  });
  const [errors, setErrors] = useState({});
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (patient) {
      setFormData({
        name: patient.name || '',
        surname: patient.surname || '',
        phone: patient.phone || '',
        address: patient.address || '',
        email: patient.email || ''
      });
      setErrors({});
    }
  }, [patient]);

  // ESC tuşu ile modal kapatma
  useEffect(() => {
    const handleEscape = (event) => {
      if (event.key === 'Escape' && show && !isSaving) {
        handleClose();
      }
    };

    if (show) {
      document.addEventListener('keydown', handleEscape);
      return () => document.removeEventListener('keydown', handleEscape);
    }
  }, [show, isSaving]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Hata varsa temizle
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Ad alanı zorunludur';
    }
    
    if (!formData.surname.trim()) {
      newErrors.surname = 'Soyad alanı zorunludur';
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Telefon alanı zorunludur';
    } else if (!/^[0-9\s\-\+\(\)]+$/.test(formData.phone)) {
      newErrors.phone = 'Geçerli bir telefon numarası giriniz';
    }
    
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Geçerli bir e-posta adresi giriniz';
    }
    
    if (!formData.address.trim()) {
      newErrors.address = 'Adres alanı zorunludur';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) {
      return;
    }
    
    setIsSaving(true);
    
    try {
      const updatedPatient = {
        ...patient,
        name: formData.name.trim(),
        surname: formData.surname.trim(),
        phone: formData.phone.trim(),
        address: formData.address.trim(),
        email: formData.email.trim()
      };
      
      await onSave(updatedPatient);
      
      // Modal'ı kapat ve state'leri temizle
      setErrors({});
      setFormData({
        name: '',
        surname: '',
        phone: '',
        address: '',
        email: ''
      });
      onHide();
    } catch (error) {
      console.error('Bilgi güncellenirken hata oluştu:', error);
      alert('Bilgileriniz güncellenirken bir hata oluştu. Lütfen tekrar deneyin.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleClose = () => {
    if (!isSaving) {
      setErrors({});
      setFormData({
        name: '',
        surname: '',
        phone: '',
        address: '',
        email: ''
      });
      onHide();
    }
  };

  return (
    <Modal 
      show={show} 
      onHide={handleClose} 
      size="lg" 
      centered
      backdrop="static"
      keyboard={!isSaving}
    >
      <Modal.Header closeButton className="bg-primary text-white">
        <Modal.Title>
          <User size={20} style={{ marginRight: '8px' }} />
          Kişisel Bilgilerimi Düzenle
        </Modal.Title>
      </Modal.Header>
      
      <Modal.Body>
        <Alert variant="info" className="mb-4">
          <strong>Bilgi:</strong> Sadece kişisel iletişim bilgilerinizi güncelleyebilirsiniz. 
          Tıbbi bilgileriniz için doktorunuzla iletişime geçin.
        </Alert>
        
        <Form>
          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>
                  <strong>Ad *</strong>
                </Form.Label>
                <Form.Control
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  isInvalid={!!errors.name}
                  placeholder="Adınızı giriniz"
                />
                <Form.Control.Feedback type="invalid">
                  {errors.name}
                </Form.Control.Feedback>
              </Form.Group>
            </Col>
            
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>
                  <strong>Soyad *</strong>
                </Form.Label>
                <Form.Control
                  type="text"
                  value={formData.surname}
                  onChange={(e) => handleInputChange('surname', e.target.value)}
                  isInvalid={!!errors.surname}
                  placeholder="Soyadınızı giriniz"
                />
                <Form.Control.Feedback type="invalid">
                  {errors.surname}
                </Form.Control.Feedback>
              </Form.Group>
            </Col>
          </Row>
          
          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>
                  <Phone size={16} style={{ marginRight: '4px' }} />
                  <strong>Telefon *</strong>
                </Form.Label>
                <Form.Control
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  isInvalid={!!errors.phone}
                  placeholder="0532 123 45 67"
                />
                <Form.Control.Feedback type="invalid">
                  {errors.phone}
                </Form.Control.Feedback>
              </Form.Group>
            </Col>
            
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>
                  <strong>E-posta</strong>
                </Form.Label>
                <Form.Control
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  isInvalid={!!errors.email}
                  placeholder="ornek@email.com"
                />
                <Form.Control.Feedback type="invalid">
                  {errors.email}
                </Form.Control.Feedback>
                <Form.Text className="text-muted">
                  İsteğe bağlı - Bilgilendirme mesajları için
                </Form.Text>
              </Form.Group>
            </Col>
          </Row>
          
          <Form.Group className="mb-3">
            <Form.Label>
              <MapPin size={16} style={{ marginRight: '4px' }} />
              <strong>Adres *</strong>
            </Form.Label>
            <Form.Control
              as="textarea"
              rows={3}
              value={formData.address}
              onChange={(e) => handleInputChange('address', e.target.value)}
              isInvalid={!!errors.address}
              placeholder="Tam adresinizi giriniz (İl, İlçe, Mahalle, Sokak, No)"
            />
            <Form.Control.Feedback type="invalid">
              {errors.address}
            </Form.Control.Feedback>
          </Form.Group>
          
          {/* Düzenlenemez Bilgiler */}
          <Alert variant="light" className="mt-4">
            <h6 className="mb-2">Düzenlenemez Bilgiler:</h6>
            <Row>
              <Col md={6}>
                <small><strong>TC Kimlik No:</strong> {patient?.tcNo || 'N/A'}</small>
              </Col>
              <Col md={6}>
                <small><strong>Yaş:</strong> {patient?.age || 'N/A'}</small>
              </Col>
              <Col md={6}>
                <small><strong>Cinsiyet:</strong> {patient?.gender || 'N/A'}</small>
              </Col>
              <Col md={6}>
                <small><strong>Hasta No:</strong> {patient?.id || 'N/A'}</small>
              </Col>
            </Row>
            <small className="text-muted mt-2 d-block">
              Bu bilgileri değiştirmek için hastane bilgi işlem birimine başvurun.
            </small>
          </Alert>
        </Form>
      </Modal.Body>
      
      <Modal.Footer>
        <Button 
          variant="secondary" 
          onClick={handleClose}
          disabled={isSaving}
        >
          <X size={16} style={{ marginRight: '4px' }} />
          İptal
        </Button>
        <Button 
          variant="primary" 
          onClick={handleSave}
          disabled={isSaving}
        >
          {isSaving ? (
            <>
              <div className="spinner-border spinner-border-sm me-2" role="status">
                <span className="visually-hidden">Kaydediliyor...</span>
              </div>
              Kaydediliyor...
            </>
          ) : (
            <>
              <Save size={16} style={{ marginRight: '4px' }} />
              Kaydet
            </>
          )}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default PatientEditModal;
