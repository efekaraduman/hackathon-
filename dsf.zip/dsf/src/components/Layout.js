import React from 'react';
import { Navbar, Nav, Container } from 'react-bootstrap';
import { LogOut, User, Stethoscope, Activity } from 'lucide-react';

const Layout = ({ children, user, onLogout }) => {
  return (
    <>
      <Navbar expand="lg" className="minimal-navbar">
        <Container>
          <Navbar.Brand href="#" className="minimal-navbar-brand">
            <Activity size={24} style={{ marginRight: '10px' }} />
            Hasta Veri Yönetim Sistemi
          </Navbar.Brand>
          
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link href="/">
                <Stethoscope size={18} style={{ marginRight: '5px' }} />
                Ana Sayfa
              </Nav.Link>
            </Nav>
            
            <Nav>
              <Nav.Link href="#" style={{ color: '#6b7280', pointerEvents: 'none' }}>
                <User size={18} style={{ marginRight: '5px' }} />
                {user.name} {user.title && `• ${user.title}`}
              </Nav.Link>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  onLogout();
                }}
                style={{ 
                  color: '#ef4444',
                  fontWeight: '500',
                  border: '1px solid #ef4444',
                  borderRadius: '6px',
                  padding: '8px 16px',
                  margin: '0 0 0 8px',
                  transition: 'all 0.2s ease',
                  display: 'flex',
                  alignItems: 'center',
                  textDecoration: 'none',
                  backgroundColor: 'transparent',
                  cursor: 'pointer',
                  fontSize: '14px',
                  gap: '6px'
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#ef4444';
                  e.target.style.color = '#ffffff';
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = 'transparent';
                  e.target.style.color = '#ef4444';
                }}
              >
                <LogOut size={16} />
                Çıkış Yap
              </button>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      <div className="main-container">
        <Container fluid>
          {children}
        </Container>
      </div>
    </>
  );
};

export default Layout;
