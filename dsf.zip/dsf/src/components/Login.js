import React, { useState } from 'react';
import { User, Shield, Stethoscope, Settings } from 'lucide-react';

const Login = ({ onLogin }) => {
  const [selectedRole, setSelectedRole] = useState('doctor');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showManagerLogin, setShowManagerLogin] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Demo için basit giriş kontrolü
    if (username && password) {
      let user;
      // Yönetici giriş modundaysa, role'u manager yap
      if (showManagerLogin) {
        user = {
          id: 'M001',
          name: 'Ayşe Demir',
          role: 'manager',
          username: username,
          title: 'Hastane Yöneticisi'
        };
        console.log('Yönetici girişi:', user);
      } else if (selectedRole === 'doctor') {
        user = {
          id: 'D001',
          name: 'Dr. Mehmet Kaya',
          role: 'doctor',
          username: username
        };
        console.log('Doktor girişi:', user);
      } else if (selectedRole === 'patient') {
        user = {
          id: 'P001',
          name: 'Ahmet',
          role: 'patient',
          username: username
        };
        console.log('Hasta girişi:', user);
      }
      
      // localStorage'u temizle ve yeni user'ı kaydet
      localStorage.removeItem('user');
      onLogin(user);
    } else {
      alert('Lütfen kullanıcı adı ve şifre giriniz.');
    }
  };

  const handleManagerLogin = () => {
    setShowManagerLogin(true);
    setUsername('');
    setPassword('');
  };

  const handleBackToNormal = () => {
    setShowManagerLogin(false);
    setSelectedRole('doctor');
    setUsername('');
    setPassword('');
  };

  return (
    <div className="minimal-login-container">
      <div className="minimal-login-card">
        <div className="minimal-login-header">
          <h2 className="minimal-login-title">🏥 Hasta Veri Yönetim Sistemi</h2>
          <p className="minimal-login-subtitle">AI Destekli Hasta Takip Platformu</p>
        </div>

        <div className="minimal-login-body">
          {!showManagerLogin && (
            <div className="role-selector" style={{ display: 'flex', gap: '12px', marginBottom: '24px' }}>
              <div 
                className={`minimal-btn ${selectedRole === 'doctor' ? 'minimal-btn-primary' : 'minimal-btn-secondary'}`}
                onClick={() => setSelectedRole('doctor')}
                style={{ flex: 1 }}
              >
                <Stethoscope size={20} />
                <div>Doktor</div>
              </div>
              <div 
                className={`minimal-btn ${selectedRole === 'patient' ? 'minimal-btn-primary' : 'minimal-btn-secondary'}`}
                onClick={() => setSelectedRole('patient')}
                style={{ flex: 1 }}
              >
                <User size={20} />
                <div>Hasta</div>
              </div>
            </div>
          )}

          {showManagerLogin && (
            <div style={{ marginBottom: '24px', textAlign: 'center' }}>
              <div style={{ 
                backgroundColor: '#f3f4f6', 
                padding: '16px', 
                borderRadius: '8px',
                marginBottom: '16px'
              }}>
                <Settings size={24} style={{ color: '#6b7280', marginBottom: '8px' }} />
                <h4 style={{ margin: '0', color: '#374151', fontSize: '16px', fontWeight: '600' }}>
                  Hastane Yöneticisi Girişi
                </h4>
                <p style={{ margin: '4px 0 0 0', color: '#6b7280', fontSize: '14px' }}>
                  Yönetici hesabınızla giriş yapın
                </p>
              </div>
              <button 
                type="button"
                className="minimal-btn minimal-btn-secondary"
                onClick={handleBackToNormal}
                style={{ fontSize: '14px' }}
              >
                ← Normal Girişe Dön
              </button>
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div className="minimal-form-group">
              <label htmlFor="username" className="minimal-label">
                Kullanıcı Adı
              </label>
              <input
                type="text"
                className="minimal-input"
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Kullanıcı adınızı giriniz"
                required
              />
            </div>

            <div className="minimal-form-group">
              <label htmlFor="password" className="minimal-label">
                Şifre
              </label>
              <input
                type="password"
                className="minimal-input"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Şifrenizi giriniz"
                required
              />
            </div>

            <button type="submit" className="minimal-btn minimal-btn-primary" style={{ width: '100%' }}>
              <Shield size={20} />
              Giriş Yap
            </button>
          </form>

          {/* Yönetici Girişi */}
          {!showManagerLogin && (
            <div style={{ marginTop: '20px', paddingTop: '20px', borderTop: '1px solid #e2e8f0' }}>
              <button 
                type="button"
                className="minimal-btn minimal-btn-secondary" 
                style={{ width: '100%' }}
                onClick={handleManagerLogin}
              >
                <Settings size={20} />
                Hastane Yöneticisi Girişi
              </button>
            </div>
          )}

          <div className="mt-4 text-center">
            <small style={{ color: '#64748b' }}>
              Demo için herhangi bir kullanıcı adı ve şifre girebilirsiniz
            </small>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;