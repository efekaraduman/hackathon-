import React, { useState, useEffect } from 'react';
import { Row, Col, Container, Button, Modal } from 'react-bootstrap';
import Sidebar from './Sidebar';
import PatientList from './doctor/PatientList';
import PatientDetails from './doctor/PatientDetails';
import AdvancedAIPanel from './doctor/AdvancedAIPanel';
import PatientSummaryCard from './doctor/PatientSummaryCard';
import ReconciledMedicationList from './doctor/ReconciledMedicationList';
import AdvancedTimeline from './doctor/AdvancedTimeline';
import AuditLogPanel from './doctor/AuditLogPanel';
import KPIDashboard from './doctor/KPIDashboard';
import ConsentPanel from './ConsentPanel';
import AppointmentScheduling from './doctor/AppointmentScheduling';
import PrescriptionManagement from './doctor/PrescriptionManagement';
import LabResultsIntegration from './doctor/LabResultsIntegration';
import DashboardAnalytics from './doctor/DashboardAnalytics';
import { generateAISummary, analyzeDrugInteractions } from '../utils/aiAnalysis';
import auditLogger from '../utils/auditLog';
import { Target, FileText, Activity, Calendar, Pill, Activity as ActivityIcon, BarChart3, Users, Home } from 'lucide-react';

const DoctorPanel = ({ patients, setPatients, onLogout, user }) => {
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredPatients, setFilteredPatients] = useState(patients);
  const [selectedDiseases, setSelectedDiseases] = useState([]);
  const [aiSummary, setAiSummary] = useState(null);
  const [drugInteractions, setDrugInteractions] = useState([]);
  const [showAuditLog, setShowAuditLog] = useState(false);
  const [showKPIDashboard, setShowKPIDashboard] = useState(false);
  const [showConsentPanel, setShowConsentPanel] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  // Tüm hastalıkları topla
  const allDiseases = [...new Set(patients.flatMap(patient => patient.chronicDiseases))];

  useEffect(() => {
    setFilteredPatients(patients);
  }, [patients]);

  useEffect(() => {
    // Arama ve filtreleme
    let filtered = patients;

    // Arama filtresi
    if (searchTerm) {
      filtered = filtered.filter(patient =>
        `${patient.name} ${patient.surname}`.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Hastalık filtresi
    if (selectedDiseases.length > 0) {
      filtered = filtered.filter(patient =>
        selectedDiseases.some(disease => patient.chronicDiseases.includes(disease))
      );
    }

    setFilteredPatients(filtered);
  }, [patients, searchTerm, selectedDiseases]);

  useEffect(() => {
    if (selectedPatient) {
      // AI özet oluştur
      const summary = generateAISummary(selectedPatient);
      setAiSummary(summary);

      // İlaç etkileşimlerini analiz et
      const interactions = analyzeDrugInteractions(selectedPatient.medications);
      setDrugInteractions(interactions);
    }
  }, [selectedPatient]);

  const handlePatientSelect = (patient) => {
    setSelectedPatient(patient);
  };

  const handleDiseaseFilter = (disease) => {
    if (selectedDiseases.includes(disease)) {
      setSelectedDiseases(selectedDiseases.filter(d => d !== disease));
    } else {
      setSelectedDiseases([...selectedDiseases, disease]);
    }
  };

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedDiseases([]);
  };

  const handleApprovalChange = (approvalData) => {
    if (selectedPatient && approvalData) {
      auditLogger.logApprovalChange(
        selectedPatient.id, 
        approvalData.action || approvalData.type, 
        approvalData.confidence || 0, 
        approvalData.feedback || ''
      );
    }
  };

  const handleMedicationUpdate = (medicationId, newData) => {
    if (selectedPatient) {
      const oldMedication = selectedPatient.medications.find(med => med.id === medicationId);
      if (oldMedication) {
        auditLogger.logMedicationChange(selectedPatient.id, medicationId, oldMedication, newData);
        
        // Hasta verilerini güncelle
        const updatedPatients = patients.map(patient => {
          if (patient.id === selectedPatient.id) {
            return {
              ...patient,
              medications: patient.medications.map(med => 
                med.id === medicationId ? { ...med, ...newData } : med
              )
            };
          }
          return patient;
        });
        setPatients(updatedPatients);
        setSelectedPatient(updatedPatients.find(p => p.id === selectedPatient.id));
      }
    }
  };

  const getPageTitle = () => {
    switch (activeTab) {
      case 'overview': return 'Genel Bakış';
      case 'patients': return 'Hasta Listesi';
      case 'appointments': return 'Randevu Yönetimi';
      case 'prescriptions': return 'Reçete Yönetimi';
      case 'lab': return 'Lab Sonuçları';
      case 'analytics': return 'Dashboard & Analitik';
      default: return 'Hasta Veri Yönetim Sistemi';
    }
  };

  const getBreadcrumb = () => {
    const breadcrumbs = [
      { label: 'Ana Sayfa', icon: Home }
    ];
    
    if (activeTab !== 'overview') {
      breadcrumbs.push({ label: getPageTitle() });
    }
    
    return breadcrumbs;
  };

  return (
    <>
      {/* Sidebar */}
      <Sidebar 
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onLogout={onLogout}
        user={user}
      />

      {/* Main Content */}
      <div className="gov-main-content">
        {/* Top Navigation */}
        <div className="gov-top-navbar">
          <h1 className="gov-page-title">{getPageTitle()}</h1>
          <div className="gov-breadcrumb">
            {getBreadcrumb().map((item, index) => (
              <div key={index} className="gov-breadcrumb-item">
                {item.icon && <item.icon size={16} />}
                <span>{item.label}</span>
                {index < getBreadcrumb().length - 1 && (
                  <span className="gov-breadcrumb-separator">/</span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Content Area */}
        <div className="gov-content-area">
          {activeTab === 'overview' && (
            <Container fluid>
              {/* Hasta Listesi ve Seçim */}
              <Row>
                <Col lg={4} md={12} className="mb-4">
                  <PatientList
                    patients={filteredPatients}
                    selectedPatient={selectedPatient}
                    onPatientSelect={handlePatientSelect}
                    searchTerm={searchTerm}
                    onSearchChange={setSearchTerm}
                    allDiseases={allDiseases}
                    selectedDiseases={selectedDiseases}
                    onDiseaseFilter={handleDiseaseFilter}
                    onClearFilters={clearFilters}
                  />
                </Col>
                
                <Col lg={8} md={12}>
                  {selectedPatient ? (
                    <>
                      <PatientSummaryCard patient={selectedPatient} aiSummary={aiSummary} />
                      
                      <Row className="mt-4">
                        <Col md={6}>
                          <PatientDetails patient={selectedPatient} />
                        </Col>
                        <Col md={6}>
                          <AdvancedAIPanel 
                            patient={selectedPatient}
                            aiSummary={aiSummary}
                            drugInteractions={drugInteractions}
                            onApprovalChange={handleApprovalChange}
                          />
                        </Col>
                      </Row>

                      <Row className="mt-4">
                        <Col md={6}>
                          <ReconciledMedicationList 
                            patient={selectedPatient}
                            onMedicationUpdate={handleMedicationUpdate}
                          />
                        </Col>
                        <Col md={6}>
                          <AdvancedTimeline patient={selectedPatient} />
                        </Col>
                      </Row>

                      {/* Kontrol Butonları */}
                      <Row className="mt-4">
                        <Col>
                          <div className="d-flex justify-content-center gap-3">
                            <button 
                              className="gov-btn gov-btn-outline-primary"
                              onClick={() => setShowAuditLog(true)}
                            >
                              <FileText size={16} />
                              Audit Log
                            </button>
                            <button 
                              className="gov-btn gov-btn-outline-success"
                              onClick={() => setShowKPIDashboard(true)}
                            >
                              <Target size={16} />
                              KPI Dashboard
                            </button>
                            <button 
                              className="gov-btn gov-btn-outline-info"
                              onClick={() => setShowConsentPanel(true)}
                            >
                              <Activity size={16} />
                              Rıza Yönetimi
                            </button>
                          </div>
                        </Col>
                      </Row>
                    </>
                  ) : (
                    <div className="text-center py-5">
                      <Users size={64} className="text-muted mb-3" />
                      <h4 className="text-muted">Hasta Seçiniz</h4>
                      <p className="text-muted">Detayları görüntülemek için sol panelden bir hasta seçiniz.</p>
                    </div>
                  )}
                </Col>
              </Row>
            </Container>
          )}

          {activeTab === 'patients' && (
            <Container fluid>
              <Row>
                <Col>
                  <PatientList
                    patients={filteredPatients}
                    selectedPatient={selectedPatient}
                    onPatientSelect={handlePatientSelect}
                    searchTerm={searchTerm}
                    onSearchChange={setSearchTerm}
                    allDiseases={allDiseases}
                    selectedDiseases={selectedDiseases}
                    onDiseaseFilter={handleDiseaseFilter}
                    onClearFilters={clearFilters}
                  />
                </Col>
              </Row>
            </Container>
          )}

          {activeTab === 'appointments' && selectedPatient && (
            <Container fluid>
              <AppointmentScheduling 
                patient={selectedPatient}
                onAppointmentUpdate={(appointments) => {
                  console.log('Appointments updated:', appointments);
                }}
              />
            </Container>
          )}

          {activeTab === 'prescriptions' && selectedPatient && (
            <Container fluid>
              <PrescriptionManagement 
                patient={selectedPatient}
                onPrescriptionUpdate={(prescriptions) => {
                  console.log('Prescriptions updated:', prescriptions);
                }}
              />
            </Container>
          )}

          {activeTab === 'lab' && selectedPatient && (
            <Container fluid>
              <LabResultsIntegration 
                patient={selectedPatient}
                onLabResultUpdate={(labResults) => {
                  console.log('Lab results updated:', labResults);
                }}
              />
            </Container>
          )}

          {activeTab === 'analytics' && (
            <Container fluid>
              <DashboardAnalytics 
                patient={selectedPatient}
                allPatients={patients}
              />
            </Container>
          )}
        </div>
      </div>

      {/* Modals */}
      <AuditLogPanel 
        show={showAuditLog} 
        onHide={() => setShowAuditLog(false)}
        patientId={selectedPatient?.id}
      />
      
      <Modal show={showKPIDashboard} onHide={() => setShowKPIDashboard(false)} size="xl">
        <Modal.Header closeButton>
          <Modal.Title>KPI Dashboard</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <KPIDashboard 
            patients={patients} 
            show={showKPIDashboard} 
            onHide={() => setShowKPIDashboard(false)}
          />
        </Modal.Body>
      </Modal>

      <Modal show={showConsentPanel} onHide={() => setShowConsentPanel(false)} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Hasta Rızası Yönetimi</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <ConsentPanel 
            patient={selectedPatient}
            onConsentUpdate={(consent) => {
              console.log('Consent updated:', consent);
            }}
          />
        </Modal.Body>
      </Modal>
    </>
  );
};

export default DoctorPanel;
