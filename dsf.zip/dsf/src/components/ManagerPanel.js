import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Activity, 
  Building, 
  Calendar, 
  TrendingUp, 
  AlertTriangle,
  UserCheck,
  Clock,
  DollarSign,
  FileText,
  Settings,
  BarChart3,
  Stethoscope
} from 'lucide-react';
import DoctorList from './manager/DoctorList';
import doctorsData from '../data/doctors.json';

const ManagerPanel = ({ patients, user, onLogout }) => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [doctors] = useState(doctorsData);
  const [stats, setStats] = useState({
    totalPatients: 0,
    totalDoctors: 12,
    totalBeds: 150,
    occupiedBeds: 89,
    todayAppointments: 45,
    pendingApprovals: 8,
    revenue: 125000,
    expenses: 98000
  });

  const [recentActivities, setRecentActivities] = useState([
    {
      id: 1,
      type: 'appointment',
      message: 'Dr. Mehmet Kaya - 15 randevu tamamlandı',
      time: '2 saat önce',
      priority: 'normal'
    },
    {
      id: 2,
      type: 'alert',
      message: 'Acil serviste yatak kapasitesi %95',
      time: '30 dakika önce',
      priority: 'high'
    },
    {
      id: 3,
      type: 'approval',
      message: 'Yeni ekipman satın alma onayı bekliyor',
      time: '1 saat önce',
      priority: 'medium'
    },
    {
      id: 4,
      type: 'revenue',
      message: 'Günlük gelir hedefi %110 gerçekleşti',
      time: '4 saat önce',
      priority: 'normal'
    }
  ]);

  useEffect(() => {
    if (patients) {
      setStats(prev => ({
        ...prev,
        totalPatients: patients.length,
        totalDoctors: doctors.length
      }));
    }
  }, [patients, doctors]);

  const StatCard = ({ icon: Icon, title, value, subtitle, color = "blue", trend }) => (
    <div className="minimal-card" style={{ padding: '20px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
        <div style={{ 
          backgroundColor: `var(--${color}-100)`, 
          color: `var(--${color}-600)`,
          padding: '8px',
          borderRadius: '8px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          <Icon size={20} />
        </div>
        {trend && (
          <div style={{ 
            color: trend > 0 ? '#10b981' : '#ef4444',
            fontSize: '14px',
            fontWeight: '600'
          }}>
            {trend > 0 ? '+' : ''}{trend}%
          </div>
        )}
      </div>
      <div style={{ fontSize: '24px', fontWeight: '700', color: '#1f2937', marginBottom: '4px' }}>
        {value}
      </div>
      <div style={{ fontSize: '14px', color: '#6b7280' }}>
        {title}
      </div>
      {subtitle && (
        <div style={{ fontSize: '12px', color: '#9ca3af', marginTop: '4px' }}>
          {subtitle}
        </div>
      )}
    </div>
  );

  const ActivityItem = ({ activity }) => {
    const getIconAndColor = (type) => {
      switch (type) {
        case 'appointment':
          return { icon: Calendar, color: '#3b82f6' };
        case 'alert':
          return { icon: AlertTriangle, color: '#ef4444' };
        case 'approval':
          return { icon: FileText, color: '#f59e0b' };
        case 'revenue':
          return { icon: TrendingUp, color: '#10b981' };
        default:
          return { icon: Activity, color: '#6b7280' };
      }
    };

    const { icon: Icon, color } = getIconAndColor(activity.type);

    return (
      <div style={{ 
        display: 'flex', 
        alignItems: 'center', 
        gap: '12px', 
        padding: '12px 0',
        borderBottom: '1px solid #f3f4f6'
      }}>
        <div style={{ 
          backgroundColor: `${color}20`, 
          color: color,
          padding: '6px',
          borderRadius: '6px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          <Icon size={16} />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: '14px', fontWeight: '500', color: '#1f2937' }}>
            {activity.message}
          </div>
          <div style={{ fontSize: '12px', color: '#6b7280' }}>
            {activity.time}
          </div>
        </div>
        {activity.priority === 'high' && (
          <div style={{ 
            backgroundColor: '#fef2f2',
            color: '#dc2626',
            padding: '2px 8px',
            borderRadius: '12px',
            fontSize: '11px',
            fontWeight: '600'
          }}>
            ACİL
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="minimal-container" style={{ padding: '24px' }}>
      {/* Header */}
      <div style={{ marginBottom: '32px' }}>
        <h1 style={{ fontSize: '28px', fontWeight: '700', color: '#1f2937', marginBottom: '8px' }}>
          Hastane Yönetici Paneli
        </h1>
        <p style={{ color: '#6b7280', fontSize: '16px', marginBottom: '20px' }}>
          Hoş geldiniz, {user.name} • {user.title}
        </p>

        {/* Navigation Tabs */}
        <div style={{ display: 'flex', gap: '8px', borderBottom: '1px solid #e5e7eb' }}>
          <button
            className={`minimal-btn ${activeTab === 'dashboard' ? 'minimal-btn-primary' : 'minimal-btn-secondary'}`}
            onClick={() => setActiveTab('dashboard')}
            style={{ 
              borderRadius: '8px 8px 0 0',
              border: 'none',
              borderBottom: activeTab === 'dashboard' ? '2px solid #3b82f6' : '2px solid transparent'
            }}
          >
            <BarChart3 size={16} />
            Dashboard
          </button>
          <button
            className={`minimal-btn ${activeTab === 'doctors' ? 'minimal-btn-primary' : 'minimal-btn-secondary'}`}
            onClick={() => setActiveTab('doctors')}
            style={{ 
              borderRadius: '8px 8px 0 0',
              border: 'none',
              borderBottom: activeTab === 'doctors' ? '2px solid #3b82f6' : '2px solid transparent'
            }}
          >
            <Stethoscope size={16} />
            Doktorlar
          </button>
        </div>
      </div>

      {/* Content */}
      {activeTab === 'dashboard' && (
        <>
          {/* Stats Grid */}
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', 
            gap: '20px',
            marginBottom: '32px'
          }}>
        <StatCard 
          icon={Users} 
          title="Toplam Hasta" 
          value={stats.totalPatients}
          color="blue"
          trend={12}
        />
        <StatCard 
          icon={UserCheck} 
          title="Aktif Doktor" 
          value={stats.totalDoctors}
          color="green"
          trend={5}
        />
        <StatCard 
          icon={Building} 
          title="Yatak Doluluk" 
          value={`${stats.occupiedBeds}/${stats.totalBeds}`}
          subtitle={`%${Math.round((stats.occupiedBeds / stats.totalBeds) * 100)} doluluk`}
          color="orange"
          trend={-3}
        />
        <StatCard 
          icon={Calendar} 
          title="Bugünkü Randevular" 
          value={stats.todayAppointments}
          color="purple"
          trend={8}
        />
        <StatCard 
          icon={DollarSign} 
          title="Aylık Gelir" 
          value={`₺${stats.revenue.toLocaleString()}`}
          subtitle="Hedefin %110'u"
          color="green"
          trend={15}
        />
        <StatCard 
          icon={FileText} 
          title="Bekleyen Onaylar" 
          value={stats.pendingApprovals}
          color="red"
        />
      </div>

      {/* Main Content Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '24px' }}>
        
        {/* Performance Chart Area */}
        <div className="minimal-card" style={{ padding: '24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
            <BarChart3 size={24} color="#3b82f6" />
            <h3 style={{ fontSize: '18px', fontWeight: '600', color: '#1f2937' }}>
              Performans Özeti
            </h3>
          </div>
          
          {/* Simple performance indicators */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
            <div>
              <h4 style={{ fontSize: '14px', fontWeight: '600', color: '#6b7280', marginBottom: '8px' }}>
                Hasta Memnuniyeti
              </h4>
              <div style={{ 
                backgroundColor: '#f3f4f6', 
                borderRadius: '8px', 
                padding: '4px',
                marginBottom: '4px'
              }}>
                <div style={{ 
                  backgroundColor: '#10b981', 
                  width: '87%', 
                  height: '8px', 
                  borderRadius: '4px' 
                }}></div>
              </div>
              <div style={{ fontSize: '12px', color: '#6b7280' }}>87% Memnun</div>
            </div>
            
            <div>
              <h4 style={{ fontSize: '14px', fontWeight: '600', color: '#6b7280', marginBottom: '8px' }}>
                Operasyonel Verimlilik
              </h4>
              <div style={{ 
                backgroundColor: '#f3f4f6', 
                borderRadius: '8px', 
                padding: '4px',
                marginBottom: '4px'
              }}>
                <div style={{ 
                  backgroundColor: '#3b82f6', 
                  width: '92%', 
                  height: '8px', 
                  borderRadius: '4px' 
                }}></div>
              </div>
              <div style={{ fontSize: '12px', color: '#6b7280' }}>92% Verimli</div>
            </div>
            
            <div>
              <h4 style={{ fontSize: '14px', fontWeight: '600', color: '#6b7280', marginBottom: '8px' }}>
                Maliyet Optimizasyonu
              </h4>
              <div style={{ 
                backgroundColor: '#f3f4f6', 
                borderRadius: '8px', 
                padding: '4px',
                marginBottom: '4px'
              }}>
                <div style={{ 
                  backgroundColor: '#f59e0b', 
                  width: '78%', 
                  height: '8px', 
                  borderRadius: '4px' 
                }}></div>
              </div>
              <div style={{ fontSize: '12px', color: '#6b7280' }}>78% Optimizasyon</div>
            </div>
            
            <div>
              <h4 style={{ fontSize: '14px', fontWeight: '600', color: '#6b7280', marginBottom: '8px' }}>
                Personel Verimliliği
              </h4>
              <div style={{ 
                backgroundColor: '#f3f4f6', 
                borderRadius: '8px', 
                padding: '4px',
                marginBottom: '4px'
              }}>
                <div style={{ 
                  backgroundColor: '#8b5cf6', 
                  width: '85%', 
                  height: '8px', 
                  borderRadius: '4px' 
                }}></div>
              </div>
              <div style={{ fontSize: '12px', color: '#6b7280' }}>85% Verimli</div>
            </div>
          </div>

          {/* Quick Actions */}
          <div style={{ marginTop: '24px', paddingTop: '20px', borderTop: '1px solid #f3f4f6' }}>
            <h4 style={{ fontSize: '16px', fontWeight: '600', color: '#1f2937', marginBottom: '12px' }}>
              Hızlı İşlemler
            </h4>
            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
              <button className="minimal-btn minimal-btn-secondary" style={{ fontSize: '14px' }}>
                <Settings size={16} />
                Sistem Ayarları
              </button>
              <button className="minimal-btn minimal-btn-secondary" style={{ fontSize: '14px' }}>
                <FileText size={16} />
                Raporlar
              </button>
              <button className="minimal-btn minimal-btn-secondary" style={{ fontSize: '14px' }}>
                <Users size={16} />
                Personel Yönetimi
              </button>
            </div>
          </div>
        </div>

        {/* Recent Activities */}
        <div className="minimal-card" style={{ padding: '24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
            <Activity size={24} color="#3b82f6" />
            <h3 style={{ fontSize: '18px', fontWeight: '600', color: '#1f2937' }}>
              Son Aktiviteler
            </h3>
          </div>
          
          <div>
            {recentActivities.map(activity => (
              <ActivityItem key={activity.id} activity={activity} />
            ))}
          </div>

          <button 
            className="minimal-btn minimal-btn-secondary" 
            style={{ width: '100%', marginTop: '16px', fontSize: '14px' }}
          >
            Tüm Aktiviteleri Görüntüle
          </button>
        </div>
      </div>
        </>
      )}

      {activeTab === 'doctors' && (
        <DoctorList 
          doctors={doctors} 
          onDoctorsUpdate={(newDoctors) => {
            // Güncellenmiş doktor listesini kaydet
            console.log('Doktorlar güncellendi:', newDoctors);
          }} 
        />
      )}
    </div>
  );
};

export default ManagerPanel;
