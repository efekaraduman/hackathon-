import React, { useState, useEffect } from 'react';
import { 
  X, 
  Save, 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Stethoscope,
  Calendar,
  Award,
  Clock,
  Building
} from 'lucide-react';

const DoctorModal = ({ isOpen, onClose, doctor, onSave, mode = 'view' }) => {
  const [formData, setFormData] = useState({
    name: '',
    specialty: '',
    department: '',
    email: '',
    phone: '',
    experience: 0,
    education: '',
    status: 'Aktif',
    shift: 'Gündüz',
    room: '',
    rating: 4.0,
    specializations: [],
    avatar: '👨‍⚕️'
  });

  const [newSpecialization, setNewSpecialization] = useState('');

  useEffect(() => {
    if (doctor) {
      setFormData({ ...doctor });
    } else {
      // Yeni doktor için temiz form
      setFormData({
        name: '',
        specialty: '',
        department: '',
        email: '',
        phone: '',
        experience: 0,
        education: '',
        status: 'Aktif',
        shift: 'Gündüz',
        room: '',
        rating: 4.0,
        specializations: [],
        avatar: '👨‍⚕️'
      });
    }
  }, [doctor]);

  const departments = [
    'Kalp ve Damar Cerrahisi',
    'Beyin ve Sinir Cerrahisi',
    'Ortopedi ve Travmatoloji',
    'Çocuk Hastalıkları',
    'Anesteziyoloji',
    'Jinekologi ve Obstetrik',
    'İç Hastalıkları',
    'Cildiye',
    'Üroloji',
    'Göz Hastalıkları',
    'Kulak Burun Boğaz',
    'Radyoloji',
    'Acil Tıp'
  ];

  const specialties = [
    'Kardiyoloji',
    'Nöroloji', 
    'Ortopedi',
    'Pediatri',
    'Anestezi',
    'Kadın Doğum',
    'Dahiliye',
    'Dermatoloji',
    'Üroloji',
    'Oftalmoloji',
    'KBB',
    'Radyoloji',
    'Acil Tıp'
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const addSpecialization = () => {
    if (newSpecialization.trim() && !formData.specializations.includes(newSpecialization.trim())) {
      setFormData(prev => ({
        ...prev,
        specializations: [...prev.specializations, newSpecialization.trim()]
      }));
      setNewSpecialization('');
    }
  };

  const removeSpecialization = (index) => {
    setFormData(prev => ({
      ...prev,
      specializations: prev.specializations.filter((_, i) => i !== index)
    }));
  };

  const handleSave = () => {
    // Basit validasyon
    if (!formData.name || !formData.specialty || !formData.department) {
      alert('Lütfen zorunlu alanları doldurun.');
      return;
    }

    const saveData = {
      ...formData,
      id: doctor?.id || `D${String(Date.now()).slice(-3)}`,
      patients: doctor?.patients || 0,
      joinDate: doctor?.joinDate || new Date().toISOString().split('T')[0]
    };

    onSave(saveData);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
      padding: '20px'
    }}>
      <div style={{
        backgroundColor: 'white',
        borderRadius: '12px',
        width: '100%',
        maxWidth: '800px',
        maxHeight: '90vh',
        overflow: 'auto',
        boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)'
      }}>
        {/* Header */}
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          padding: '24px',
          borderBottom: '1px solid #e5e7eb'
        }}>
          <h2 style={{ margin: 0, fontSize: '24px', fontWeight: '700', color: '#1f2937' }}>
            {mode === 'add' ? 'Yeni Doktor Ekle' : mode === 'edit' ? 'Doktor Düzenle' : 'Doktor Detayları'}
          </h2>
          <button
            onClick={onClose}
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              color: '#6b7280',
              padding: '8px'
            }}
          >
            <X size={24} />
          </button>
        </div>

        {/* Content */}
        <div style={{ padding: '24px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '24px' }}>
            
            {/* Kişisel Bilgiler */}
            <div>
              <h3 style={{ fontSize: '18px', fontWeight: '600', color: '#1f2937', marginBottom: '16px' }}>
                <User size={20} style={{ marginRight: '8px', verticalAlign: 'middle' }} />
                Kişisel Bilgiler
              </h3>

              <div style={{ marginBottom: '16px' }}>
                <label style={{ fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '6px', display: 'block' }}>
                  Ad Soyad *
                </label>
                <input
                  type="text"
                  className="minimal-input"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  disabled={mode === 'view'}
                  placeholder="Dr. İsim Soyisim"
                />
              </div>

              <div style={{ marginBottom: '16px' }}>
                <label style={{ fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '6px', display: 'block' }}>
                  Uzmanlık *
                </label>
                <select
                  className="minimal-input"
                  value={formData.specialty}
                  onChange={(e) => handleInputChange('specialty', e.target.value)}
                  disabled={mode === 'view'}
                >
                  <option value="">Seçiniz</option>
                  {specialties.map(spec => (
                    <option key={spec} value={spec}>{spec}</option>
                  ))}
                </select>
              </div>

              <div style={{ marginBottom: '16px' }}>
                <label style={{ fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '6px', display: 'block' }}>
                  Departman *
                </label>
                <select
                  className="minimal-input"
                  value={formData.department}
                  onChange={(e) => handleInputChange('department', e.target.value)}
                  disabled={mode === 'view'}
                >
                  <option value="">Seçiniz</option>
                  {departments.map(dept => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>

              <div style={{ marginBottom: '16px' }}>
                <label style={{ fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '6px', display: 'block' }}>
                  Eğitim
                </label>
                <input
                  type="text"
                  className="minimal-input"
                  value={formData.education}
                  onChange={(e) => handleInputChange('education', e.target.value)}
                  disabled={mode === 'view'}
                  placeholder="Üniversite Tıp Fakültesi"
                />
              </div>
            </div>

            {/* İletişim ve Çalışma Bilgileri */}
            <div>
              <h3 style={{ fontSize: '18px', fontWeight: '600', color: '#1f2937', marginBottom: '16px' }}>
                <Building size={20} style={{ marginRight: '8px', verticalAlign: 'middle' }} />
                İletişim ve Çalışma
              </h3>

              <div style={{ marginBottom: '16px' }}>
                <label style={{ fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '6px', display: 'block' }}>
                  E-posta
                </label>
                <input
                  type="email"
                  className="minimal-input"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  disabled={mode === 'view'}
                  placeholder="doktor@hastane.com"
                />
              </div>

              <div style={{ marginBottom: '16px' }}>
                <label style={{ fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '6px', display: 'block' }}>
                  Telefon
                </label>
                <input
                  type="tel"
                  className="minimal-input"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  disabled={mode === 'view'}
                  placeholder="+90 5XX XXX XXXX"
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '16px' }}>
                <div>
                  <label style={{ fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '6px', display: 'block' }}>
                    Deneyim (Yıl)
                  </label>
                  <input
                    type="number"
                    className="minimal-input"
                    value={formData.experience}
                    onChange={(e) => handleInputChange('experience', parseInt(e.target.value) || 0)}
                    disabled={mode === 'view'}
                    min="0"
                    max="50"
                  />
                </div>
                <div>
                  <label style={{ fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '6px', display: 'block' }}>
                    Oda No
                  </label>
                  <input
                    type="text"
                    className="minimal-input"
                    value={formData.room}
                    onChange={(e) => handleInputChange('room', e.target.value)}
                    disabled={mode === 'view'}
                    placeholder="A-101"
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '16px' }}>
                <div>
                  <label style={{ fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '6px', display: 'block' }}>
                    Durum
                  </label>
                  <select
                    className="minimal-input"
                    value={formData.status}
                    onChange={(e) => handleInputChange('status', e.target.value)}
                    disabled={mode === 'view'}
                  >
                    <option value="Aktif">Aktif</option>
                    <option value="İzinli">İzinli</option>
                    <option value="Pasif">Pasif</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '6px', display: 'block' }}>
                    Vardiya
                  </label>
                  <select
                    className="minimal-input"
                    value={formData.shift}
                    onChange={(e) => handleInputChange('shift', e.target.value)}
                    disabled={mode === 'view'}
                  >
                    <option value="Gündüz">Gündüz</option>
                    <option value="Gece">Gece</option>
                    <option value="24 Saat">24 Saat</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Uzmanlık Alanları */}
          <div style={{ marginTop: '24px' }}>
            <h3 style={{ fontSize: '18px', fontWeight: '600', color: '#1f2937', marginBottom: '16px' }}>
              <Award size={20} style={{ marginRight: '8px', verticalAlign: 'middle' }} />
              Uzmanlık Alanları
            </h3>

            {mode !== 'view' && (
              <div style={{ display: 'flex', gap: '8px', marginBottom: '12px' }}>
                <input
                  type="text"
                  className="minimal-input"
                  value={newSpecialization}
                  onChange={(e) => setNewSpecialization(e.target.value)}
                  placeholder="Yeni uzmanlık alanı ekle"
                  style={{ flex: 1 }}
                  onKeyPress={(e) => e.key === 'Enter' && addSpecialization()}
                />
                <button
                  type="button"
                  className="minimal-btn minimal-btn-primary"
                  onClick={addSpecialization}
                  style={{ whiteSpace: 'nowrap' }}
                >
                  Ekle
                </button>
              </div>
            )}

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
              {formData.specializations.map((spec, index) => (
                <span 
                  key={index}
                  style={{
                    backgroundColor: '#f3f4f6',
                    color: '#374151',
                    padding: '4px 12px',
                    borderRadius: '12px',
                    fontSize: '14px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px'
                  }}
                >
                  {spec}
                  {mode !== 'view' && (
                    <button
                      type="button"
                      onClick={() => removeSpecialization(index)}
                      style={{
                        background: 'none',
                        border: 'none',
                        cursor: 'pointer',
                        color: '#6b7280',
                        padding: '0',
                        fontSize: '16px'
                      }}
                    >
                      ×
                    </button>
                  )}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        {mode !== 'view' && (
          <div style={{
            display: 'flex',
            justifyContent: 'flex-end',
            gap: '12px',
            padding: '24px',
            borderTop: '1px solid #e5e7eb'
          }}>
            <button
              type="button"
              className="minimal-btn minimal-btn-secondary"
              onClick={onClose}
            >
              İptal
            </button>
            <button
              type="button"
              className="minimal-btn minimal-btn-primary"
              onClick={handleSave}
            >
              <Save size={16} style={{ marginRight: '6px' }} />
              {mode === 'add' ? 'Ekle' : 'Kaydet'}
            </button>
          </div>
        )}

        {mode === 'view' && (
          <div style={{
            display: 'flex',
            justifyContent: 'flex-end',
            padding: '24px',
            borderTop: '1px solid #e5e7eb'
          }}>
            <button
              type="button"
              className="minimal-btn minimal-btn-secondary"
              onClick={onClose}
            >
              Kapat
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default DoctorModal;
