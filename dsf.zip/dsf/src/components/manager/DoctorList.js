import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Filter, 
  Star, 
  Phone, 
  Mail, 
  MapPin, 
  Calendar,
  Clock,
  Award,
  Activity,
  User,
  Stethoscope,
  Eye,
  Edit,
  Trash2,
  Plus
} from 'lucide-react';
import DoctorModal from './DoctorModal';

const DoctorList = ({ doctors: initialDoctors, onDoctorsUpdate }) => {
  const [doctors, setDoctors] = useState(initialDoctors);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDepartment, setFilterDepartment] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  
  // Modal states
  const [modalOpen, setModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('view'); // view, edit, add
  const [selectedDoctor, setSelectedDoctor] = useState(null);

  // Filtreleme
  const filteredDoctors = doctors.filter(doctor => {
    const matchesSearch = doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doctor.specialty.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDepartment = !filterDepartment || doctor.department === filterDepartment;
    const matchesStatus = !filterStatus || doctor.status === filterStatus;
    
    return matchesSearch && matchesDepartment && matchesStatus;
  });

  // Benzersiz departmanları al
  const departments = [...new Set(doctors.map(doctor => doctor.department))];

  // Modal işlemleri
  const openModal = (mode, doctor = null) => {
    setModalMode(mode);
    setSelectedDoctor(doctor);
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setSelectedDoctor(null);
  };

  const handleSaveDoctor = (doctorData) => {
    if (modalMode === 'add') {
      const newDoctors = [...doctors, doctorData];
      setDoctors(newDoctors);
      onDoctorsUpdate?.(newDoctors);
    } else if (modalMode === 'edit') {
      const newDoctors = doctors.map(d => d.id === doctorData.id ? doctorData : d);
      setDoctors(newDoctors);
      onDoctorsUpdate?.(newDoctors);
    }
  };

  const handleDeleteDoctor = (doctorId) => {
    if (window.confirm('Bu doktoru silmek istediğinizden emin misiniz?')) {
      const newDoctors = doctors.filter(d => d.id !== doctorId);
      setDoctors(newDoctors);
      onDoctorsUpdate?.(newDoctors);
    }
  };

  const DoctorCard = ({ doctor }) => {
    const getStatusColor = (status) => {
      switch (status) {
        case 'Aktif': return '#10b981';
        case 'İzinli': return '#f59e0b';
        case 'Pasif': return '#ef4444';
        default: return '#6b7280';
      }
    };

    return (
      <div className="minimal-card" style={{ padding: '20px', marginBottom: '16px' }}>
        <div style={{ display: 'flex', gap: '16px' }}>
          {/* Avatar */}
          <div style={{
            width: '60px',
            height: '60px',
            backgroundColor: '#f3f4f6',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '24px',
            flexShrink: 0
          }}>
            {doctor.avatar}
          </div>

          {/* Ana Bilgiler */}
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
              <div>
                <h3 style={{ margin: '0 0 4px 0', fontSize: '18px', fontWeight: '600', color: '#1f2937' }}>
                  {doctor.name}
                </h3>
                <p style={{ margin: '0', color: '#3b82f6', fontWeight: '500', fontSize: '14px' }}>
                  {doctor.specialty}
                </p>
              </div>
              
              <div style={{ 
                backgroundColor: getStatusColor(doctor.status) + '20',
                color: getStatusColor(doctor.status),
                padding: '4px 12px',
                borderRadius: '12px',
                fontSize: '12px',
                fontWeight: '600'
              }}>
                {doctor.status}
              </div>
            </div>

            {/* Departman ve Oda */}
            <div style={{ display: 'flex', gap: '20px', marginBottom: '12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#6b7280', fontSize: '14px' }}>
                <Stethoscope size={14} />
                {doctor.department}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#6b7280', fontSize: '14px' }}>
                <MapPin size={14} />
                Oda {doctor.room}
              </div>
            </div>

            {/* İstatistikler */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', gap: '16px', marginBottom: '12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <Users size={14} color="#3b82f6" />
                <span style={{ fontSize: '14px', color: '#374151' }}>
                  <strong>{doctor.patients}</strong> hasta
                </span>
              </div>
              
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <Star size={14} color="#f59e0b" />
                <span style={{ fontSize: '14px', color: '#374151' }}>
                  <strong>{doctor.rating}</strong> puan
                </span>
              </div>
              
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <Award size={14} color="#10b981" />
                <span style={{ fontSize: '14px', color: '#374151' }}>
                  <strong>{doctor.experience}</strong> yıl
                </span>
              </div>
              
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <Clock size={14} color="#8b5cf6" />
                <span style={{ fontSize: '14px', color: '#374151' }}>
                  {doctor.shift}
                </span>
              </div>
            </div>

            {/* İletişim */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '12px', borderTop: '1px solid #f3f4f6' }}>
              <div style={{ display: 'flex', gap: '20px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#6b7280', fontSize: '13px' }}>
                  <Phone size={12} />
                  {doctor.phone}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#6b7280', fontSize: '13px' }}>
                  <Mail size={12} />
                  {doctor.email}
                </div>
              </div>

              {/* İşlem Butonları */}
              <div style={{ display: 'flex', gap: '6px' }}>
                <button
                  className="minimal-btn minimal-btn-secondary"
                  onClick={() => openModal('view', doctor)}
                  style={{ 
                    padding: '6px 8px', 
                    fontSize: '12px',
                    backgroundColor: '#f3f4f6',
                    color: '#374151'
                  }}
                  title="Detayları Görüntüle"
                >
                  <Eye size={14} />
                </button>
                <button
                  className="minimal-btn minimal-btn-secondary"
                  onClick={() => openModal('edit', doctor)}
                  style={{ 
                    padding: '6px 8px', 
                    fontSize: '12px',
                    backgroundColor: '#dbeafe',
                    color: '#1d4ed8'
                  }}
                  title="Düzenle"
                >
                  <Edit size={14} />
                </button>
                <button
                  className="minimal-btn minimal-btn-secondary"
                  onClick={() => handleDeleteDoctor(doctor.id)}
                  style={{ 
                    padding: '6px 8px', 
                    fontSize: '12px',
                    backgroundColor: '#fee2e2',
                    color: '#dc2626'
                  }}
                  title="Sil"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Uzmanlık Alanları */}
        <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px solid #f3f4f6' }}>
          <h4 style={{ fontSize: '14px', fontWeight: '600', color: '#374151', marginBottom: '8px' }}>
            Uzmanlık Alanları:
          </h4>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
            {doctor.specializations.map((spec, index) => (
              <span 
                key={index}
                style={{
                  backgroundColor: '#f3f4f6',
                  color: '#374151',
                  padding: '2px 8px',
                  borderRadius: '12px',
                  fontSize: '12px'
                }}
              >
                {spec}
              </span>
            ))}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: '24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <Users size={24} color="#3b82f6" />
            <h2 style={{ fontSize: '24px', fontWeight: '700', color: '#1f2937', margin: '0' }}>
              Doktor Yönetimi
            </h2>
          </div>
          <button
            className="minimal-btn minimal-btn-primary"
            onClick={() => openModal('add')}
            style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '8px',
              fontWeight: '500'
            }}
          >
            <Plus size={18} />
            Yeni Doktor Ekle
          </button>
        </div>
        <p style={{ color: '#6b7280', margin: '0' }}>
          Hastanedeki tüm doktorları görüntüleyin ve yönetin
        </p>
      </div>

      {/* Filtreler */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', 
        gap: '16px', 
        marginBottom: '24px',
        padding: '20px',
        backgroundColor: '#f8fafc',
        borderRadius: '12px'
      }}>
        {/* Arama */}
        <div>
          <label style={{ fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '6px', display: 'block' }}>
            Doktor Ara
          </label>
          <div style={{ position: 'relative' }}>
            <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#6b7280' }} />
            <input
              type="text"
              className="minimal-input"
              placeholder="İsim veya uzmanlık..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ paddingLeft: '40px' }}
            />
          </div>
        </div>

        {/* Departman Filtresi */}
        <div>
          <label style={{ fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '6px', display: 'block' }}>
            Departman
          </label>
          <select
            className="minimal-input"
            value={filterDepartment}
            onChange={(e) => setFilterDepartment(e.target.value)}
          >
            <option value="">Tüm Departmanlar</option>
            {departments.map(dept => (
              <option key={dept} value={dept}>{dept}</option>
            ))}
          </select>
        </div>

        {/* Durum Filtresi */}
        <div>
          <label style={{ fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '6px', display: 'block' }}>
            Durum
          </label>
          <select
            className="minimal-input"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="">Tüm Durumlar</option>
            <option value="Aktif">Aktif</option>
            <option value="İzinli">İzinli</option>
            <option value="Pasif">Pasif</option>
          </select>
        </div>
      </div>

      {/* Sonuç Sayısı */}
      <div style={{ marginBottom: '20px', color: '#6b7280', fontSize: '14px' }}>
        <Activity size={16} style={{ marginRight: '6px', verticalAlign: 'middle' }} />
        {filteredDoctors.length} doktor bulundu
      </div>

      {/* Doktor Listesi */}
      <div>
        {filteredDoctors.length > 0 ? (
          filteredDoctors.map(doctor => (
            <DoctorCard key={doctor.id} doctor={doctor} />
          ))
        ) : (
          <div style={{ 
            textAlign: 'center', 
            padding: '40px', 
            color: '#6b7280',
            backgroundColor: '#f9fafb',
            borderRadius: '12px'
          }}>
            <User size={48} style={{ margin: '0 auto 16px auto', opacity: 0.5 }} />
            <h3 style={{ fontSize: '18px', fontWeight: '500', marginBottom: '8px' }}>
              Doktor Bulunamadı
            </h3>
            <p style={{ margin: '0' }}>
              Arama kriterlerinizi değiştirerek tekrar deneyin.
            </p>
          </div>
        )}
      </div>

      {/* Doctor Modal */}
      <DoctorModal
        isOpen={modalOpen}
        onClose={closeModal}
        doctor={selectedDoctor}
        onSave={handleSaveDoctor}
        mode={modalMode}
      />
    </div>
  );
};

export default DoctorList;
