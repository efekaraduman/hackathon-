import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Users, Activity, FileText, BarChart3, LogOut } from 'lucide-react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import './styles/minimalist.css';

// Components
import Login from './components/Login';
import DoctorPanel from './components/DoctorPanel';
import PatientPanel from './components/PatientPanel';
import Layout from './components/Layout';

// Admin Panel Component (inline)
const AdminPanel = ({ user, onLogout, patients }) => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [doctors, setDoctors] = useState([
    { id: 'D001', name: 'Dr. Mehmet Kaya', department: 'Kardiyoloji', email: 'mehmet.kaya@hastane.com', phone: '0532 123 4567', status: 'active', patients: 45 },
    { id: 'D002', name: 'Dr. Ayşe Demir', department: 'Nöroloji', email: 'ayse.demir@hastane.com', phone: '0532 234 5678', status: 'active', patients: 32 },
    { id: 'D003', name: 'Dr. Ali Yılmaz', department: 'Ortopedi', email: 'ali.yilmaz@hastane.com', phone: '0532 345 6789', status: 'inactive', patients: 28 },
    { id: 'D004', name: 'Dr. Fatma Özkan', department: 'Dahiliye', email: 'fatma.ozkan@hastane.com', phone: '0532 456 7890', status: 'active', patients: 38 },
    { id: 'D005', name: 'Dr. Mustafa Çelik', department: 'Göz Hastalıkları', email: 'mustafa.celik@hastane.com', phone: '0532 567 8901', status: 'active', patients: 41 }
  ]);
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [showDoctorModal, setShowDoctorModal] = useState(false);
  const [showDoctorDetail, setShowDoctorDetail] = useState(false);
  const [showEquipmentDetail, setShowEquipmentDetail] = useState(false);
  const [selectedEquipment, setSelectedEquipment] = useState(null);
  const [showMaintenanceHistory, setShowMaintenanceHistory] = useState(false);
  const [showTechnicalDocs, setShowTechnicalDocs] = useState(false);
  const [showEmergencyRepair, setShowEmergencyRepair] = useState(false);
  const [doctorForm, setDoctorForm] = useState({
    name: '',
    department: '',
    email: '',
    phone: '',
    status: 'active'
  });
  // Rastgele randevu verileri oluşturma fonksiyonu
  const generateRandomAppointments = () => {
    const today = new Date().toISOString().split('T')[0];
    const currentHour = new Date().getHours();
    const currentMinute = new Date().getMinutes();
    const currentTime = currentHour * 60 + currentMinute; // Dakika cinsinden mevcut zaman
    
    const patientNames = [
      'Ahmet Yılmaz', 'Fatma Demir', 'Mehmet Kaya', 'Ayşe Özkan', 'Ali Çelik',
      'Zeynep Yıldız', 'Mustafa Şahin', 'Elif Korkmaz', 'Hasan Yılmaz', 'Gülay Demir',
      'Okan Özkan', 'Cemil Kaya', 'Sibel Yıldız', 'Murat Çelik', 'Pınar Şahin',
      'Kemal Yılmaz', 'Nevin Demir', 'Recep Kaya', 'Sevgi Özkan', 'Tolga Şahin',
      'Aylin Yıldız', 'Burak Demir', 'Deniz Kaya', 'Ebru Özkan', 'Fikret Şahin',
      'Gülşen Aktaş', 'Hüseyin Özdemir', 'İpek Çelik', 'Jale Yılmaz', 'Kaan Şahin'
    ];
    
    const appointmentNotes = {
      'D001': [ // Kardiyoloji
        'EKG çekimi - Normal ritim', 'Holter takibi - 24 saatlik kayıt', 'Ekokardiyografi - Kalp fonksiyonları normal',
        'Göğüs ağrısı şikayeti - EKG normal', 'Kontrol muayenesi - İlaç doz ayarlaması', 'Ritim bozukluğu takibi',
        'Kalp kateterizasyonu sonrası kontrol', 'Hipertansiyon takibi', 'Kalp yetmezliği kontrolü'
      ],
      'D002': [ // Nöroloji
        'Baş ağrısı şikayeti - Migren', 'MR sonucu değerlendirme - Normal', 'EEG çekimi - Epilepsi şüphesi',
        'Nörolojik muayene - Denge problemi', 'Migren takibi - İlaç etkinliği', 'Bellek problemi - Demans taraması',
        'Baş dönmesi - Vertigo değerlendirmesi', 'Uyku bozukluğu - Polisomnografi', 'Kas güçsüzlüğü - EMG'
      ],
      'D003': [ // Ortopedi
        'Diz ağrısı - Menisküs şüphesi', 'Bel ağrısı - MR değerlendirme', 'Omuz ağrısı - Rotator cuff',
        'Kırık kontrolü - Röntgen normal', 'Fizik tedavi kontrolü', 'Eklem ağrısı - Artrit',
        'Spor yaralanması - ACL', 'Kemik yoğunluğu - Osteoporoz', 'Ayak ağrısı - Plantar fasiit'
      ],
      'D004': [ // Dahiliye
        'Diyabet kontrolü - HbA1c normal', 'Hipertansiyon takibi - Tansiyon kontrolü', 'Kolesterol yüksekliği',
        'Tiroid fonksiyon testleri', 'Karaciğer enzimleri - Normal', 'Böbrek fonksiyon testleri',
        'Genel sağlık kontrolü', 'Kilo verme programı', 'Metabolik sendrom takibi'
      ],
      'D005': [ // Göz Hastalıkları
        'Göz muayenesi - Miyop kontrolü', 'Göz tansiyonu - Glokom şüphesi', 'Katarakt muayenesi',
        'Göz dibi muayenesi - Retina normal', 'Göz kuruluğu tedavisi', 'Göz alerjisi - Konjonktivit',
        'Göz tembelliği - Ambliyopi', 'Göz kası felci - Strabismus', 'Göz travması kontrolü'
      ]
    };
    
    const times = ['08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30', 
                   '12:00', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00'];
    
    let appointments = [];
    let appointmentId = 1;
    
    doctors.forEach(doctor => {
      if (doctor.status === 'active') {
        // Her doktor için 3-6 arası rastgele randevu oluştur
        const appointmentCount = Math.floor(Math.random() * 4) + 3;
        const doctorAppointments = [];
        
        // Saatleri rastgele seç ama sıralı olsun
        const selectedTimes = times
          .sort(() => Math.random() - 0.5) // Rastgele karıştır
          .slice(0, appointmentCount) // İhtiyacımız kadar al
          .sort((a, b) => a.localeCompare(b)); // Saate göre sırala
        
        for (let i = 0; i < appointmentCount; i++) {
          const time = selectedTimes[i];
          const timeInMinutes = parseInt(time.split(':')[0]) * 60 + parseInt(time.split(':')[1]);
          
          const patientName = patientNames[Math.floor(Math.random() * patientNames.length)];
          const notes = appointmentNotes[doctor.id][Math.floor(Math.random() * appointmentNotes[doctor.id].length)];
          
          // Mevcut zamandan önceki randevular tamamlanmış, sonrakiler bekliyor
          const status = timeInMinutes < currentTime ? 'completed' : 'upcoming';
          
          doctorAppointments.push({
            id: `A${String(appointmentId).padStart(3, '0')}`,
            doctorId: doctor.id,
            patientName: patientName,
            time: time,
            date: today,
            status: status,
            notes: notes
          });
          
          appointmentId++;
        }
        
        appointments = [...appointments, ...doctorAppointments];
      }
    });
    
    return appointments;
  };

  const [appointments, setAppointments] = useState(generateRandomAppointments());
  
  // Ayarlar için state'ler
  const [settings, setSettings] = useState({
    hospital: {
      name: 'Merkez Hastanesi',
      address: 'Atatürk Caddesi No:123, Merkez/İstanbul',
      phone: '+90 212 555 0123',
      email: 'info@merkezhastanesi.com',
      website: 'www.merkezhastanesi.com',
      license: 'HST-2024-001',
      capacity: 500
    },
    system: {
      timezone: 'Europe/Istanbul',
      dateFormat: 'DD/MM/YYYY',
      timeFormat: '24',
      language: 'tr',
      currency: 'TRY',
      autoBackup: true,
      backupFrequency: 'daily',
      sessionTimeout: 30
    },
    notifications: {
      email: true,
      sms: true,
      push: true,
      appointmentReminder: true,
      emergencyAlert: true,
      systemMaintenance: true
    },
    security: {
      passwordPolicy: 'strong',
      twoFactorAuth: false,
      loginAttempts: 5,
      sessionDuration: 8,
      ipWhitelist: false,
      auditLog: true
    },
    integration: {
      labSystem: true,
      pharmacySystem: true,
      insuranceSystem: true,
      imagingSystem: true,
      emergencySystem: true
    }
  });

  const adminStats = {
    totalUsers: 1247,
    activeDoctors: doctors.filter(d => d.status === 'active').length,
    totalPatients: patients.length,
    systemUptime: '99.8%',
    criticalAlerts: 3,
    pendingApprovals: 12
  };

  // Doktor yönetimi fonksiyonları
  const handleAddDoctor = () => {
    setDoctorForm({
      name: '',
      department: '',
      email: '',
      phone: '',
      status: 'active'
    });
    setSelectedDoctor(null);
    setShowDoctorModal(true);
  };

  const handleEditDoctor = (doctor) => {
    setDoctorForm(doctor);
    setSelectedDoctor(doctor);
    setShowDoctorModal(true);
  };

  const handleSaveDoctor = () => {
    if (selectedDoctor) {
      // Düzenleme
      setDoctors(doctors.map(d => 
        d.id === selectedDoctor.id 
          ? { ...doctorForm, id: selectedDoctor.id, patients: selectedDoctor.patients }
          : d
      ));
    } else {
      // Yeni ekleme
      const newDoctor = {
        ...doctorForm,
        id: `D${String(doctors.length + 1).padStart(3, '0')}`,
        patients: 0
      };
      setDoctors([...doctors, newDoctor]);
    }
    setShowDoctorModal(false);
    setSelectedDoctor(null);
  };

  const handleDeleteDoctor = (doctorId) => {
    if (window.confirm('Bu doktoru silmek istediğinizden emin misiniz?')) {
      setDoctors(doctors.filter(d => d.id !== doctorId));
    }
  };

  const handleDoctorStatusChange = (doctorId, newStatus) => {
    setDoctors(doctors.map(d => 
      d.id === doctorId ? { ...d, status: newStatus } : d
    ));
  };

  const handleDoctorDetail = (doctor) => {
    setSelectedDoctor(doctor);
    setShowDoctorDetail(true);
  };

  const getDoctorAppointments = (doctorId) => {
    const today = new Date().toISOString().split('T')[0];
    return appointments.filter(apt => 
      apt.doctorId === doctorId && apt.date === today
    ).sort((a, b) => a.time.localeCompare(b.time));
  };

  const getCompletedAppointments = (doctorId) => {
    return getDoctorAppointments(doctorId).filter(apt => apt.status === 'completed');
  };

  const getUpcomingAppointments = (doctorId) => {
    return getDoctorAppointments(doctorId).filter(apt => apt.status === 'upcoming');
  };

  const recentActivities = [
    { id: 1, action: 'Yeni doktor kaydı onaylandı', user: 'Dr. Ayşe Demir', time: '5 dakika önce', type: 'success' },
    { id: 2, action: 'Sistem yedekleme tamamlandı', user: 'Sistem', time: '1 saat önce', type: 'info' },
    { id: 3, action: 'Kritik güvenlik uyarısı', user: 'Güvenlik Sistemi', time: '2 saat önce', type: 'warning' },
    { id: 4, action: 'Hasta verisi güncellendi', user: 'Dr. Mehmet Kaya', time: '3 saat önce', type: 'success' },
    { id: 5, action: 'Yeni kullanıcı kaydı', user: 'Hasta: Ahmet Yılmaz', time: '4 saat önce', type: 'info' }
  ];

  const renderDashboard = () => (
    <div className="admin-dashboard">
      <div className="admin-stats-grid">
        <div className="admin-stat-card">
          <div className="stat-icon">
            <Users size={24} />
          </div>
          <div className="stat-content">
            <h3>{adminStats.totalUsers}</h3>
            <p>Toplam Kullanıcı</p>
          </div>
        </div>
        
        <div className="admin-stat-card">
          <div className="stat-icon">
            <Activity size={24} />
          </div>
          <div className="stat-content">
            <h3>{adminStats.activeDoctors}</h3>
            <p>Aktif Doktor</p>
          </div>
        </div>
        
        <div className="admin-stat-card">
          <div className="stat-icon">
            <FileText size={24} />
          </div>
          <div className="stat-content">
            <h3>{adminStats.totalPatients}</h3>
            <p>Toplam Hasta</p>
          </div>
        </div>
        
        <div className="admin-stat-card">
          <div className="stat-icon">
            <BarChart3 size={24} />
          </div>
          <div className="stat-content">
            <h3>{adminStats.systemUptime}</h3>
            <p>Sistem Uptime</p>
          </div>
        </div>
      </div>

      <div className="admin-activity-section">
        <h4>Son Aktiviteler</h4>
        <div className="activity-list">
          {recentActivities.map(activity => (
            <div key={activity.id} className={`activity-item ${activity.type}`}>
              <div className="activity-content">
                <p className="activity-action">{activity.action}</p>
                <p className="activity-user">{activity.user} • {activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderDoctors = () => (
    <div className="admin-doctors">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h4>Doktor Yönetimi</h4>
        <button 
          className="btn btn-primary"
          onClick={handleAddDoctor}
        >
          + Yeni Doktor Ekle
        </button>
      </div>

      <div className="doctors-grid">
        {doctors.map(doctor => (
          <div key={doctor.id} className="doctor-card">
            <div className="doctor-header">
              <div className="doctor-info">
                <h5>{doctor.name}</h5>
                <p className="text-muted">{doctor.department}</p>
              </div>
              <div className="doctor-status">
                <span className={`badge ${doctor.status === 'active' ? 'bg-success' : 'bg-secondary'}`}>
                  {doctor.status === 'active' ? 'Aktif' : 'Pasif'}
                </span>
              </div>
            </div>
            
            <div className="doctor-details">
              <p><strong>Email:</strong> {doctor.email}</p>
              <p><strong>Telefon:</strong> {doctor.phone}</p>
              <p><strong>Hasta Sayısı:</strong> {doctor.patients}</p>
              <div className="appointment-summary">
                <div className="appointment-count">
                  <span className="count-number">{getDoctorAppointments(doctor.id).length}</span>
                  <span className="count-label">Bugünkü Randevu</span>
                </div>
                <div className="appointment-breakdown">
                  <span className="completed-count">✅ {getCompletedAppointments(doctor.id).length}</span>
                  <span className="upcoming-count">⏰ {getUpcomingAppointments(doctor.id).length}</span>
                </div>
              </div>
            </div>
            
            <div className="doctor-actions">
              <button 
                className="btn btn-sm btn-info"
                onClick={() => handleDoctorDetail(doctor)}
              >
                📅 Günlük Program
              </button>
              <button 
                className="btn btn-sm btn-outline-primary"
                onClick={() => handleEditDoctor(doctor)}
              >
                Düzenle
              </button>
              <button 
                className={`btn btn-sm ${doctor.status === 'active' ? 'btn-warning' : 'btn-success'}`}
                onClick={() => handleDoctorStatusChange(doctor.id, doctor.status === 'active' ? 'inactive' : 'active')}
              >
                {doctor.status === 'active' ? 'Pasif Yap' : 'Aktif Yap'}
              </button>
              <button 
                className="btn btn-sm btn-outline-danger"
                onClick={() => handleDeleteDoctor(doctor.id)}
              >
                Sil
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderDoctorDetail = () => {
    if (!selectedDoctor) return null;
    
    const completedAppointments = getCompletedAppointments(selectedDoctor.id);
    const upcomingAppointments = getUpcomingAppointments(selectedDoctor.id);
    const today = new Date().toLocaleDateString('tr-TR', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });

    return (
      <div className="doctor-detail-modal">
        <div className="modal-overlay">
          <div className="modal-content doctor-detail-content">
            <div className="modal-header">
              <h5>👨‍⚕️ {selectedDoctor.name} - Günlük Program</h5>
              <button 
                className="btn-close"
                onClick={() => setShowDoctorDetail(false)}
              >×</button>
            </div>
            <div className="modal-body">
              <div className="doctor-info-header">
                <div className="doctor-basic-info">
                  <h6><strong>Bölüm:</strong> {selectedDoctor.department}</h6>
                  <h6><strong>Email:</strong> {selectedDoctor.email}</h6>
                  <h6><strong>Telefon:</strong> {selectedDoctor.phone}</h6>
                  <h6><strong>Tarih:</strong> {today}</h6>
                </div>
                <div className="appointment-stats">
                  <div className="stat-item completed">
                    <span className="stat-number">{completedAppointments.length}</span>
                    <span className="stat-label">Tamamlanan</span>
                  </div>
                  <div className="stat-item upcoming">
                    <span className="stat-number">{upcomingAppointments.length}</span>
                    <span className="stat-label">Bekleyen</span>
                  </div>
                </div>
              </div>

              <div className="appointments-section">
                <div className="completed-appointments">
                  <h6 className="section-title">✅ Tamamlanan Randevular</h6>
                  {completedAppointments.length > 0 ? (
                    <div className="appointments-list">
                      {completedAppointments.map(appointment => (
                        <div key={appointment.id} className="appointment-item completed">
                          <div className="appointment-time">{appointment.time}</div>
                          <div className="appointment-details">
                            <div className="patient-name">{appointment.patientName}</div>
                            <div className="appointment-notes">{appointment.notes}</div>
                          </div>
                          <div className="appointment-status">
                            <span className="badge bg-success">Tamamlandı</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="no-appointments">Bugün tamamlanan randevu bulunmuyor.</p>
                  )}
                </div>

                <div className="upcoming-appointments">
                  <h6 className="section-title">⏰ Bekleyen Randevular</h6>
                  {upcomingAppointments.length > 0 ? (
                    <div className="appointments-list">
                      {upcomingAppointments.map(appointment => (
                        <div key={appointment.id} className="appointment-item upcoming">
                          <div className="appointment-time">{appointment.time}</div>
                          <div className="appointment-details">
                            <div className="patient-name">{appointment.patientName}</div>
                            <div className="appointment-notes">{appointment.notes}</div>
                          </div>
                          <div className="appointment-status">
                            <span className="badge bg-warning">Bekliyor</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="no-appointments">Bugün bekleyen randevu bulunmuyor.</p>
                  )}
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button 
                className="btn btn-secondary"
                onClick={() => setShowDoctorDetail(false)}
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderReports = () => {
    // Rapor verilerini hesapla
    const totalAppointments = appointments.length;
    const completedAppointments = appointments.filter(apt => apt.status === 'completed').length;
    const upcomingAppointments = appointments.filter(apt => apt.status === 'upcoming').length;
    const completionRate = totalAppointments > 0 ? Math.round((completedAppointments / totalAppointments) * 100) : 0;

    // Finansal veriler (demo)
    const today = new Date();
    const currentMonth = today.getMonth() + 1;
    const currentYear = today.getFullYear();
    
    // Aylık gelir-gider hesaplamaları
    const monthlyRevenue = {
      'Ocak': 125000, 'Şubat': 138000, 'Mart': 142000, 'Nisan': 135000, 'Mayıs': 148000, 'Haziran': 155000,
      'Temmuz': 162000, 'Ağustos': 158000, 'Eylül': 145000, 'Ekim': 152000, 'Kasım': 148000, 'Aralık': 165000
    };
    
    const monthlyExpenses = {
      'Ocak': 95000, 'Şubat': 102000, 'Mart': 108000, 'Nisan': 101000, 'Mayıs': 112000, 'Haziran': 118000,
      'Temmuz': 125000, 'Ağustos': 122000, 'Eylül': 110000, 'Ekim': 115000, 'Kasım': 112000, 'Aralık': 128000
    };

    const monthNames = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
    const currentMonthName = monthNames[currentMonth - 1];
    
    const currentRevenue = monthlyRevenue[currentMonthName];
    const currentExpenses = monthlyExpenses[currentMonthName];
    const currentProfit = currentRevenue - currentExpenses;
    const profitMargin = Math.round((currentProfit / currentRevenue) * 100);

    // Gelir kaynakları
    const revenueSources = [
      { source: 'Muayene Ücretleri', amount: Math.round(currentRevenue * 0.4), percentage: 40 },
      { source: 'Ameliyat Ücretleri', amount: Math.round(currentRevenue * 0.25), percentage: 25 },
      { source: 'Laboratuvar Testleri', amount: Math.round(currentRevenue * 0.15), percentage: 15 },
      { source: 'Görüntüleme Hizmetleri', amount: Math.round(currentRevenue * 0.12), percentage: 12 },
      { source: 'Yatış Ücretleri', amount: Math.round(currentRevenue * 0.08), percentage: 8 }
    ];

    // Gider kategorileri
    const expenseCategories = [
      { category: 'Personel Maaşları', amount: Math.round(currentExpenses * 0.45), percentage: 45 },
      { category: 'Tıbbi Malzemeler', amount: Math.round(currentExpenses * 0.20), percentage: 20 },
      { category: 'Enerji ve Altyapı', amount: Math.round(currentExpenses * 0.15), percentage: 15 },
      { category: 'Teknoloji ve IT', amount: Math.round(currentExpenses * 0.10), percentage: 10 },
      { category: 'Bakım ve Onarım', amount: Math.round(currentExpenses * 0.10), percentage: 10 }
    ];

    // Son 6 ayın finansal performansı
    const last6Months = monthNames.slice(Math.max(0, currentMonth - 6), currentMonth);
    const financialHistory = last6Months.map(month => ({
      month,
      revenue: monthlyRevenue[month],
      expenses: monthlyExpenses[month],
      profit: monthlyRevenue[month] - monthlyExpenses[month]
    }));

    // Hastane operasyonel verileri
    const hospitalCapacity = 500; // Toplam yatak sayısı
    const occupiedBeds = Math.floor(Math.random() * 50) + 350; // 350-400 arası dolu yatak
    const availableBeds = hospitalCapacity - occupiedBeds;
    const occupancyRate = Math.round((occupiedBeds / hospitalCapacity) * 100);
    
    // Bölümlere göre doluluk oranları
    const departmentOccupancy = [
      { name: 'Kardiyoloji', total: 80, occupied: Math.floor(Math.random() * 20) + 60, color: '#ef4444' },
      { name: 'Nöroloji', total: 60, occupied: Math.floor(Math.random() * 15) + 45, color: '#f59e0b' },
      { name: 'Ortopedi', total: 70, occupied: Math.floor(Math.random() * 18) + 52, color: '#10b981' },
      { name: 'Dahiliye', total: 100, occupied: Math.floor(Math.random() * 25) + 75, color: '#3b82f6' },
      { name: 'Göz Hastalıkları', total: 40, occupied: Math.floor(Math.random() * 10) + 30, color: '#8b5cf6' },
      { name: 'Genel Cerrahi', total: 90, occupied: Math.floor(Math.random() * 22) + 68, color: '#ec4899' },
      { name: 'Acil Servis', total: 30, occupied: Math.floor(Math.random() * 8) + 22, color: '#dc2626' },
      { name: 'Yoğun Bakım', total: 30, occupied: Math.floor(Math.random() * 10) + 20, color: '#1f2937' }
    ];

    // Acil servis yoğunluk durumu
    const emergencyStatus = {
      critical: Math.floor(Math.random() * 5) + 2, // Kritik hasta sayısı
      urgent: Math.floor(Math.random() * 8) + 5,  // Acil hasta sayısı
      normal: Math.floor(Math.random() * 15) + 10, // Normal hasta sayısı
      waiting: Math.floor(Math.random() * 12) + 8  // Bekleyen hasta sayısı
    };

    // Ameliyat durumu
    const surgeryStatus = {
      scheduled: Math.floor(Math.random() * 8) + 12, // Planlanan ameliyatlar
      inProgress: Math.floor(Math.random() * 3) + 2, // Devam eden ameliyatlar
      completed: Math.floor(Math.random() * 15) + 25, // Tamamlanan ameliyatlar
      cancelled: Math.floor(Math.random() * 3) + 1   // İptal edilen ameliyatlar
    };

    // Personel durumu
    const staffStatus = {
      doctors: { total: 45, onDuty: Math.floor(Math.random() * 10) + 35, offDuty: 10 },
      nurses: { total: 120, onDuty: Math.floor(Math.random() * 20) + 100, offDuty: 20 },
      technicians: { total: 30, onDuty: Math.floor(Math.random() * 5) + 25, offDuty: 5 },
      support: { total: 60, onDuty: Math.floor(Math.random() * 10) + 50, offDuty: 10 }
    };

    // Ekipman durumu ve detayları
    const equipmentStatus = {
      operational: Math.floor(Math.random() * 10) + 85, // Çalışır durumda
      maintenance: Math.floor(Math.random() * 5) + 8,   // Bakımda
      outOfOrder: Math.floor(Math.random() * 3) + 2     // Arızalı
    };

    // Detaylı ekipman listesi
    const equipmentList = [
      // Çalışır durumda ekipmanlar
      { id: 'EQ001', name: 'MR Cihazı', type: 'Görüntüleme', location: 'Radyoloji', status: 'operational', lastMaintenance: '2024-01-15', nextMaintenance: '2024-04-15', manufacturer: 'Siemens', model: 'Magnetom Aera', serialNumber: 'MR-2024-001' },
      { id: 'EQ002', name: 'CT Cihazı', type: 'Görüntüleme', location: 'Radyoloji', status: 'operational', lastMaintenance: '2024-01-10', nextMaintenance: '2024-04-10', manufacturer: 'GE Healthcare', model: 'Revolution CT', serialNumber: 'CT-2024-002' },
      { id: 'EQ003', name: 'Ultrason Cihazı', type: 'Görüntüleme', location: 'Kardiyoloji', status: 'operational', lastMaintenance: '2024-01-20', nextMaintenance: '2024-04-20', manufacturer: 'Philips', model: 'EPIQ 7', serialNumber: 'US-2024-003' },
      { id: 'EQ004', name: 'EKG Cihazı', type: 'Kardiyoloji', location: 'Kardiyoloji', status: 'operational', lastMaintenance: '2024-01-05', nextMaintenance: '2024-04-05', manufacturer: 'Schiller', model: 'AT-102', serialNumber: 'EKG-2024-004' },
      { id: 'EQ005', name: 'Ventilatör', type: 'Yoğun Bakım', location: 'Yoğun Bakım', status: 'operational', lastMaintenance: '2024-01-12', nextMaintenance: '2024-04-12', manufacturer: 'Hamilton Medical', model: 'C3', serialNumber: 'VENT-2024-005' },
      
      // Bakımda ekipmanlar
      { id: 'EQ006', name: 'Anestezi Cihazı', type: 'Anestezi', location: 'Ameliyathane 1', status: 'maintenance', lastMaintenance: '2024-01-25', nextMaintenance: '2024-02-25', manufacturer: 'Drager', model: 'Primus', serialNumber: 'ANES-2024-006', maintenanceReason: 'Rutin bakım', estimatedCompletion: '2024-01-28' },
      { id: 'EQ007', name: 'Diyaliz Cihazı', type: 'Nefroloji', location: 'Diyaliz Ünitesi', status: 'maintenance', lastMaintenance: '2024-01-22', nextMaintenance: '2024-02-22', manufacturer: 'Fresenius', model: '4008S', serialNumber: 'DIA-2024-007', maintenanceReason: 'Kalibrasyon', estimatedCompletion: '2024-01-26' },
      { id: 'EQ008', name: 'Endoskopi Cihazı', type: 'Gastroenteroloji', location: 'Endoskopi Ünitesi', status: 'maintenance', lastMaintenance: '2024-01-18', nextMaintenance: '2024-02-18', manufacturer: 'Olympus', model: 'EVIS EXERA III', serialNumber: 'ENDO-2024-008', maintenanceReason: 'Lens değişimi', estimatedCompletion: '2024-01-24' },
      
      // Arızalı ekipmanlar
      { id: 'EQ009', name: 'Röntgen Cihazı', type: 'Görüntüleme', location: 'Radyoloji', status: 'outOfOrder', lastMaintenance: '2024-01-08', nextMaintenance: '2024-02-08', manufacturer: 'Siemens', model: 'Mobilett Mira Max', serialNumber: 'XRAY-2024-009', faultDescription: 'X-ışını tüpü arızası', reportedDate: '2024-01-26', estimatedRepair: '2024-01-30', priority: 'Yüksek' },
      { id: 'EQ010', name: 'Defibrilatör', type: 'Acil', location: 'Acil Servis', status: 'outOfOrder', lastMaintenance: '2024-01-03', nextMaintenance: '2024-02-03', manufacturer: 'Philips', model: 'HeartStart MRx', serialNumber: 'DEF-2024-010', faultDescription: 'Batarya arızası', reportedDate: '2024-01-25', estimatedRepair: '2024-01-29', priority: 'Kritik' },
      { id: 'EQ011', name: 'Monitör', type: 'Yoğun Bakım', location: 'Yoğun Bakım', status: 'outOfOrder', lastMaintenance: '2024-01-15', nextMaintenance: '2024-02-15', manufacturer: 'Philips', model: 'IntelliVue MP70', serialNumber: 'MON-2024-011', faultDescription: 'Ekran görüntü sorunu', reportedDate: '2024-01-24', estimatedRepair: '2024-01-28', priority: 'Orta' }
    ];

    // Hasta akışı (son 24 saat)
    const patientFlow = {
      admissions: Math.floor(Math.random() * 20) + 30,  // Yatışlar
      discharges: Math.floor(Math.random() * 18) + 28,  // Taburcular
      transfers: Math.floor(Math.random() * 8) + 5,     // Transferler
      emergency: Math.floor(Math.random() * 15) + 25    // Acil girişler
    };
    
    // Bölümlere göre randevu dağılımı
    const departmentStats = doctors.map(doctor => {
      const doctorAppointments = appointments.filter(apt => apt.doctorId === doctor.id);
      return {
        department: doctor.department,
        totalAppointments: doctorAppointments.length,
        completedAppointments: doctorAppointments.filter(apt => apt.status === 'completed').length,
        upcomingAppointments: doctorAppointments.filter(apt => apt.status === 'upcoming').length,
        doctorName: doctor.name
      };
    });

    // En yoğun saatler
    const hourlyStats = {};
    appointments.forEach(apt => {
      const hour = apt.time.split(':')[0];
      hourlyStats[hour] = (hourlyStats[hour] || 0) + 1;
    });
    const busiestHours = Object.entries(hourlyStats)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5);

    // Hasta analizi
    const patientStats = {};
    appointments.forEach(apt => {
      patientStats[apt.patientName] = (patientStats[apt.patientName] || 0) + 1;
    });
    const frequentPatients = Object.entries(patientStats)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5);

    return (
      <div className="admin-reports">
        <div className="reports-header">
          <h4>📊 Hastane Raporları ve Analitik</h4>
          <p className="text-muted">Günlük performans ve istatistikler</p>
        </div>

        {/* Genel İstatistikler */}
        <div className="reports-section">
          <h5>📈 Genel İstatistikler</h5>
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-icon">📅</div>
              <div className="stat-content">
                <h3>{totalAppointments}</h3>
                <p>Toplam Randevu</p>
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-icon">✅</div>
              <div className="stat-content">
                <h3>{completedAppointments}</h3>
                <p>Tamamlanan</p>
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-icon">⏰</div>
              <div className="stat-content">
                <h3>{upcomingAppointments}</h3>
                <p>Bekleyen</p>
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-icon">📊</div>
              <div className="stat-content">
                <h3>{completionRate}%</h3>
                <p>Tamamlanma Oranı</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bölüm Analizi */}
        <div className="reports-section">
          <h5>🏥 Bölüm Analizi</h5>
          <div className="department-stats">
            {departmentStats.map((dept, index) => (
              <div key={index} className="department-card">
                <div className="department-header">
                  <h6>{dept.department}</h6>
                  <span className="doctor-name">{dept.doctorName}</span>
                </div>
                <div className="department-metrics">
                  <div className="metric">
                    <span className="metric-label">Toplam:</span>
                    <span className="metric-value">{dept.totalAppointments}</span>
                  </div>
                  <div className="metric">
                    <span className="metric-label">Tamamlanan:</span>
                    <span className="metric-value completed">{dept.completedAppointments}</span>
                  </div>
                  <div className="metric">
                    <span className="metric-label">Bekleyen:</span>
                    <span className="metric-value upcoming">{dept.upcomingAppointments}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* En Yoğun Saatler */}
        <div className="reports-section">
          <h5>⏰ En Yoğun Saatler</h5>
          <div className="hourly-stats">
            {busiestHours.map(([hour, count], index) => (
              <div key={hour} className="hour-stat">
                <div className="hour-time">{hour}:00</div>
                <div className="hour-bar">
                  <div 
                    className="hour-fill" 
                    style={{ width: `${(count / Math.max(...busiestHours.map(([,c]) => c))) * 100}%` }}
                  ></div>
                </div>
                <div className="hour-count">{count} randevu</div>
              </div>
            ))}
          </div>
        </div>

        {/* Sık Gelen Hastalar */}
        <div className="reports-section">
          <h5>👥 Sık Gelen Hastalar</h5>
          <div className="patient-stats">
            {frequentPatients.map(([patient, count], index) => (
              <div key={patient} className="patient-item">
                <div className="patient-rank">#{index + 1}</div>
                <div className="patient-name">{patient}</div>
                <div className="patient-count">{count} randevu</div>
              </div>
            ))}
          </div>
        </div>

        {/* Performans Özeti */}
        <div className="reports-section">
          <h5>🎯 Performans Özeti</h5>
          <div className="performance-summary">
            <div className="performance-item">
              <div className="performance-label">Günlük Hedef</div>
              <div className="performance-value">100 randevu</div>
              <div className="performance-progress">
                <div 
                  className="progress-bar" 
                  style={{ width: `${Math.min((totalAppointments / 100) * 100, 100)}%` }}
                ></div>
              </div>
            </div>
            <div className="performance-item">
              <div className="performance-label">Verimlilik</div>
              <div className="performance-value">{completionRate}%</div>
              <div className="performance-status">
                {completionRate >= 80 ? '🟢 Mükemmel' : completionRate >= 60 ? '🟡 İyi' : '🔴 Geliştirilmeli'}
              </div>
            </div>
            <div className="performance-item">
              <div className="performance-label">Aktif Doktor</div>
              <div className="performance-value">{doctors.filter(d => d.status === 'active').length}</div>
              <div className="performance-status">👨‍⚕️ Çalışıyor</div>
            </div>
          </div>
        </div>

        {/* Finansal Raporlar */}
        <div className="reports-section">
          <h5>💰 Finansal Durum - {currentMonthName} {currentYear}</h5>
          <div className="financial-overview">
            <div className="financial-cards">
              <div className="financial-card revenue">
                <div className="financial-icon">💵</div>
                <div className="financial-content">
                  <h3>₺{currentRevenue.toLocaleString()}</h3>
                  <p>Aylık Gelir</p>
                </div>
              </div>
              <div className="financial-card expense">
                <div className="financial-icon">💸</div>
                <div className="financial-content">
                  <h3>₺{currentExpenses.toLocaleString()}</h3>
                  <p>Aylık Gider</p>
                </div>
              </div>
              <div className="financial-card profit">
                <div className="financial-icon">📈</div>
                <div className="financial-content">
                  <h3>₺{currentProfit.toLocaleString()}</h3>
                  <p>Net Kar</p>
                </div>
              </div>
              <div className="financial-card margin">
                <div className="financial-icon">📊</div>
                <div className="financial-content">
                  <h3>{profitMargin}%</h3>
                  <p>Kar Marjı</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Gelir Kaynakları */}
        <div className="reports-section">
          <h5>💎 Gelir Kaynakları Analizi</h5>
          <div className="revenue-sources">
            {revenueSources.map((source, index) => (
              <div key={index} className="revenue-item">
                <div className="revenue-info">
                  <span className="revenue-source">{source.source}</span>
                  <span className="revenue-percentage">{source.percentage}%</span>
                </div>
                <div className="revenue-amount">₺{source.amount.toLocaleString()}</div>
                <div className="revenue-bar">
                  <div 
                    className="revenue-fill" 
                    style={{ width: `${source.percentage}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Gider Kategorileri */}
        <div className="reports-section">
          <h5>📉 Gider Kategorileri</h5>
          <div className="expense-categories">
            {expenseCategories.map((category, index) => (
              <div key={index} className="expense-item">
                <div className="expense-info">
                  <span className="expense-category">{category.category}</span>
                  <span className="expense-percentage">{category.percentage}%</span>
                </div>
                <div className="expense-amount">₺{category.amount.toLocaleString()}</div>
                <div className="expense-bar">
                  <div 
                    className="expense-fill" 
                    style={{ width: `${category.percentage}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Finansal Geçmiş */}
        <div className="reports-section">
          <h5>📅 Son 6 Ay Finansal Performans</h5>
          <div className="financial-history">
            <div className="history-chart">
              {financialHistory.map((month, index) => (
                <div key={month.month} className="month-bar">
                  <div className="month-name">{month.month}</div>
                  <div className="month-bars">
                    <div className="bar-group">
                      <div 
                        className="bar revenue-bar" 
                        style={{ height: `${(month.revenue / Math.max(...financialHistory.map(m => m.revenue))) * 100}%` }}
                        title={`Gelir: ₺${month.revenue.toLocaleString()}`}
                      ></div>
                      <div 
                        className="bar expense-bar" 
                        style={{ height: `${(month.expenses / Math.max(...financialHistory.map(m => m.expenses))) * 100}%` }}
                        title={`Gider: ₺${month.expenses.toLocaleString()}`}
                      ></div>
                    </div>
                    <div className="month-profit">
                      <span className={month.profit > 0 ? 'profit-positive' : 'profit-negative'}>
                        ₺{month.profit.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="chart-legend">
              <div className="legend-item">
                <div className="legend-color revenue-color"></div>
                <span>Gelir</span>
              </div>
              <div className="legend-item">
                <div className="legend-color expense-color"></div>
                <span>Gider</span>
              </div>
            </div>
          </div>
        </div>

        {/* Hastane Operasyonel Durumu */}
        <div className="reports-section">
          <h5>🏥 Hastane Operasyonel Durumu</h5>
          <div className="operational-overview">
            <div className="operational-cards">
              <div className="operational-card occupancy">
                <div className="operational-icon">🛏️</div>
                <div className="operational-content">
                  <h3>{occupancyRate}%</h3>
                  <p>Doluluk Oranı</p>
                  <div className="operational-details">
                    <span className="detail-item">Dolu: {occupiedBeds}</span>
                    <span className="detail-item">Boş: {availableBeds}</span>
                    <span className="detail-item">Toplam: {hospitalCapacity}</span>
                  </div>
                </div>
              </div>
              <div className="operational-card emergency">
                <div className="operational-icon">🚨</div>
                <div className="operational-content">
                  <h3>{emergencyStatus.critical + emergencyStatus.urgent}</h3>
                  <p>Acil Hasta</p>
                  <div className="operational-details">
                    <span className="detail-item critical">Kritik: {emergencyStatus.critical}</span>
                    <span className="detail-item urgent">Acil: {emergencyStatus.urgent}</span>
                    <span className="detail-item">Bekleyen: {emergencyStatus.waiting}</span>
                  </div>
                </div>
              </div>
              <div className="operational-card surgery">
                <div className="operational-icon">⚕️</div>
                <div className="operational-content">
                  <h3>{surgeryStatus.inProgress}</h3>
                  <p>Devam Eden Ameliyat</p>
                  <div className="operational-details">
                    <span className="detail-item">Planlanan: {surgeryStatus.scheduled}</span>
                    <span className="detail-item">Tamamlanan: {surgeryStatus.completed}</span>
                    <span className="detail-item">İptal: {surgeryStatus.cancelled}</span>
                  </div>
                </div>
              </div>
              <div className="operational-card staff">
                <div className="operational-icon">👥</div>
                <div className="operational-content">
                  <h3>{staffStatus.doctors.onDuty + staffStatus.nurses.onDuty}</h3>
                  <p>Görevde Personel</p>
                  <div className="operational-details">
                    <span className="detail-item">Doktor: {staffStatus.doctors.onDuty}</span>
                    <span className="detail-item">Hemşire: {staffStatus.nurses.onDuty}</span>
                    <span className="detail-item">Teknisyen: {staffStatus.technicians.onDuty}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bölüm Doluluk Oranları */}
        <div className="reports-section">
          <h5>📊 Bölüm Doluluk Oranları</h5>
          <div className="department-occupancy">
            {departmentOccupancy.map((dept, index) => {
              const occupancyPercent = Math.round((dept.occupied / dept.total) * 100);
              return (
                <div key={index} className="occupancy-item">
                  <div className="occupancy-header">
                    <span className="department-name">{dept.name}</span>
                    <span className="occupancy-percentage">{occupancyPercent}%</span>
                  </div>
                  <div className="occupancy-bar">
                    <div 
                      className="occupancy-fill" 
                      style={{ 
                        width: `${occupancyPercent}%`,
                        backgroundColor: dept.color
                      }}
                    ></div>
                  </div>
                  <div className="occupancy-details">
                    <span className="bed-count">Dolu: {dept.occupied}</span>
                    <span className="bed-count">Boş: {dept.total - dept.occupied}</span>
                    <span className="bed-count">Toplam: {dept.total}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Hasta Akışı */}
        <div className="reports-section">
          <h5>🔄 Hasta Akışı (Son 24 Saat)</h5>
          <div className="patient-flow">
            <div className="flow-cards">
              <div className="flow-card admissions">
                <div className="flow-icon">📥</div>
                <div className="flow-content">
                  <h3>{patientFlow.admissions}</h3>
                  <p>Yatışlar</p>
                </div>
              </div>
              <div className="flow-card discharges">
                <div className="flow-icon">📤</div>
                <div className="flow-content">
                  <h3>{patientFlow.discharges}</h3>
                  <p>Taburcular</p>
                </div>
              </div>
              <div className="flow-card transfers">
                <div className="flow-icon">🔄</div>
                <div className="flow-content">
                  <h3>{patientFlow.transfers}</h3>
                  <p>Transferler</p>
                </div>
              </div>
              <div className="flow-card emergency">
                <div className="flow-icon">🚨</div>
                <div className="flow-content">
                  <h3>{patientFlow.emergency}</h3>
                  <p>Acil Girişler</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Ekipman Durumu */}
        <div className="reports-section">
          <h5>🔧 Ekipman Durumu</h5>
          <div className="equipment-status">
            <div className="equipment-cards">
              <div 
                className="equipment-card operational clickable"
                onClick={() => {
                  const operationalEquipments = equipmentList.filter(eq => eq.status === 'operational');
                  if (operationalEquipments.length > 0) {
                    handleEquipmentClick(operationalEquipments[0]);
                  }
                }}
              >
                <div className="equipment-icon">✅</div>
                <div className="equipment-content">
                  <h3>{equipmentStatus.operational}%</h3>
                  <p>Çalışır Durumda</p>
                  <small className="equipment-count">
                    {equipmentList.filter(eq => eq.status === 'operational').length} ekipman
                  </small>
                </div>
              </div>
              <div 
                className="equipment-card maintenance clickable"
                onClick={() => {
                  const maintenanceEquipments = equipmentList.filter(eq => eq.status === 'maintenance');
                  if (maintenanceEquipments.length > 0) {
                    handleEquipmentClick(maintenanceEquipments[0]);
                  }
                }}
              >
                <div className="equipment-icon">🔧</div>
                <div className="equipment-content">
                  <h3>{equipmentStatus.maintenance}%</h3>
                  <p>Bakımda</p>
                  <small className="equipment-count">
                    {equipmentList.filter(eq => eq.status === 'maintenance').length} ekipman
                  </small>
                </div>
              </div>
              <div 
                className="equipment-card out-of-order clickable"
                onClick={() => {
                  const outOfOrderEquipments = equipmentList.filter(eq => eq.status === 'outOfOrder');
                  if (outOfOrderEquipments.length > 0) {
                    handleEquipmentClick(outOfOrderEquipments[0]);
                  }
                }}
              >
                <div className="equipment-icon">❌</div>
                <div className="equipment-content">
                  <h3>{equipmentStatus.outOfOrder}%</h3>
                  <p>Arızalı</p>
                  <small className="equipment-count">
                    {equipmentList.filter(eq => eq.status === 'outOfOrder').length} ekipman
                  </small>
                </div>
              </div>
            </div>
            <div className="equipment-chart">
              <div className="equipment-bar">
                <div 
                  className="equipment-fill operational" 
                  style={{ width: `${equipmentStatus.operational}%` }}
                ></div>
                <div 
                  className="equipment-fill maintenance" 
                  style={{ width: `${equipmentStatus.maintenance}%` }}
                ></div>
                <div 
                  className="equipment-fill out-of-order" 
                  style={{ width: `${equipmentStatus.outOfOrder}%` }}
                ></div>
              </div>
            </div>
            
            {/* Ekipman Listesi */}
            <div className="equipment-list">
              <h6>📋 Ekipman Listesi</h6>
              <div className="equipment-items">
                {equipmentList.map((equipment) => {
                  const statusInfo = equipment.status === 'operational' ? 
                    { text: 'Çalışır', color: '#10b981' } :
                    equipment.status === 'maintenance' ? 
                    { text: 'Bakımda', color: '#f59e0b' } :
                    { text: 'Arızalı', color: '#dc2626' };
                  
                  return (
                    <div 
                      key={equipment.id} 
                      className="equipment-item clickable"
                      onClick={() => handleEquipmentClick(equipment)}
                    >
                      <div className="equipment-item-info">
                        <span className="equipment-name">{equipment.name}</span>
                        <span className="equipment-location">{equipment.location}</span>
                      </div>
                      <div className="equipment-item-status">
                        <span 
                          className="status-indicator"
                          style={{ color: statusInfo.color }}
                        >
                          {statusInfo.text}
                        </span>
                        <span className="equipment-type">{equipment.type}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Personel Durumu Detayı */}
        <div className="reports-section">
          <h5>👥 Personel Durumu</h5>
          <div className="staff-details">
            {Object.entries(staffStatus).map(([role, data]) => {
              const onDutyPercent = Math.round((data.onDuty / data.total) * 100);
              return (
                <div key={role} className="staff-item">
                  <div className="staff-info">
                    <span className="staff-role">{role.charAt(0).toUpperCase() + role.slice(1)}</span>
                    <span className="staff-percentage">{onDutyPercent}% Görevde</span>
                  </div>
                  <div className="staff-bar">
                    <div 
                      className="staff-fill" 
                      style={{ width: `${onDutyPercent}%` }}
                    ></div>
                  </div>
                  <div className="staff-counts">
                    <span className="count-item on-duty">Görevde: {data.onDuty}</span>
                    <span className="count-item off-duty">İzinli: {data.offDuty}</span>
                    <span className="count-item total">Toplam: {data.total}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  const handleEquipmentClick = (equipment) => {
    setSelectedEquipment(equipment);
    setShowEquipmentDetail(true);
  };

  const renderEquipmentDetail = () => {
    if (!selectedEquipment) return null;

    const getStatusInfo = (status) => {
      switch (status) {
        case 'operational':
          return { text: 'Çalışır Durumda', color: '#10b981', bgColor: '#ecfdf5' };
        case 'maintenance':
          return { text: 'Bakımda', color: '#f59e0b', bgColor: '#fffbeb' };
        case 'outOfOrder':
          return { text: 'Arızalı', color: '#dc2626', bgColor: '#fef2f2' };
        default:
          return { text: 'Bilinmiyor', color: '#6b7280', bgColor: '#f9fafb' };
      }
    };

    const statusInfo = getStatusInfo(selectedEquipment.status);

    return (
      <div className="equipment-detail-modal">
        <div className="modal-overlay">
          <div className="modal-content equipment-detail-content">
            <div className="modal-header">
              <h5>🔧 {selectedEquipment.name} - Ekipman Detayları</h5>
              <button 
                className="btn-close"
                onClick={() => setShowEquipmentDetail(false)}
              >×</button>
            </div>
            <div className="modal-body">
              <div className="equipment-detail-grid">
                {/* Temel Bilgiler */}
                <div className="detail-section">
                  <h6>📋 Temel Bilgiler</h6>
                  <div className="detail-items">
                    <div className="detail-item">
                      <span className="detail-label">Ekipman Adı:</span>
                      <span className="detail-value">{selectedEquipment.name}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Tip:</span>
                      <span className="detail-value">{selectedEquipment.type}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Konum:</span>
                      <span className="detail-value">{selectedEquipment.location}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Durum:</span>
                      <span 
                        className="detail-value status-badge"
                        style={{ 
                          color: statusInfo.color, 
                          backgroundColor: statusInfo.bgColor 
                        }}
                      >
                        {statusInfo.text}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Teknik Bilgiler */}
                <div className="detail-section">
                  <h6>⚙️ Teknik Bilgiler</h6>
                  <div className="detail-items">
                    <div className="detail-item">
                      <span className="detail-label">Üretici:</span>
                      <span className="detail-value">{selectedEquipment.manufacturer}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Model:</span>
                      <span className="detail-value">{selectedEquipment.model}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Seri No:</span>
                      <span className="detail-value">{selectedEquipment.serialNumber}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Ekipman ID:</span>
                      <span className="detail-value">{selectedEquipment.id}</span>
                    </div>
                  </div>
                </div>

                {/* Bakım Bilgileri */}
                <div className="detail-section">
                  <h6>🔧 Bakım Bilgileri</h6>
                  <div className="detail-items">
                    <div className="detail-item">
                      <span className="detail-label">Son Bakım:</span>
                      <span className="detail-value">{selectedEquipment.lastMaintenance}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Sonraki Bakım:</span>
                      <span className="detail-value">{selectedEquipment.nextMaintenance}</span>
                    </div>
                    {selectedEquipment.maintenanceReason && (
                      <div className="detail-item">
                        <span className="detail-label">Bakım Nedeni:</span>
                        <span className="detail-value">{selectedEquipment.maintenanceReason}</span>
                      </div>
                    )}
                    {selectedEquipment.estimatedCompletion && (
                      <div className="detail-item">
                        <span className="detail-label">Tahmini Tamamlanma:</span>
                        <span className="detail-value">{selectedEquipment.estimatedCompletion}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Arıza Bilgileri (Sadece arızalı ekipmanlar için) */}
                {selectedEquipment.status === 'outOfOrder' && (
                  <div className="detail-section">
                    <h6>⚠️ Arıza Bilgileri</h6>
                    <div className="detail-items">
                      <div className="detail-item">
                        <span className="detail-label">Arıza Açıklaması:</span>
                        <span className="detail-value">{selectedEquipment.faultDescription}</span>
                      </div>
                      <div className="detail-item">
                        <span className="detail-label">Bildirilme Tarihi:</span>
                        <span className="detail-value">{selectedEquipment.reportedDate}</span>
                      </div>
                      <div className="detail-item">
                        <span className="detail-label">Tahmini Onarım:</span>
                        <span className="detail-value">{selectedEquipment.estimatedRepair}</span>
                      </div>
                      <div className="detail-item">
                        <span className="detail-label">Öncelik:</span>
                        <span 
                          className="detail-value priority-badge"
                          style={{ 
                            color: selectedEquipment.priority === 'Kritik' ? '#dc2626' : 
                                   selectedEquipment.priority === 'Yüksek' ? '#f59e0b' : '#6b7280',
                            backgroundColor: selectedEquipment.priority === 'Kritik' ? '#fef2f2' : 
                                           selectedEquipment.priority === 'Yüksek' ? '#fffbeb' : '#f9fafb'
                          }}
                        >
                          {selectedEquipment.priority}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Eylem Butonları */}
                <div className="detail-actions">
                  {selectedEquipment.status === 'outOfOrder' && (
                    <button 
                      className="btn btn-danger"
                      onClick={() => setShowEmergencyRepair(true)}
                    >
                      🚨 Acil Onarım Talebi
                    </button>
                  )}
                  {selectedEquipment.status === 'maintenance' && (
                    <button className="btn btn-warning">
                      ⏰ Bakım Durumu Güncelle
                    </button>
                  )}
                  <button 
                    className="btn btn-primary"
                    onClick={() => setShowMaintenanceHistory(true)}
                  >
                    📋 Bakım Geçmişi
                  </button>
                  <button 
                    className="btn btn-outline-secondary"
                    onClick={() => setShowTechnicalDocs(true)}
                  >
                    📄 Teknik Dökümanlar
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderMaintenanceHistory = () => {
    if (!selectedEquipment) return null;

    // Demo bakım geçmişi verileri
    const maintenanceHistory = [
      {
        id: 'MH001',
        date: '2024-01-15',
        type: 'Rutin Bakım',
        technician: 'Ahmet Yılmaz',
        description: 'Genel kontrol ve temizlik yapıldı. Tüm sistemler normal çalışıyor.',
        duration: '2 saat',
        status: 'Tamamlandı',
        cost: '₺500'
      },
      {
        id: 'MH002',
        date: '2023-12-10',
        type: 'Kalibrasyon',
        technician: 'Mehmet Kaya',
        description: 'Sensör kalibrasyonu yapıldı. Ölçüm doğruluğu test edildi.',
        duration: '1.5 saat',
        status: 'Tamamlandı',
        cost: '₺300'
      },
      {
        id: 'MH003',
        date: '2023-11-05',
        type: 'Arıza Onarımı',
        technician: 'Ali Demir',
        description: 'Motor arızası tespit edildi ve değiştirildi.',
        duration: '4 saat',
        status: 'Tamamlandı',
        cost: '₺1,200'
      },
      {
        id: 'MH004',
        date: '2023-10-20',
        type: 'Rutin Bakım',
        technician: 'Fatma Özkan',
        description: 'Filtre değişimi ve sistem temizliği.',
        duration: '1 saat',
        status: 'Tamamlandı',
        cost: '₺200'
      }
    ];

    return (
      <div className="maintenance-history-modal">
        <div className="modal-overlay">
          <div className="modal-content maintenance-history-content">
            <div className="modal-header">
              <h5>🔧 {selectedEquipment.name} - Bakım Geçmişi</h5>
              <button 
                className="btn-close"
                onClick={() => setShowMaintenanceHistory(false)}
              >×</button>
            </div>
            <div className="modal-body">
              <div className="maintenance-summary">
                <div className="summary-item">
                  <span className="summary-label">Toplam Bakım:</span>
                  <span className="summary-value">{maintenanceHistory.length} kayıt</span>
                </div>
                <div className="summary-item">
                  <span className="summary-label">Son Bakım:</span>
                  <span className="summary-value">{maintenanceHistory[0].date}</span>
                </div>
                <div className="summary-item">
                  <span className="summary-label">Toplam Maliyet:</span>
                  <span className="summary-value">₺2,200</span>
                </div>
              </div>

              <div className="maintenance-list">
                {maintenanceHistory.map((maintenance) => (
                  <div key={maintenance.id} className="maintenance-item">
                    <div className="maintenance-header">
                      <div className="maintenance-date">
                        <span className="date">{maintenance.date}</span>
                        <span className="type">{maintenance.type}</span>
                      </div>
                      <div className="maintenance-status">
                        <span className={`status ${maintenance.status.toLowerCase()}`}>
                          {maintenance.status}
                        </span>
                      </div>
                    </div>
                    <div className="maintenance-details">
                      <div className="detail-row">
                        <span className="detail-label">Teknisyen:</span>
                        <span className="detail-value">{maintenance.technician}</span>
                      </div>
                      <div className="detail-row">
                        <span className="detail-label">Süre:</span>
                        <span className="detail-value">{maintenance.duration}</span>
                      </div>
                      <div className="detail-row">
                        <span className="detail-label">Maliyet:</span>
                        <span className="detail-value">{maintenance.cost}</span>
                      </div>
                    </div>
                    <div className="maintenance-description">
                      <p>{maintenance.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderTechnicalDocs = () => {
    if (!selectedEquipment) return null;

    // Demo teknik döküman verileri
    const technicalDocs = [
      {
        id: 'TD001',
        name: 'Kullanım Kılavuzu',
        type: 'PDF',
        size: '2.5 MB',
        uploadDate: '2024-01-10',
        version: 'v2.1',
        description: 'Ekipmanın temel kullanım talimatları ve güvenlik önlemleri'
      },
      {
        id: 'TD002',
        name: 'Teknik Şema',
        type: 'DWG',
        size: '1.8 MB',
        uploadDate: '2024-01-08',
        version: 'v1.3',
        description: 'Elektriksel ve mekanik bağlantı şemaları'
      },
      {
        id: 'TD003',
        name: 'Bakım Prosedürleri',
        type: 'PDF',
        size: '3.2 MB',
        uploadDate: '2024-01-05',
        version: 'v1.0',
        description: 'Detaylı bakım ve onarım prosedürleri'
      },
      {
        id: 'TD004',
        name: 'Güvenlik Sertifikası',
        type: 'PDF',
        size: '0.8 MB',
        uploadDate: '2023-12-20',
        version: 'v1.0',
        description: 'CE ve ISO sertifikaları'
      },
      {
        id: 'TD005',
        name: 'Yedek Parça Listesi',
        type: 'XLSX',
        size: '0.5 MB',
        uploadDate: '2023-12-15',
        version: 'v2.0',
        description: 'Yedek parça numaraları ve fiyat listesi'
      }
    ];

    return (
      <div className="technical-docs-modal">
        <div className="modal-overlay">
          <div className="modal-content technical-docs-content">
            <div className="modal-header">
              <h5>📄 {selectedEquipment.name} - Teknik Dökümanlar</h5>
              <button 
                className="btn-close"
                onClick={() => setShowTechnicalDocs(false)}
              >×</button>
            </div>
            <div className="modal-body">
              <div className="docs-summary">
                <div className="summary-item">
                  <span className="summary-label">Toplam Döküman:</span>
                  <span className="summary-value">{technicalDocs.length} dosya</span>
                </div>
                <div className="summary-item">
                  <span className="summary-label">Toplam Boyut:</span>
                  <span className="summary-value">8.8 MB</span>
                </div>
                <div className="summary-item">
                  <span className="summary-label">Son Güncelleme:</span>
                  <span className="summary-value">2024-01-10</span>
                </div>
              </div>

              <div className="docs-list">
                {technicalDocs.map((doc) => (
                  <div key={doc.id} className="doc-item">
                    <div className="doc-icon">
                      {doc.type === 'PDF' ? '📄' : doc.type === 'DWG' ? '📐' : '📊'}
                    </div>
                    <div className="doc-info">
                      <div className="doc-name">{doc.name}</div>
                      <div className="doc-meta">
                        <span className="doc-type">{doc.type}</span>
                        <span className="doc-size">{doc.size}</span>
                        <span className="doc-version">{doc.version}</span>
                        <span className="doc-date">{doc.uploadDate}</span>
                      </div>
                      <div className="doc-description">{doc.description}</div>
                    </div>
                    <div className="doc-actions">
                      <button className="btn btn-sm btn-primary">
                        👁️ Görüntüle
                      </button>
                      <button className="btn btn-sm btn-outline-secondary">
                        ⬇️ İndir
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderEmergencyRepair = () => {
    if (!selectedEquipment) return null;

    return (
      <div className="emergency-repair-modal">
        <div className="modal-overlay">
          <div className="modal-content emergency-repair-content">
            <div className="modal-header">
              <h5>🚨 {selectedEquipment.name} - Acil Onarım Talebi</h5>
              <button 
                className="btn-close"
                onClick={() => setShowEmergencyRepair(false)}
              >×</button>
            </div>
            <div className="modal-body">
              <div className="emergency-info">
                <div className="alert alert-danger">
                  <h6>⚠️ Acil Onarım Talebi Oluşturuldu!</h6>
                  <p>Ekipmanınız için acil onarım talebi başarıyla oluşturuldu ve teknik ekibimize iletildi.</p>
                </div>

                <div className="repair-details">
                  <h6>📋 Talep Detayları</h6>
                  <div className="detail-grid">
                    <div className="detail-item">
                      <span className="detail-label">Talep No:</span>
                      <span className="detail-value">REQ-2024-001</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Ekipman:</span>
                      <span className="detail-value">{selectedEquipment.name}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Konum:</span>
                      <span className="detail-value">{selectedEquipment.location}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Öncelik:</span>
                      <span className="detail-value priority-high">Yüksek</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Tahmini Süre:</span>
                      <span className="detail-value">2-4 saat</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Atanan Teknisyen:</span>
                      <span className="detail-value">Ahmet Yılmaz</span>
                    </div>
                  </div>
                </div>

                <div className="repair-status">
                  <h6>📊 Talep Durumu</h6>
                  <div className="status-timeline">
                    <div className="timeline-item completed">
                      <div className="timeline-marker">✓</div>
                      <div className="timeline-content">
                        <span className="timeline-title">Talep Oluşturuldu</span>
                        <span className="timeline-time">Az önce</span>
                      </div>
                    </div>
                    <div className="timeline-item in-progress">
                      <div className="timeline-marker">⏳</div>
                      <div className="timeline-content">
                        <span className="timeline-title">Teknisyen Atandı</span>
                        <span className="timeline-time">Devam ediyor</span>
                      </div>
                    </div>
                    <div className="timeline-item pending">
                      <div className="timeline-marker">⏸️</div>
                      <div className="timeline-content">
                        <span className="timeline-title">Onarım Başladı</span>
                        <span className="timeline-time">Bekleniyor</span>
                      </div>
                    </div>
                    <div className="timeline-item pending">
                      <div className="timeline-marker">⏸️</div>
                      <div className="timeline-content">
                        <span className="timeline-title">Onarım Tamamlandı</span>
                        <span className="timeline-time">Bekleniyor</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="contact-info">
                  <h6>📞 İletişim Bilgileri</h6>
                  <div className="contact-grid">
                    <div className="contact-item">
                      <span className="contact-label">Teknik Destek:</span>
                      <span className="contact-value">+90 212 555 0123</span>
                    </div>
                    <div className="contact-item">
                      <span className="contact-label">Email:</span>
                      <span className="contact-value">teknik@hastane.com</span>
                    </div>
                    <div className="contact-item">
                      <span className="contact-label">Acil Hat:</span>
                      <span className="contact-value">+90 212 555 9999</span>
                    </div>
                  </div>
                </div>

                <div className="repair-actions">
                  <button className="btn btn-primary">
                    📱 Durum Takibi
                  </button>
                  <button className="btn btn-outline-secondary">
                    📧 Email Gönder
                  </button>
                  <button className="btn btn-outline-info">
                    📋 Talep Detayları
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderSettings = () => {
    const handleSettingChange = (category, key, value) => {
      setSettings(prev => ({
        ...prev,
        [category]: {
          ...prev[category],
          [key]: value
        }
      }));
    };

    const handleSaveSettings = () => {
      // Ayarları kaydetme işlemi
      alert('Ayarlar başarıyla kaydedildi!');
    };

    const handleResetSettings = () => {
      if (window.confirm('Tüm ayarları varsayılan değerlere sıfırlamak istediğinizden emin misiniz?')) {
        // Varsayılan ayarlara dön
        alert('Ayarlar varsayılan değerlere sıfırlandı!');
      }
    };

    return (
      <div className="admin-settings">
        <div className="settings-header">
          <h4>⚙️ Sistem Ayarları</h4>
          <p className="text-muted">Hastane yönetim sistemi ayarlarını yapılandırın</p>
        </div>

        <div className="settings-content">
          {/* Hastane Bilgileri */}
          <div className="settings-section">
            <h5>🏥 Hastane Bilgileri</h5>
            <div className="settings-grid">
              <div className="setting-item">
                <label className="setting-label">Hastane Adı</label>
                <input
                  type="text"
                  className="setting-input"
                  value={settings.hospital.name}
                  onChange={(e) => handleSettingChange('hospital', 'name', e.target.value)}
                />
              </div>
              <div className="setting-item">
                <label className="setting-label">Adres</label>
                <textarea
                  className="setting-textarea"
                  value={settings.hospital.address}
                  onChange={(e) => handleSettingChange('hospital', 'address', e.target.value)}
                  rows="3"
                />
              </div>
              <div className="setting-item">
                <label className="setting-label">Telefon</label>
                <input
                  type="tel"
                  className="setting-input"
                  value={settings.hospital.phone}
                  onChange={(e) => handleSettingChange('hospital', 'phone', e.target.value)}
                />
              </div>
              <div className="setting-item">
                <label className="setting-label">Email</label>
                <input
                  type="email"
                  className="setting-input"
                  value={settings.hospital.email}
                  onChange={(e) => handleSettingChange('hospital', 'email', e.target.value)}
                />
              </div>
              <div className="setting-item">
                <label className="setting-label">Website</label>
                <input
                  type="url"
                  className="setting-input"
                  value={settings.hospital.website}
                  onChange={(e) => handleSettingChange('hospital', 'website', e.target.value)}
                />
              </div>
              <div className="setting-item">
                <label className="setting-label">Lisans No</label>
                <input
                  type="text"
                  className="setting-input"
                  value={settings.hospital.license}
                  onChange={(e) => handleSettingChange('hospital', 'license', e.target.value)}
                />
              </div>
              <div className="setting-item">
                <label className="setting-label">Yatak Kapasitesi</label>
                <input
                  type="number"
                  className="setting-input"
                  value={settings.hospital.capacity}
                  onChange={(e) => handleSettingChange('hospital', 'capacity', parseInt(e.target.value))}
                />
              </div>
            </div>
          </div>

          {/* Sistem Ayarları */}
          <div className="settings-section">
            <h5>💻 Sistem Ayarları</h5>
            <div className="settings-grid">
              <div className="setting-item">
                <label className="setting-label">Saat Dilimi</label>
                <select
                  className="setting-select"
                  value={settings.system.timezone}
                  onChange={(e) => handleSettingChange('system', 'timezone', e.target.value)}
                >
                  <option value="Europe/Istanbul">Türkiye (UTC+3)</option>
                  <option value="Europe/London">Londra (UTC+0)</option>
                  <option value="America/New_York">New York (UTC-5)</option>
                </select>
              </div>
              <div className="setting-item">
                <label className="setting-label">Tarih Formatı</label>
                <select
                  className="setting-select"
                  value={settings.system.dateFormat}
                  onChange={(e) => handleSettingChange('system', 'dateFormat', e.target.value)}
                >
                  <option value="DD/MM/YYYY">GG/AA/YYYY</option>
                  <option value="MM/DD/YYYY">AA/GG/YYYY</option>
                  <option value="YYYY-MM-DD">YYYY-AA-GG</option>
                </select>
              </div>
              <div className="setting-item">
                <label className="setting-label">Saat Formatı</label>
                <select
                  className="setting-select"
                  value={settings.system.timeFormat}
                  onChange={(e) => handleSettingChange('system', 'timeFormat', e.target.value)}
                >
                  <option value="24">24 Saat</option>
                  <option value="12">12 Saat (AM/PM)</option>
                </select>
              </div>
              <div className="setting-item">
                <label className="setting-label">Dil</label>
                <select
                  className="setting-select"
                  value={settings.system.language}
                  onChange={(e) => handleSettingChange('system', 'language', e.target.value)}
                >
                  <option value="tr">Türkçe</option>
                  <option value="en">English</option>
                  <option value="de">Deutsch</option>
                </select>
              </div>
              <div className="setting-item">
                <label className="setting-label">Para Birimi</label>
                <select
                  className="setting-select"
                  value={settings.system.currency}
                  onChange={(e) => handleSettingChange('system', 'currency', e.target.value)}
                >
                  <option value="TRY">₺ Türk Lirası</option>
                  <option value="USD">$ Amerikan Doları</option>
                  <option value="EUR">€ Euro</option>
                </select>
              </div>
              <div className="setting-item">
                <label className="setting-label">Otomatik Yedekleme</label>
                <div className="setting-toggle">
                  <input
                    type="checkbox"
                    checked={settings.system.autoBackup}
                    onChange={(e) => handleSettingChange('system', 'autoBackup', e.target.checked)}
                  />
                  <span className="toggle-label">Aktif</span>
                </div>
              </div>
              <div className="setting-item">
                <label className="setting-label">Yedekleme Sıklığı</label>
                <select
                  className="setting-select"
                  value={settings.system.backupFrequency}
                  onChange={(e) => handleSettingChange('system', 'backupFrequency', e.target.value)}
                >
                  <option value="hourly">Saatlik</option>
                  <option value="daily">Günlük</option>
                  <option value="weekly">Haftalık</option>
                </select>
              </div>
              <div className="setting-item">
                <label className="setting-label">Oturum Zaman Aşımı (dakika)</label>
                <input
                  type="number"
                  className="setting-input"
                  value={settings.system.sessionTimeout}
                  onChange={(e) => handleSettingChange('system', 'sessionTimeout', parseInt(e.target.value))}
                  min="5"
                  max="120"
                />
              </div>
            </div>
          </div>

          {/* Bildirim Ayarları */}
          <div className="settings-section">
            <h5>🔔 Bildirim Ayarları</h5>
            <div className="settings-grid">
              <div className="setting-item">
                <label className="setting-label">Email Bildirimleri</label>
                <div className="setting-toggle">
                  <input
                    type="checkbox"
                    checked={settings.notifications.email}
                    onChange={(e) => handleSettingChange('notifications', 'email', e.target.checked)}
                  />
                  <span className="toggle-label">Aktif</span>
                </div>
              </div>
              <div className="setting-item">
                <label className="setting-label">SMS Bildirimleri</label>
                <div className="setting-toggle">
                  <input
                    type="checkbox"
                    checked={settings.notifications.sms}
                    onChange={(e) => handleSettingChange('notifications', 'sms', e.target.checked)}
                  />
                  <span className="toggle-label">Aktif</span>
                </div>
              </div>
              <div className="setting-item">
                <label className="setting-label">Push Bildirimleri</label>
                <div className="setting-toggle">
                  <input
                    type="checkbox"
                    checked={settings.notifications.push}
                    onChange={(e) => handleSettingChange('notifications', 'push', e.target.checked)}
                  />
                  <span className="toggle-label">Aktif</span>
                </div>
              </div>
              <div className="setting-item">
                <label className="setting-label">Randevu Hatırlatmaları</label>
                <div className="setting-toggle">
                  <input
                    type="checkbox"
                    checked={settings.notifications.appointmentReminder}
                    onChange={(e) => handleSettingChange('notifications', 'appointmentReminder', e.target.checked)}
                  />
                  <span className="toggle-label">Aktif</span>
                </div>
              </div>
              <div className="setting-item">
                <label className="setting-label">Acil Durum Uyarıları</label>
                <div className="setting-toggle">
                  <input
                    type="checkbox"
                    checked={settings.notifications.emergencyAlert}
                    onChange={(e) => handleSettingChange('notifications', 'emergencyAlert', e.target.checked)}
                  />
                  <span className="toggle-label">Aktif</span>
                </div>
              </div>
              <div className="setting-item">
                <label className="setting-label">Sistem Bakım Bildirimleri</label>
                <div className="setting-toggle">
                  <input
                    type="checkbox"
                    checked={settings.notifications.systemMaintenance}
                    onChange={(e) => handleSettingChange('notifications', 'systemMaintenance', e.target.checked)}
                  />
                  <span className="toggle-label">Aktif</span>
                </div>
              </div>
            </div>
          </div>

          {/* Güvenlik Ayarları */}
          <div className="settings-section">
            <h5>🔒 Güvenlik Ayarları</h5>
            <div className="settings-grid">
              <div className="setting-item">
                <label className="setting-label">Şifre Politikası</label>
                <select
                  className="setting-select"
                  value={settings.security.passwordPolicy}
                  onChange={(e) => handleSettingChange('security', 'passwordPolicy', e.target.value)}
                >
                  <option value="weak">Zayıf (6+ karakter)</option>
                  <option value="medium">Orta (8+ karakter, sayı)</option>
                  <option value="strong">Güçlü (12+ karakter, sayı, özel karakter)</option>
                </select>
              </div>
              <div className="setting-item">
                <label className="setting-label">İki Faktörlü Kimlik Doğrulama</label>
                <div className="setting-toggle">
                  <input
                    type="checkbox"
                    checked={settings.security.twoFactorAuth}
                    onChange={(e) => handleSettingChange('security', 'twoFactorAuth', e.target.checked)}
                  />
                  <span className="toggle-label">Aktif</span>
                </div>
              </div>
              <div className="setting-item">
                <label className="setting-label">Maksimum Giriş Denemesi</label>
                <input
                  type="number"
                  className="setting-input"
                  value={settings.security.loginAttempts}
                  onChange={(e) => handleSettingChange('security', 'loginAttempts', parseInt(e.target.value))}
                  min="3"
                  max="10"
                />
              </div>
              <div className="setting-item">
                <label className="setting-label">Oturum Süresi (saat)</label>
                <input
                  type="number"
                  className="setting-input"
                  value={settings.security.sessionDuration}
                  onChange={(e) => handleSettingChange('security', 'sessionDuration', parseInt(e.target.value))}
                  min="1"
                  max="24"
                />
              </div>
              <div className="setting-item">
                <label className="setting-label">IP Beyaz Listesi</label>
                <div className="setting-toggle">
                  <input
                    type="checkbox"
                    checked={settings.security.ipWhitelist}
                    onChange={(e) => handleSettingChange('security', 'ipWhitelist', e.target.checked)}
                  />
                  <span className="toggle-label">Aktif</span>
                </div>
              </div>
              <div className="setting-item">
                <label className="setting-label">Denetim Kayıtları</label>
                <div className="setting-toggle">
                  <input
                    type="checkbox"
                    checked={settings.security.auditLog}
                    onChange={(e) => handleSettingChange('security', 'auditLog', e.target.checked)}
                  />
                  <span className="toggle-label">Aktif</span>
                </div>
              </div>
            </div>
          </div>

          {/* Entegrasyon Ayarları */}
          <div className="settings-section">
            <h5>🔗 Sistem Entegrasyonları</h5>
            <div className="settings-grid">
              <div className="setting-item">
                <label className="setting-label">Laboratuvar Sistemi</label>
                <div className="setting-toggle">
                  <input
                    type="checkbox"
                    checked={settings.integration.labSystem}
                    onChange={(e) => handleSettingChange('integration', 'labSystem', e.target.checked)}
                  />
                  <span className="toggle-label">Aktif</span>
                </div>
              </div>
              <div className="setting-item">
                <label className="setting-label">Eczane Sistemi</label>
                <div className="setting-toggle">
                  <input
                    type="checkbox"
                    checked={settings.integration.pharmacySystem}
                    onChange={(e) => handleSettingChange('integration', 'pharmacySystem', e.target.checked)}
                  />
                  <span className="toggle-label">Aktif</span>
                </div>
              </div>
              <div className="setting-item">
                <label className="setting-label">Sigorta Sistemi</label>
                <div className="setting-toggle">
                  <input
                    type="checkbox"
                    checked={settings.integration.insuranceSystem}
                    onChange={(e) => handleSettingChange('integration', 'insuranceSystem', e.target.checked)}
                  />
                  <span className="toggle-label">Aktif</span>
                </div>
              </div>
              <div className="setting-item">
                <label className="setting-label">Görüntüleme Sistemi</label>
                <div className="setting-toggle">
                  <input
                    type="checkbox"
                    checked={settings.integration.imagingSystem}
                    onChange={(e) => handleSettingChange('integration', 'imagingSystem', e.target.checked)}
                  />
                  <span className="toggle-label">Aktif</span>
                </div>
              </div>
              <div className="setting-item">
                <label className="setting-label">Acil Durum Sistemi</label>
                <div className="setting-toggle">
                  <input
                    type="checkbox"
                    checked={settings.integration.emergencySystem}
                    onChange={(e) => handleSettingChange('integration', 'emergencySystem', e.target.checked)}
                  />
                  <span className="toggle-label">Aktif</span>
                </div>
              </div>
            </div>
          </div>

          {/* Ayarlar Butonları */}
          <div className="settings-actions">
            <button className="btn btn-primary" onClick={handleSaveSettings}>
              💾 Ayarları Kaydet
            </button>
            <button className="btn btn-outline-secondary" onClick={handleResetSettings}>
              🔄 Varsayılana Sıfırla
            </button>
            <button className="btn btn-outline-info">
              📤 Ayarları Dışa Aktar
            </button>
            <button className="btn btn-outline-success">
              📥 Ayarları İçe Aktar
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="admin-panel">
      <div className="admin-header">
        <div className="admin-header-content">
          <div className="admin-title">
            <h2>🏥 Hastane Yönetim Paneli</h2>
          </div>
          <div className="admin-user-info">
            <span>Hoş geldiniz, {user.name}</span>
            <button 
              className="btn logout-btn d-flex align-items-center" 
              onClick={onLogout}
              style={{ gap: '8px' }}
            >
              <LogOut size={18} />
              Çıkış Yap
            </button>
          </div>
        </div>
      </div>

      <div className="admin-navigation">
        <button 
          className={`btn ${activeTab === 'dashboard' ? 'btn-primary' : 'btn-outline-primary'}`}
          onClick={() => setActiveTab('dashboard')}
          style={{ margin: '4px' }}
        >
          📊 Dashboard
        </button>
        <button 
          className={`btn ${activeTab === 'users' ? 'btn-primary' : 'btn-outline-primary'}`}
          onClick={() => setActiveTab('users')}
          style={{ margin: '4px' }}
        >
          👥 Doktor Yönetimi
        </button>
        <button 
          className={`btn ${activeTab === 'reports' ? 'btn-primary' : 'btn-outline-primary'}`}
          onClick={() => setActiveTab('reports')}
          style={{ margin: '4px' }}
        >
          📈 Raporlar
        </button>
        <button 
          className={`btn ${activeTab === 'settings' ? 'btn-primary' : 'btn-outline-primary'}`}
          onClick={() => setActiveTab('settings')}
          style={{ margin: '4px' }}
        >
          ⚙️ Ayarlar
        </button>
      </div>

      <div className="admin-content">
        {activeTab === 'dashboard' && renderDashboard()}
        {activeTab === 'users' && renderDoctors()}
        {activeTab === 'reports' && renderReports()}
        {activeTab === 'settings' && renderSettings()}
      </div>

      {/* Doktor Detay Modal */}
      {showDoctorDetail && renderDoctorDetail()}

      {/* Ekipman Detay Modal */}
      {showEquipmentDetail && renderEquipmentDetail()}

      {/* Bakım Geçmişi Modal */}
      {showMaintenanceHistory && renderMaintenanceHistory()}

      {/* Teknik Dökümanlar Modal */}
      {showTechnicalDocs && renderTechnicalDocs()}

      {/* Acil Onarım Talebi Modal */}
      {showEmergencyRepair && renderEmergencyRepair()}

      {/* Doktor Ekleme/Düzenleme Modal */}
      {showDoctorModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h5>{selectedDoctor ? 'Doktor Düzenle' : 'Yeni Doktor Ekle'}</h5>
              <button 
                className="btn-close"
                onClick={() => setShowDoctorModal(false)}
              >×</button>
            </div>
            <div className="modal-body">
              <div className="mb-3">
                <label className="form-label">Doktor Adı</label>
                <input
                  type="text"
                  className="form-control"
                  value={doctorForm.name}
                  onChange={(e) => setDoctorForm({...doctorForm, name: e.target.value})}
                  placeholder="Dr. Ad Soyad"
                />
              </div>
              <div className="mb-3">
                <label className="form-label">Bölüm</label>
                <select
                  className="form-control"
                  value={doctorForm.department}
                  onChange={(e) => setDoctorForm({...doctorForm, department: e.target.value})}
                >
                  <option value="">Bölüm Seçin</option>
                  <option value="Kardiyoloji">Kardiyoloji</option>
                  <option value="Nöroloji">Nöroloji</option>
                  <option value="Ortopedi">Ortopedi</option>
                  <option value="Dahiliye">Dahiliye</option>
                  <option value="Göz Hastalıkları">Göz Hastalıkları</option>
                  <option value="Genel Cerrahi">Genel Cerrahi</option>
                </select>
              </div>
              <div className="mb-3">
                <label className="form-label">Email</label>
                <input
                  type="email"
                  className="form-control"
                  value={doctorForm.email}
                  onChange={(e) => setDoctorForm({...doctorForm, email: e.target.value})}
                  placeholder="doktor@hastane.com"
                />
              </div>
              <div className="mb-3">
                <label className="form-label">Telefon</label>
                <input
                  type="tel"
                  className="form-control"
                  value={doctorForm.phone}
                  onChange={(e) => setDoctorForm({...doctorForm, phone: e.target.value})}
                  placeholder="0532 123 4567"
                />
              </div>
              <div className="mb-3">
                <label className="form-label">Durum</label>
                <select
                  className="form-control"
                  value={doctorForm.status}
                  onChange={(e) => setDoctorForm({...doctorForm, status: e.target.value})}
                >
                  <option value="active">Aktif</option>
                  <option value="inactive">Pasif</option>
                </select>
              </div>
            </div>
            <div className="modal-footer">
              <button 
                className="btn btn-secondary"
                onClick={() => setShowDoctorModal(false)}
              >
                İptal
              </button>
              <button 
                className="btn btn-primary"
                onClick={handleSaveDoctor}
              >
                {selectedDoctor ? 'Güncelle' : 'Ekle'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Data
import patientsData from './data/patients.json';

function App() {
  const [user, setUser] = useState(null);
  const [patients, setPatients] = useState(patientsData);

  useEffect(() => {
    // Check if user is logged in from localStorage
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const handleLogin = (userData) => {
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  return (
    <Router>
      <div className="App">
        {!user ? (
          <Login onLogin={handleLogin} />
        ) : (
          <Layout user={user} onLogout={handleLogout}>
            <Routes>
              <Route 
                path="/" 
                element={
                  user.role === 'admin' ? 
                    <AdminPanel user={user} onLogout={handleLogout} patients={patients} /> :
                  user.role === 'doctor' ? 
                    <DoctorPanel patients={patients} setPatients={setPatients} onLogout={handleLogout} user={user} /> :
                    <PatientPanel patients={patients} user={user} onLogout={handleLogout} setPatients={setPatients} />
                } 
              />
              <Route 
                path="/doctor" 
                element={<DoctorPanel patients={patients} setPatients={setPatients} onLogout={handleLogout} user={user} />} 
              />
              <Route 
                path="/patient" 
                element={<PatientPanel patients={patients} user={user} onLogout={handleLogout} setPatients={setPatients} />} 
              />
              <Route 
                path="/admin" 
                element={<AdminPanel user={user} onLogout={handleLogout} patients={patients} />} 
              />
            </Routes>
          </Layout>
        )}
      </div>
    </Router>
  );
}

export default App;
