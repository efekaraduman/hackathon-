# 🏥 Hasta Veri Yönetim Sistemi

AI destekli hasta takip ve veri yönetim platformu. Doktorların hasta bilgilerini düzenli bir şekilde takip etmelerini sağlayan modern web uygulaması.

## ✨ Özellikler

### 🔐 Kullanıcı Yönetimi
- Doktor ve hasta giriş sistemi
- Rol tabanlı erişim kontrolü
- Güvenli kimlik doğrulama

### 👥 Hasta Yönetimi
- Hasta listesi ve arama
- Detaylı hasta profilleri
- Kronik hastalık takibi
- Alerji yönetimi
- İlaç geçmişi

### 💊 İlaç Yönetimi
- Reconciled medication list
- İlaç etkileşim analizi
- Dozaj takibi
- Kaynak yönetimi

### 📊 AI Analiz
- Hasta veri analizi
- Risk değerlendirmesi
- Güven seviyesi hesaplama
- Akıllı öneriler
- Doktor onay sistemi

### 📅 Timeline ve Takip
- Gelişmiş zaman çizelgesi
- Randevu yönetimi
- Laboratuvar sonuçları
- Operasyon geçmişi
- Olay filtreleme

### 🛡️ Veri Koruma
- KVKK/GDPR uyumlu rıza yönetimi
- Veri anonimleştirme
- Audit logging
- Güvenlik protokolleri

### 📈 Dashboard ve Analitik
- KPI dashboard
- Görsel analizler
- İstatistikler
- Raporlama

## 🚀 Kurulum

### Gereksinimler
- Node.js (v14 veya üzeri)
- npm veya yarn

### Adımlar

1. **Repository'yi klonla:**
```bash
git clone https://github.com/KULLANICI_ADIN/hasta-veri-yonetim-sistemi.git
cd hasta-veri-yonetim-sistemi
```

2. **Bağımlılıkları yükle:**
```bash
npm install
```

3. **Uygulamayı başlat:**
```bash
npm start
```

4. **Tarayıcıda aç:**
```
http://localhost:3000
```

## 🎨 Tema Özellikleri

### Minimalist Tasarım
- Sade ve temiz arayüz
- Profesyonel görünüm
- Göz yormayan renkler
- Responsive tasarım
- Modern tipografi

### Renk Paleti
- **Primary:** Mavi (#2563eb)
- **Secondary:** Gri (#64748b)
- **Success:** Yeşil (#10b981)
- **Warning:** Turuncu (#f59e0b)
- **Danger:** Kırmızı (#ef4444)

## 🛠️ Teknolojiler

- **Frontend:** React.js
- **UI Framework:** Bootstrap
- **Icons:** Lucide React
- **Charts:** Chart.js, react-chartjs-2
- **Styling:** CSS3, CSS Variables
- **State Management:** React Hooks
- **Routing:** React Router

## 📱 Responsive Tasarım

- **Desktop:** Tam özellikli arayüz
- **Tablet:** Optimize edilmiş layout
- **Mobile:** Dokunmatik uyumlu

## 🔧 Geliştirme

### Proje Yapısı
```
src/
├── components/          # React bileşenleri
│   ├── doctor/         # Doktor paneli bileşenleri
│   ├── Layout.js       # Ana layout
│   └── Login.js        # Giriş sayfası
├── data/               # Veri dosyaları
├── styles/             # CSS dosyaları
├── utils/              # Yardımcı fonksiyonlar
└── App.js              # Ana uygulama
```

### Scripts
```bash
npm start          # Geliştirme sunucusu
npm run build      # Production build
npm test           # Testleri çalıştır
```

## 📄 Lisans

Bu proje MIT lisansı altında lisanslanmıştır.

## 👥 Katkıda Bulunma

1. Fork yap
2. Feature branch oluştur (`git checkout -b feature/AmazingFeature`)
3. Commit yap (`git commit -m 'Add some AmazingFeature'`)
4. Push yap (`git push origin feature/AmazingFeature`)
5. Pull Request oluştur

## 📞 İletişim

Proje hakkında sorularınız için issue açabilirsiniz.

---

**Not:** Bu proje demo amaçlıdır. Gerçek hasta verileri için güvenlik önlemleri alınmalıdır.